(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// routes/wx.js                                                        //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Router.route('/list/wxorderlists', {                                   // 1
  "name": "wxorderlists",                                              // 2
  waitOn: function () {                                                // 3
    return Meteor.subscribe("getwxorders");                            // 4
  },                                                                   //
  data: function () {                                                  // 6
    var wxorders = Orders.find({ host: 'KYLWECHAT' });                 // 7
    return {                                                           // 8
      wxorders: wxorders                                               // 9
    };                                                                 //
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/wxorder/:orderId', {                                    // 14
  name: 'wxorderdetail',                                               // 15
  waitOn: function () {                                                // 16
    var orderId = this.params.orderId;                                 // 17
    return Meteor.subscribe('getwxorder', orderId);                    // 18
  },                                                                   //
  data: function () {                                                  // 20
    var orderId = this.params.orderId;                                 // 21
    var order = Orders.findOne({ host: 'KYLWECHAT', order_id: orderId });
    return {                                                           // 23
      order: order                                                     // 24
    };                                                                 //
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=wx.js.map
