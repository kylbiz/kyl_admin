(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// routes/template.js                                                  //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Router.route("/template", {                                            // 1
  name: "template",                                                    // 2
  onBeforeAction: function () {                                        // 3
    if (!Meteor.userId()) {                                            // 4
      Router.go('/sign-in');                                           // 5
    } else {                                                           //
      var uuid = this.params.query.uuid || "";                         // 7
      var type = this.params.query.type || "check";                    // 8
      var zone = this.params.query.zone || "hk";                       // 9
      var holdernum = this.params.query.holdernum || "1";              // 10
                                                                       //
      Session.set("uuid", uuid);                                       // 12
      Session.set("type", type);                                       // 13
      Session.set("zone", zone);                                       // 14
      Session.set("holdernum", holdernum);                             // 15
    }                                                                  //
    this.next();                                                       // 18
  },                                                                   //
  subscriptions: function () {                                         // 20
    var uuid = this.params.query.uuid || "";                           // 21
    Meteor.subscribe('GetHandleResults', uuid);                        // 22
    Meteor.subscribe("getDocNum");                                     // 23
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=template.js.map
