(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// routes/production.js                                                //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
//---------------------------------------------                        //
function isInteger(value) {                                            // 2
  return typeof value === "number" && isFinite(value) && Math.floor(value) === value;
}                                                                      //
                                                                       //
function handleProportion(numerator, denominator) {                    // 8
  var num = numerator * 100 / denominator;                             // 9
  if (isInteger(num)) {                                                // 10
    return num + '%';                                                  // 11
  } else {                                                             //
    return num.toFixed(2) + '%';                                       // 13
  }                                                                    //
}                                                                      //
                                                                       //
Router.configure({                                                     // 18
  layoutTemplate: 'basicLayout',                                       // 19
  notFoundTemplate: 'notFound'                                         // 20
});                                                                    //
                                                                       //
Router.route('/', {                                                    // 23
  onBeforeAction: function () {                                        // 24
    if (!Meteor.user()) {                                              // 25
      Router.go('/login');                                             // 26
    } else {                                                           //
      Router.go('/list');                                              // 28
      this.next();                                                     // 29
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/login', function () {                                   // 34
  this.render('login');                                                // 35
  Router.go('/');                                                      // 36
});                                                                    //
                                                                       //
Router.route('list', {                                                 // 39
  onBeforeAction: function () {                                        // 40
    if (!Meteor.user()) {                                              // 41
      Router.go('/login');                                             // 42
    } else {                                                           //
      this.next();                                                     // 44
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/list/table');                                           // 49
                                                                       //
Router.route('/list/registration', {                                   // 53
  name: 'registrationLists'                                            // 54
});                                                                    //
                                                                       //
// subscriptions: function() {                                         //
//   return Meteor.subscribe('getOrderTypeLists', 'registration');     //
// },                                                                  //
// waitOn: function() {                                                //
//   return Meteor.subscribe('getOrderTypeLists', 'registration');     //
// }                                                                   //
Router.route('/list/finance', {                                        // 63
  name: 'financeList'                                                  // 64
});                                                                    //
                                                                       //
// subscriptions: function() {                                         //
//   return Meteor.subscribe('getOrderTypeLists', 'finance');          //
// },                                                                  //
// waitOn: function() {                                                //
//   return Meteor.subscribe('getOrderTypeLists', 'finance');          //
// }                                                                   //
Router.route('/list/bank', {                                           // 73
  name: 'bankList'                                                     // 74
});                                                                    //
                                                                       //
// subscriptions: function() {                                         //
//  return  Meteor.subscribe('getOrderTypeLists', 'bank');             //
// },                                                                  //
// waitOn: function() {                                                //
//  return  Meteor.subscribe('getOrderTypeLists', 'bank');             //
// }                                                                   //
Router.route('/list/assurance', {                                      // 83
  name: 'assuranceList'                                                // 84
});                                                                    //
                                                                       //
// subscriptions: function() {                                         //
//  return Meteor.subscribe('getOrderTypeLists', 'assurance');         //
// },                                                                  //
// waitOn: function() {                                                //
//  return Meteor.subscribe('getOrderTypeLists', 'assurance');         //
// }                                                                   //
Router.route('/list/bookkeeping', {                                    // 93
  name: 'bookkeepingList'                                              // 94
});                                                                    //
                                                                       //
// subscriptions: function() {                                         //
//   return Meteor.subscribe('getOrderTypeLists', 'bookkeeping');      //
// },                                                                  //
// waitOn: function() {                                                //
//  return Meteor.subscribe('getOrderTypeLists', 'bookkeeping');       //
// }                                                                   //
Router.route('/list/special', {                                        // 103
  name: 'specialList'                                                  // 104
});                                                                    //
                                                                       //
// subscriptions: function() {                                         //
//   return Meteor.subscribe('getOrderTypeLists', 'special');          //
// },                                                                  //
// waitOn: function() {                                                //
//  return Meteor.subscribe('getOrderTypeLists', 'special');           //
// }                                                                   //
Router.route('/primaryList', function () {                             // 114
  this.render('primaryList');                                          // 115
});                                                                    //
                                                                       //
Router.route('/registration/:orderId', {                               // 118
  name: 'registrationView',                                            // 119
  subscriptions: function () {                                         // 120
    var orderId = this.params.orderId;                                 // 121
    return Meteor.subscribe('orderInformation', orderId);              // 122
  },                                                                   //
  waitOn: function () {                                                // 124
    var orderId = this.params.orderId;                                 // 125
    return Meteor.subscribe('orderInformation', orderId);              // 126
  },                                                                   //
  data: function () {                                                  // 128
    var orderId = this.params.orderId;                                 // 129
    Session.set('orderId', orderId);                                   // 130
    var order = Orders.findOne({ orderId: orderId });                  // 131
    if (order && order.holders) {                                      // 132
      var holders = order.holders;                                     // 133
      var moneyAmount = 0;                                             // 134
      holders.forEach(function (holder) {                              // 135
        if (typeof (holder.money === 'string')) {                      // 136
          holder.money = parseInt(holder.money);                       // 137
        }                                                              //
        moneyAmount += holder.money;                                   // 139
      });                                                              //
      var length = holders.length;                                     // 141
      if (moneyAmount > 0) {                                           // 142
        for (var i = 0; i < length; i++) {                             // 143
          var percentage = handleProportion(parseInt(holders[i].money), moneyAmount);
          holders[i].percentage = percentage;                          // 145
        }                                                              //
      }                                                                //
      order.holders = holders;                                         // 148
    }                                                                  //
    return {                                                           // 150
      order: order                                                     // 151
    };                                                                 //
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/edit/registration/:orderId', {                          // 156
  name: 'editorFactory',                                               // 157
  subscriptions: function () {                                         // 158
    var orderId = this.params.orderId;                                 // 159
    return Meteor.subscribe('orderInformation', orderId);              // 160
  },                                                                   //
  waitOn: function () {                                                // 162
    var orderId = this.params.orderId;                                 // 163
    return Meteor.subscribe('orderInformation', orderId);              // 164
  },                                                                   //
  data: function () {                                                  // 166
    var self = this;                                                   // 167
    self.businessScope = [];                                           // 168
    var orderId = this.params.orderId;                                 // 169
    Session.set('orderId', orderId);                                   // 170
    var order = Orders.findOne({ orderId: orderId }, { sort: { createTime: -1 } });
    if (order && order.hasOwnProperty('businessScope')) {              // 172
      var businessScope = order.businessScope;                         // 173
      var length = businessScope.length;                               // 174
      for (var i = 0; i < length; i++) {                               // 175
        self.businessScope.push({ name: businessScope[i] });           // 176
      }                                                                //
      return {                                                         // 178
        businessScope: self.businessScope,                             // 179
        order: order                                                   // 180
      };                                                               //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/assurance/:orderId', {                                  // 186
  name: 'assuranceView',                                               // 187
  subscriptions: function () {                                         // 188
    var orderId = this.params.orderId;                                 // 189
                                                                       //
    return Meteor.subscribe('orderInformation', orderId);              // 191
  },                                                                   //
  waitOn: function () {                                                // 193
    var orderId = this.params.orderId;                                 // 194
    return Meteor.subscribe('orderInformation', orderId);              // 195
  },                                                                   //
  data: function () {                                                  // 197
    var orderId = this.params.orderId;                                 // 198
    var order = Orders.findOne({ orderId: orderId });                  // 199
    return {                                                           // 200
      order: order                                                     // 201
    };                                                                 //
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/finance/:orderId', {                                    // 207
  name: 'financeView',                                                 // 208
  subscriptions: function () {                                         // 209
    var orderId = this.params.orderId;                                 // 210
    return Meteor.subscribe('orderInformation', orderId);              // 211
  },                                                                   //
  waitOn: function () {                                                // 213
    var orderId = this.params.orderId;                                 // 214
    return Meteor.subscribe('orderInformation', orderId);              // 215
  },                                                                   //
  data: function () {                                                  // 217
    var orderId = this.params.orderId;                                 // 218
    var order = Orders.findOne({ orderId: orderId });                  // 219
    return {                                                           // 220
      order: order                                                     // 221
    };                                                                 //
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/bank/:orderId', {                                       // 228
  name: 'bankView',                                                    // 229
  subscriptions: function () {                                         // 230
    var orderId = this.params.orderId;                                 // 231
                                                                       //
    return Meteor.subscribe('orderInformation', orderId);              // 233
  },                                                                   //
  waitOn: function () {                                                // 235
    var orderId = this.params.orderId;                                 // 236
    return Meteor.subscribe('orderInformation', orderId);              // 237
  },                                                                   //
  data: function () {                                                  // 239
    var orderId = this.params.orderId;                                 // 240
    var order = Orders.findOne({ orderId: orderId });                  // 241
    return {                                                           // 242
      order: order                                                     // 243
    };                                                                 //
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/bookkeeping/:orderId', {                                // 249
  name: 'bookkeepingView',                                             // 250
  subscriptions: function () {                                         // 251
    var orderId = this.params.orderId;                                 // 252
                                                                       //
    return Meteor.subscribe('orderInformation', orderId);              // 254
  },                                                                   //
  waitOn: function () {                                                // 256
    var orderId = this.params.orderId;                                 // 257
    return Meteor.subscribe('orderInformation', orderId);              // 258
  },                                                                   //
  data: function () {                                                  // 260
    var orderId = this.params.orderId;                                 // 261
    var order = Orders.findOne({ orderId: orderId });                  // 262
    if (order && order.holders) {                                      // 263
      var holders = order.holders;                                     // 264
      var moneyAmount = 0;                                             // 265
      holders.forEach(function (holder) {                              // 266
        if (typeof (holder.money === 'string')) {                      // 267
          holder.money = parseInt(holder.money);                       // 268
        }                                                              //
        moneyAmount += holder.money;                                   // 270
      });                                                              //
      var length = holders.length;                                     // 272
      if (moneyAmount > 0) {                                           // 273
        for (var i = 0; i < length; i++) {                             // 274
          var percentage = handleProportion(parseInt(holders[i].money), moneyAmount);
          holders[i].percentage = percentage;                          // 276
        }                                                              //
      }                                                                //
      order.holders = holders;                                         // 279
    }                                                                  //
    return {                                                           // 281
      order: order                                                     // 282
    };                                                                 //
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/special/:orderId', {                                    // 288
  name: 'specialView',                                                 // 289
  subscriptions: function () {                                         // 290
    var orderId = this.params.orderId;                                 // 291
                                                                       //
    return Meteor.subscribe('orderInformation', orderId);              // 293
  },                                                                   //
  waitOn: function () {                                                // 295
    var orderId = this.params.orderId;                                 // 296
    return Meteor.subscribe('orderInformation', orderId);              // 297
  },                                                                   //
  data: function () {                                                  // 299
    var orderId = this.params.orderId;                                 // 300
    var order = Orders.findOne({ orderId: orderId });                  // 301
    return {                                                           // 302
      order: order                                                     // 303
    };                                                                 //
  }                                                                    //
});                                                                    //
                                                                       //
// 客户帐号查看                                                              //
Router.route('/userList', {                                            // 311
  name: 'userList',                                                    // 312
  subscriptions: function () {                                         // 313
    return Meteor.subscribe("customers");                              // 314
  },                                                                   //
  waitOn: function () {                                                // 316
    return Meteor.subscribe("customers");                              // 317
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/userDetail/:_id', {                                     // 321
  name: 'userDetail',                                                  // 322
  waitOn: function () {                                                // 323
    var userId = this.params._id;                                      // 324
    return Meteor.subscribe("getCustomer", userId);                    // 325
  },                                                                   //
  data: function () {                                                  // 327
    Session.set("userId", this.params._id);                            // 328
    return Meteor.users.findOne({ _id: this.params._id });             // 329
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/adminSet/:_id', {                                       // 333
  name: 'adminSet',                                                    // 334
  waitOn: function () {                                                // 335
    return Meteor.subscribe("admins");                                 // 336
  },                                                                   //
  data: function () {                                                  // 338
    if (this.params._id == "addadmin") {                               // 339
      return { _id: this.params._id };                                 // 340
    };                                                                 //
    return Meteor.users.findOne({ _id: this.params._id });             // 342
  }                                                                    //
});                                                                    //
                                                                       //
// 登陆权限控制                                                              //
Router.onBeforeAction(function () {                                    // 347
  var user = Meteor.user();                                            // 348
  if (!user || !user.username) {                                       // 349
    this.render('login');                                              // 350
  } else {                                                             //
    var username = user.username;                                      // 352
    Meteor.call("checkLoginPermission", username, function (err, result) {
      if (!result) {                                                   // 354
        Meteor.logout();                                               // 355
      }                                                                //
    });                                                                //
    this.next();                                                       // 358
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('profile');                                               // 362
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=production.js.map
