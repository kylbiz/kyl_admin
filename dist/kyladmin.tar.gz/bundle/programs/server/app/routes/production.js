(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// routes/production.js                                                //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
//---------------------------------------------                        //
function isInteger(value) {                                            // 2
  return typeof value === "number" && isFinite(value) && Math.floor(value) === value;
}                                                                      //
                                                                       //
function handleProportion(numerator, denominator) {                    // 8
  var num = numerator * 100 / denominator;                             // 9
  if (isInteger(num)) {                                                // 10
    return num + '%';                                                  // 11
  } else {                                                             //
    return num.toFixed(2) + '%';                                       // 13
  }                                                                    //
}                                                                      //
                                                                       //
Router.configure({                                                     // 18
  layoutTemplate: 'basicLayout',                                       // 19
  notFoundTemplate: 'notFound'                                         // 20
});                                                                    //
                                                                       //
Router.route('/', {                                                    // 23
  onBeforeAction: function () {                                        // 24
    if (!Meteor.user()) {                                              // 25
      Router.go('/login');                                             // 26
    } else {                                                           //
      Router.go('/list');                                              // 28
      this.next();                                                     // 29
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/login', function () {                                   // 34
  this.render('login');                                                // 35
  Router.go('/');                                                      // 36
});                                                                    //
                                                                       //
Router.route('list', {                                                 // 39
  onBeforeAction: function () {                                        // 40
    if (!Meteor.user()) {                                              // 41
      Router.go('/login');                                             // 42
    } else {                                                           //
      this.next();                                                     // 44
    }                                                                  //
  },                                                                   //
  waitOn: function () {                                                // 47
    var userId = Meteor.userId() || "";                                // 48
    return Meteor.subscribe('getAllOrders');                           // 49
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/list/registration', {                                   // 53
  name: 'registrationLists',                                           // 54
  subscriptions: function () {                                         // 55
    return Meteor.subscribe('getOrderTypeLists', 'registration');      // 56
  },                                                                   //
  waitOn: function () {                                                // 58
    return Meteor.subscribe('getOrderTypeLists', 'registration');      // 59
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/list/finance', {                                        // 63
  name: 'financeList',                                                 // 64
  subscriptions: function () {                                         // 65
    return Meteor.subscribe('getOrderTypeLists', 'finance');           // 66
  },                                                                   //
  waitOn: function () {                                                // 68
    return Meteor.subscribe('getOrderTypeLists', 'finance');           // 69
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/list/bank', {                                           // 73
  name: 'bankList',                                                    // 74
  subscriptions: function () {                                         // 75
    return Meteor.subscribe('getOrderTypeLists', 'bank');              // 76
  },                                                                   //
  waitOn: function () {                                                // 78
    return Meteor.subscribe('getOrderTypeLists', 'bank');              // 79
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/list/assurance', {                                      // 83
  name: 'assuranceList',                                               // 84
  subscriptions: function () {                                         // 85
    return Meteor.subscribe('getOrderTypeLists', 'assurance');         // 86
  },                                                                   //
  waitOn: function () {                                                // 88
    return Meteor.subscribe('getOrderTypeLists', 'assurance');         // 89
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/list/bookkeeping', {                                    // 93
  name: 'bookkeepingList',                                             // 94
  subscriptions: function () {                                         // 95
    return Meteor.subscribe('getOrderTypeLists', 'bookkeeping');       // 96
  },                                                                   //
  waitOn: function () {                                                // 98
    return Meteor.subscribe('getOrderTypeLists', 'bookkeeping');       // 99
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/list/special', {                                        // 103
  name: 'specialList',                                                 // 104
  subscriptions: function () {                                         // 105
    return Meteor.subscribe('getOrderTypeLists', 'special');           // 106
  },                                                                   //
  waitOn: function () {                                                // 108
    return Meteor.subscribe('getOrderTypeLists', 'special');           // 109
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/primaryList', function () {                             // 114
  this.render('primaryList');                                          // 115
});                                                                    //
                                                                       //
Router.route('/registration/:orderId', {                               // 118
  name: 'registrationView',                                            // 119
  subscriptions: function () {                                         // 120
    var orderId = this.params.orderId;                                 // 121
    return Meteor.subscribe('orderInformation', orderId);              // 122
  },                                                                   //
  waitOn: function () {                                                // 124
    var orderId = this.params.orderId;                                 // 125
    return Meteor.subscribe('orderInformation', orderId);              // 126
  },                                                                   //
  data: function () {                                                  // 128
    var orderId = this.params.orderId;                                 // 129
    Session.set('orderId', orderId);                                   // 130
    var order = Orders.findOne({ orderId: orderId });                  // 131
    if (order && order.holders) {                                      // 132
      var holders = order.holders;                                     // 133
      var moneyAmount = 0;                                             // 134
      holders.forEach(function (holder) {                              // 135
        if (typeof (holder.money === 'string')) {                      // 136
          holder.money = parseInt(holder.money);                       // 137
        }                                                              //
        moneyAmount += holder.money;                                   // 139
      });                                                              //
      var length = holders.length;                                     // 141
      if (moneyAmount > 0) {                                           // 142
        for (var i = 0; i < length; i++) {                             // 143
          var percentage = handleProportion(parseInt(holders[i].money), moneyAmount);
          holders[i].percentage = percentage;                          // 145
        }                                                              //
      }                                                                //
      order.holders = holders;                                         // 148
    }                                                                  //
    return {                                                           // 150
      order: order                                                     // 151
    };                                                                 //
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/edit/registration/:orderId', {                          // 157
  name: 'editorFactory',                                               // 158
  subscriptions: function () {                                         // 159
    var orderId = this.params.orderId;                                 // 160
    return Meteor.subscribe('orderInformation', orderId);              // 161
  },                                                                   //
  waitOn: function () {                                                // 163
    var orderId = this.params.orderId;                                 // 164
    return Meteor.subscribe('orderInformation', orderId);              // 165
  },                                                                   //
  data: function () {                                                  // 167
    var self = this;                                                   // 168
    self.businessScope = [];                                           // 169
    var orderId = this.params.orderId;                                 // 170
    Session.set('orderId', orderId);                                   // 171
    var order = Orders.findOne({ orderId: orderId }, { sort: { createTime: -1 } });
    if (order && order.hasOwnProperty('businessScope')) {              // 173
      var businessScope = order.businessScope;                         // 174
      var length = businessScope.length;                               // 175
      for (var i = 0; i < length; i++) {                               // 176
        self.businessScope.push({ name: businessScope[i] });           // 177
      }                                                                //
      return {                                                         // 179
        businessScope: self.businessScope,                             // 180
        order: order                                                   // 181
      };                                                               //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/assurance/:orderId', {                                  // 189
  name: 'assuranceView',                                               // 190
  subscriptions: function () {                                         // 191
    var orderId = this.params.orderId;                                 // 192
                                                                       //
    return Meteor.subscribe('orderInformation', orderId);              // 194
  },                                                                   //
  waitOn: function () {                                                // 196
    var orderId = this.params.orderId;                                 // 197
    return Meteor.subscribe('orderInformation', orderId);              // 198
  },                                                                   //
  data: function () {                                                  // 200
    var orderId = this.params.orderId;                                 // 201
    var order = Orders.findOne({ orderId: orderId });                  // 202
    return {                                                           // 203
      order: order                                                     // 204
    };                                                                 //
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/finance/:orderId', {                                    // 210
  name: 'financeView',                                                 // 211
  subscriptions: function () {                                         // 212
    var orderId = this.params.orderId;                                 // 213
    return Meteor.subscribe('orderInformation', orderId);              // 214
  },                                                                   //
  waitOn: function () {                                                // 216
    var orderId = this.params.orderId;                                 // 217
    return Meteor.subscribe('orderInformation', orderId);              // 218
  },                                                                   //
  data: function () {                                                  // 220
    var orderId = this.params.orderId;                                 // 221
    var order = Orders.findOne({ orderId: orderId });                  // 222
    return {                                                           // 223
      order: order                                                     // 224
    };                                                                 //
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/bank/:orderId', {                                       // 231
  name: 'bankView',                                                    // 232
  subscriptions: function () {                                         // 233
    var orderId = this.params.orderId;                                 // 234
                                                                       //
    return Meteor.subscribe('orderInformation', orderId);              // 236
  },                                                                   //
  waitOn: function () {                                                // 238
    var orderId = this.params.orderId;                                 // 239
    return Meteor.subscribe('orderInformation', orderId);              // 240
  },                                                                   //
  data: function () {                                                  // 242
    var orderId = this.params.orderId;                                 // 243
    var order = Orders.findOne({ orderId: orderId });                  // 244
    return {                                                           // 245
      order: order                                                     // 246
    };                                                                 //
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/bookkeeping/:orderId', {                                // 252
  name: 'bookkeepingView',                                             // 253
  subscriptions: function () {                                         // 254
    var orderId = this.params.orderId;                                 // 255
                                                                       //
    return Meteor.subscribe('orderInformation', orderId);              // 257
  },                                                                   //
  waitOn: function () {                                                // 259
    var orderId = this.params.orderId;                                 // 260
    return Meteor.subscribe('orderInformation', orderId);              // 261
  },                                                                   //
  data: function () {                                                  // 263
    var orderId = this.params.orderId;                                 // 264
    var order = Orders.findOne({ orderId: orderId });                  // 265
    if (order && order.holders) {                                      // 266
      var holders = order.holders;                                     // 267
      var moneyAmount = 0;                                             // 268
      holders.forEach(function (holder) {                              // 269
        if (typeof (holder.money === 'string')) {                      // 270
          holder.money = parseInt(holder.money);                       // 271
        }                                                              //
        moneyAmount += holder.money;                                   // 273
      });                                                              //
      var length = holders.length;                                     // 275
      if (moneyAmount > 0) {                                           // 276
        for (var i = 0; i < length; i++) {                             // 277
          var percentage = handleProportion(parseInt(holders[i].money), moneyAmount);
          holders[i].percentage = percentage;                          // 279
        }                                                              //
      }                                                                //
      order.holders = holders;                                         // 282
    }                                                                  //
    return {                                                           // 284
      order: order                                                     // 285
    };                                                                 //
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/special/:orderId', {                                    // 291
  name: 'specialView',                                                 // 292
  subscriptions: function () {                                         // 293
    var orderId = this.params.orderId;                                 // 294
                                                                       //
    return Meteor.subscribe('orderInformation', orderId);              // 296
  },                                                                   //
  waitOn: function () {                                                // 298
    var orderId = this.params.orderId;                                 // 299
    return Meteor.subscribe('orderInformation', orderId);              // 300
  },                                                                   //
  data: function () {                                                  // 302
    var orderId = this.params.orderId;                                 // 303
    var order = Orders.findOne({ orderId: orderId });                  // 304
    return {                                                           // 305
      order: order                                                     // 306
    };                                                                 //
  }                                                                    //
});                                                                    //
                                                                       //
// 客户帐号查看                                                              //
Router.route('/userList', {                                            // 314
  name: 'userList',                                                    // 315
  subscriptions: function () {                                         // 316
    return Meteor.subscribe("customers");                              // 317
  },                                                                   //
  waitOn: function () {                                                // 319
    return Meteor.subscribe("customers");                              // 320
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/userDetail/:_id', {                                     // 324
  name: 'userDetail',                                                  // 325
  waitOn: function () {                                                // 326
    var userId = this.params._id;                                      // 327
    return Meteor.subscribe("getCustomer", userId);                    // 328
  },                                                                   //
  data: function () {                                                  // 330
    Session.set("userId", this.params._id);                            // 331
    return Meteor.users.findOne({ _id: this.params._id });             // 332
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/adminSet/:_id', {                                       // 336
  name: 'adminSet',                                                    // 337
  waitOn: function () {                                                // 338
    return Meteor.subscribe("admins");                                 // 339
  },                                                                   //
  data: function () {                                                  // 341
    if (this.params._id == "addadmin") {                               // 342
      return { _id: this.params._id };                                 // 343
    };                                                                 //
    return Meteor.users.findOne({ _id: this.params._id });             // 345
  }                                                                    //
});                                                                    //
                                                                       //
// 登陆权限控制                                                              //
Router.onBeforeAction(function () {                                    // 350
  var user = Meteor.user();                                            // 351
  if (!user || !user.username) {                                       // 352
    this.render('login');                                              // 353
  } else {                                                             //
    var username = user.username;                                      // 355
    Meteor.call("checkLoginPermission", username, function (err, result) {
      if (!result) {                                                   // 357
        Meteor.logout();                                               // 358
      }                                                                //
    });                                                                //
    this.next();                                                       // 361
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('profile');                                               // 365
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=production.js.map
