(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// routes/manager.js                                                   //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
// 后台用户管理                                                              //
Router.route('/manager/user', {                                        // 2
  template: 'loading',                                                 // 3
  onBeforeAction: function () {                                        // 4
    var self = this;                                                   // 5
    this.render("loading");                                            // 6
    Meteor.call('checkUserHandlePermission', function (error, result) {
      if (!result) {                                                   // 8
        self.render('nopermission');                                   // 9
      } else {                                                         //
        self.render("manager");                                        // 11
      }                                                                //
    });                                                                //
                                                                       //
    this.next();                                                       // 15
  },                                                                   //
  subscriptions: function () {                                         // 17
    return Meteor.subscribe("admins");                                 // 18
  }                                                                    //
});                                                                    //
                                                                       //
// -------------------------------------------------                   //
                                                                       //
// 后台公司注册管理                                                            //
Router.route('/manager/registration', {                                // 26
  // template: 'loading',                                              //
  name: 'RegistrationInfos'                                            // 28
});                                                                    //
                                                                       //
// -------------------------------------------------                   //
// 公司注册具体信息                                                            //
// onBeforeAction: function () {                                       //
//   var self = this;                                                  //
//   Meteor.call('checkUserHandlePermission', function (error, result) {
//     if (!result) {                                                  //
//       self.render('nopermission');                                  //
//     } else {                                                        //
//       self.render("RegistrationInfos");                             //
//     }                                                               //
//   });                                                               //
                                                                       //
//   this.next();                                                      //
// }                                                                   //
Router.route('/manager/registration/:listId', {                        // 45
  // template: 'loading',                                              //
  name: 'RegistrationManageView'                                       // 47
});                                                                    //
                                                                       //
// -------------------------------------------------                   //
// 管理银行信息                                                              //
// onBeforeAction: function () {                                       //
//   var self = this;                                                  //
//   var listId = self.params.listId || "";                            //
//   Session.set({listId: listId});                                    //
//   Meteor.call('checkUserHandlePermission', function (error, result) {
//     if (!result) {                                                  //
//       self.render('nopermission');                                  //
//     } else {                                                        //
//       self.render("RegistrationManageView");                        //
//     }                                                               //
//   });                                                               //
                                                                       //
//   this.next();                                                      //
// }                                                                   //
                                                                       //
Router.route('/manager/bank', {                                        // 67
  // template: 'loading',                                              //
  name: 'ManageBank'                                                   // 69
});                                                                    //
                                                                       //
// --------------------------------------------------                  //
                                                                       //
// 管理微信小店                                                              //
// onBeforeAction: function () {                                       //
//   var self = this;                                                  //
//   Meteor.call('checkUserHandlePermission', function (error, result) {
//     if (!result) {                                                  //
//       self.render('nopermission');                                  //
//     } else {                                                        //
//       self.render("ManageBank");                                    //
//     }                                                               //
//   });                                                               //
//   this.next();                                                      //
// }                                                                   //
Router.route('/manager/wxshop', {                                      // 87
  name: 'WXShopList',                                                  // 88
  waitOn: function () {                                                // 89
    return Meteor.subscribe('getWxShopInfo');                          // 90
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/manager/wxshop/:_id', {                                 // 94
  // name: 'WXShopGoodView',                                           //
  name: 'developing',                                                  // 96
  waitOn: function () {                                                // 97
    var _id = this.params._id;                                         // 98
    return Meteor.subscribe('getWxShopInfo', { _id: _id });            // 99
  }                                                                    //
});                                                                    //
                                                                       //
// Router.route('/manager/wxshop/new', {});                            //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=manager.js.map
