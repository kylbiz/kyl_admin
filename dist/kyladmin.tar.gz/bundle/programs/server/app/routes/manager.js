(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// routes/manager.js                                                   //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
                                                                       //
                                                                       //
// 后台用户管理                                                              //
Router.route('/manager/user', {                                        // 5
  template: 'loading',                                                 // 6
  onBeforeAction: function () {                                        // 7
    var self = this;                                                   // 8
    this.render("loading");                                            // 9
    Meteor.call('checkUserHandlePermission', function (error, result) {
      if (!result) {                                                   // 11
        self.render('nopermission');                                   // 12
      } else {                                                         //
        self.render("manager");                                        // 14
      }                                                                //
    });                                                                //
                                                                       //
    this.next();                                                       // 18
  },                                                                   //
  subscriptions: function () {                                         // 20
    return Meteor.subscribe("admins");                                 // 21
  }                                                                    //
});                                                                    //
                                                                       //
// -------------------------------------------------                   //
                                                                       //
// 后台公司注册管理                                                            //
Router.route('/manager/registration', {                                // 29
  // template: 'loading',                                              //
  name: 'RegistrationInfos'                                            // 31
});                                                                    //
                                                                       //
// -------------------------------------------------                   //
// 公司注册具体信息                                                            //
// onBeforeAction: function () {                                       //
//   var self = this;                                                  //
//   Meteor.call('checkUserHandlePermission', function (error, result) {
//     if (!result) {                                                  //
//       self.render('nopermission');                                  //
//     } else {                                                        //
//       self.render("RegistrationInfos");                             //
//     }                                                               //
//   });                                                               //
                                                                       //
//   this.next();                                                      //
// }                                                                   //
Router.route('/manager/registration/:listId', {                        // 48
  // template: 'loading',                                              //
  name: 'RegistrationManageView'                                       // 50
});                                                                    //
                                                                       //
// -------------------------------------------------                   //
// 管理银行信息                                                              //
// onBeforeAction: function () {                                       //
//   var self = this;                                                  //
//   var listId = self.params.listId || "";                            //
//   Session.set({listId: listId});                                    //
//   Meteor.call('checkUserHandlePermission', function (error, result) {
//     if (!result) {                                                  //
//       self.render('nopermission');                                  //
//     } else {                                                        //
//       self.render("RegistrationManageView");                        //
//     }                                                               //
//   });                                                               //
                                                                       //
//   this.next();                                                      //
// }                                                                   //
                                                                       //
Router.route('/manager/bank', {                                        // 70
  // template: 'loading',                                              //
  name: 'ManageBank'                                                   // 72
});                                                                    //
                                                                       //
// --------------------------------------------------                  //
                                                                       //
// 管理微信小店                                                              //
// onBeforeAction: function () {                                       //
//   var self = this;                                                  //
//   Meteor.call('checkUserHandlePermission', function (error, result) {
//     if (!result) {                                                  //
//       self.render('nopermission');                                  //
//     } else {                                                        //
//       self.render("ManageBank");                                    //
//     }                                                               //
//   });                                                               //
//   this.next();                                                      //
// }                                                                   //
Router.route('/manager/wxshop', {                                      // 90
  name: 'WXShopList',                                                  // 91
  waitOn: function () {                                                // 92
    return Meteor.subscribe('getWxShopInfo');                          // 93
  }                                                                    //
});                                                                    //
                                                                       //
Router.route('/manager/wxshop/:_id', {                                 // 97
  // name: 'WXShopGoodView',                                           //
  name: 'developing',                                                  // 99
  waitOn: function () {                                                // 100
    var _id = this.params._id;                                         // 101
    return Meteor.subscribe('getWxShopInfo', { _id: _id });            // 102
  }                                                                    //
});                                                                    //
                                                                       //
// Router.route('/manager/wxshop/new', {});                            //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=manager.js.map
