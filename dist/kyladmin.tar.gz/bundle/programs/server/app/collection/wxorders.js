(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// collection/wxorders.js                                              //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Orders.helpers({                                                       // 1
  order_update_time: function () {                                     // 2
    var updateTime = this.updateTime;                                  // 3
    if (updateTime) {                                                  // 4
      var year = updateTime.getFullYear();                             // 5
      var month = updateTime.getMonth() + 1;                           // 6
      var date = updateTime.getDate();                                 // 7
      var hours = updateTime.getHours();                               // 8
      var minutes = updateTime.getMinutes();                           // 9
      var order_update_time = year + '-' + month + '-' + date + ' ' + hours + ':' + minutes;
      return order_update_time;                                        // 11
    } else {                                                           //
      return "";                                                       // 13
    }                                                                  //
  },                                                                   //
  "order_create_timeL": function () {                                  // 16
    var order_create_time = this.order_create_time;                    // 17
    if (order_create_time) {                                           // 18
      var createTime = new Date(order_create_time * 1000);             // 19
      var year = createTime.getFullYear();                             // 20
      var month = createTime.getMonth() + 1;                           // 21
      var date = createTime.getDate();                                 // 22
      var hours = createTime.getHours();                               // 23
      var minutes = createTime.getMinutes();                           // 24
      var order_create_timeL = year + '-' + month + '-' + date + ' ' + hours + ':' + minutes;
      return order_create_timeL;                                       // 26
    } else {                                                           //
      return "";                                                       // 28
    }                                                                  //
  },                                                                   //
  "product_priceL": function () {                                      // 31
    var product_price = this.product_price || 0;                       // 32
    if (product_price) {                                               // 33
      return product_price / 100;                                      // 34
    } else {                                                           //
      return 0;                                                        // 36
    }                                                                  //
  },                                                                   //
  "order_total_priceL": function () {                                  // 39
    var order_total_price = this.order_total_price || 0;               // 40
    if (order_total_price) {                                           // 41
      return order_total_price / 100;                                  // 42
    } else {                                                           //
      return 0;                                                        // 44
    }                                                                  //
  },                                                                   //
  "order_statusL": function () {                                       // 47
    var order_status = this.order_status || "";                        // 48
    var status = "";                                                   // 49
    if (order_status) {                                                // 50
      switch (order_status) {                                          // 51
        case 2:                                                        // 52
          status = "待发货";                                              // 53
          break;                                                       // 54
        case 3:                                                        // 55
          status = '已发货';                                              // 56
          break;                                                       // 57
        case 5:                                                        // 58
          status = '已完成';                                              // 59
          break;                                                       // 60
        case 8:                                                        // 60
          status = '维权中';                                              // 62
          break;                                                       // 63
        default:                                                       // 63
          status = '全部状态';                                             // 65
          break;                                                       // 66
      }                                                                // 66
    }                                                                  //
    return status;                                                     // 69
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=wxorders.js.map
