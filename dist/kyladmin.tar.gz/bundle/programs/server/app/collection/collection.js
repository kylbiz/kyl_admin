(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// collection/collection.js                                            //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
                                                                       //
User = Meteor.users;                                                   // 2
                                                                       //
Orders = new Meteor.Collection('Orders');                              // 4
                                                                       //
Business = new Meteor.Collection('Business');                          // 6
                                                                       //
Business1 = new Meteor.Collection('Business1');                        // 8
                                                                       //
ProgressTemple = new Meteor.Collection('ProgressTemple');              // 10
                                                                       //
BusinessTypeLists = new Meteor.Collection('BusinessTypeLists');        // 12
                                                                       //
RegistrationLists = new Meteor.Collection("RegistrationLists");        // 14
                                                                       //
HandleResults = new Meteor.Collection("HandleResults");                // 16
                                                                       //
DocNum = new Meteor.Collection("DocNum");                              // 18
                                                                       //
WeChatInfo = new Meteor.Collection('wechatinfo');                      // 20
                                                                       //
WeChatShopGoods = new Meteor.Collection('WeChatShopGoods');            // 22
                                                                       //
PayLogs = new Meteor.Collection('PayLogs');                            // 24
                                                                       //
Date.prototype.Format = function (fmt) {                               // 27
  //author: meizz                                                      //
  var o = {                                                            // 28
    "M+": this.getMonth() + 1, //月份                                    // 29
    "d+": this.getDate(), //日                                          // 30
    "h+": this.getHours(), //小时                                        // 31
    "m+": this.getMinutes(), //分                                       // 32
    "s+": this.getSeconds(), //秒                                       // 33
    "q+": Math.floor((this.getMonth() + 3) / 3), //季度                  // 34
    "S": this.getMilliseconds() //毫秒                                   // 35
  };                                                                   //
  if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
  for (var k in babelHelpers.sanitizeForInObject(o)) if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
  return fmt;                                                          // 40
};                                                                     //
                                                                       //
Orders.helpers({                                                       // 44
  // payOrderId: function () {                                         //
  //   if (this.payed) {                                               //
  //     var openid = this.openid;                                     //
  //     var host = this.host;                                         //
  //     var payLog = PayLogs.findOne({openid: openid}) || {};         //
                                                                       //
  //     payOrderId = '';                                              //
  //     if (host == "KYLPC") {                                        //
  //       // payOrderId = payLog.                                     //
  //     } else if (host == "KYLWX") {                                 //
                                                                       //
  //     } else if (host == "KYLWAP") {                                //
                                                                       //
  //     }                                                             //
  //     return payOrderId;                                            //
  //   }                                                               //
  // },                                                                //
  openidL: function () {                                               // 62
    var host = this.host;                                              // 63
    var payHost = ({                                                   // 64
      'KYLPC': 'PC端支付宝支付',                                             // 65
      'KYLWX': '微信支付',                                                 // 66
      'KYLWAP': '移动端支付宝支付'                                             // 67
    })[host] || "未知渠道";                                                //
                                                                       //
    var openid = this.openid;                                          // 70
    var payLog = PayLogs.findOne({ openid: openid }) || {};            // 71
    channelPayOrder = "未知";                                            // 72
    if (payLog) {                                                      // 73
      channelPayOrder = ({                                             // 74
        'KYLPC': function () {                                         // 75
          var payInfos = payLog.payInfos || {};                        // 76
          if (!payInfos.messageDetail) {                               // 77
            // console.log('payLog', host, openid, payInfos);          //
            return "未知";                                               // 79
          }                                                            //
          return payInfos.messageDetail.trade_no || '未知';              // 81
        },                                                             //
        'KYLWX': function () {                                         // 83
          var wxpayInfos = payLog.wxpayInfos || payLog.paySuccessInfo || {};
          return wxpayInfos.transaction_id || wxpayInfos.transaction_no || '未知';
        },                                                             //
        'KYLWAP': function () {                                        // 87
          var paySuccessInfo = payLog.paySuccessInfo || {};            // 88
          return paySuccessInfo.transaction_no || '未知';                // 89
        }                                                              //
      })[host]() || "未知";                                              //
    }                                                                  //
                                                                       //
    return payHost + '-' + this.openid + "<br/>" + " 开业啦订单编号: " + this.orderId + "<br/>" + " 支付渠道方单号: " + channelPayOrder + "<br/>" + "<i><b> 备注信息: </b></i>" + (this.remark || '无');
  },                                                                   //
  payChannel: function () {                                            // 99
    return ({ 'KYLPC': 'PC端支付宝', 'KYLWAP': '移动端支付宝', 'KYLWX': '微信' })[this.host] || "未知";
  },                                                                   //
  createTimeL: function () {                                           // 102
    if (this.createTime) {                                             // 103
      return moment(this.createTime).format('YYYY-MM-DD HH:mm');       // 104
      // var createTimeL = this.createTime;                            //
      // var year = createTimeL.getFullYear();                         //
      // var month = createTimeL.getMonth() + 1;                       //
      // var date= createTimeL.getDate();                              //
      // var hours = createTimeL.getHours();                           //
      // var minutes = createTimeL.getMinutes();                       //
      // var createTime =  year+ '-' +  month +'-' + date + ' ' + hours + ':' + minutes;
      // return createTime;                                            //
      // return moment(this.createTime).format("YYYY年MM月DD日 H:mm");    //
    } else {                                                           //
        return '未知';                                                   // 115
      }                                                                //
  },                                                                   //
  payedTimeL: function () {                                            // 118
    if (this.payedTime) {                                              // 119
      return moment(this.payedTime).format('YYYY-MM-DD HH:mm');        // 120
    }                                                                  //
    return null;                                                       // 122
  },                                                                   //
  productName: function () {                                           // 124
    var productName = '';                                              // 125
    if (this.host == 'KYLWAP' || this.host == 'KYLWX') {               // 126
      var productInfo = this.servicesNameList[0];                      // 127
      productName = productInfo.zhDes || productInfo.label || productInfo.name;
    } else {                                                           //
      productName = this.servicesNameList[0].name;                     // 130
    }                                                                  //
    return productName || '未知';                                        // 132
  },                                                                   //
                                                                       //
  businessScopeL: function () {                                        // 135
    if (this.businessScope) {                                          // 136
      return this.businessScope.toString();                            // 137
    } else {                                                           //
      return '';                                                       // 139
    }                                                                  //
  },                                                                   //
  companyNameL: function () {                                          // 142
    if (this.companyName && this.companyName.mainName) {               // 143
      var mainName = this.companyName.mainName || "";                  // 144
      var industrySmall = this.industrySmall || "";                    // 145
      return mainName + '（上海）' + industrySmall + '有限公司';               // 146
    }                                                                  //
    return "";                                                         // 148
  },                                                                   //
  alternativeName: function () {                                       // 150
    if (this.companyName) {                                            // 151
      var companyName = '';                                            // 152
      if (this.companyName.alternativeName1) {                         // 153
        companyName += this.companyName.alternativeName1;              // 154
      };                                                               //
      if (this.companyName.alternativeName2) {                         // 156
        companyName += ',' + this.companyName.alternativeName2;        // 157
      };                                                               //
      if (this.companyName.alternativeName3) {                         // 159
        companyName += ',' + this.companyName.alternativeName3;        // 160
      };                                                               //
      if (this.companyName.alternativeName4) {                         // 162
        companyName += ',' + this.companyName.alternativeName4;        // 163
      }                                                                //
      return companyName;                                              // 165
    }                                                                  //
  },                                                                   //
  displayHolders: function () {                                        // 168
    if (this.holders) {                                                // 169
      var holders = this.holders;                                      // 170
      var displayHolders = [];                                         // 171
      if (holders && holders.length <= 3) {                            // 172
        displayHolders = holders;                                      // 173
        return displayHolders;                                         // 174
      } else if (holders && holders.length > 3) {                      //
        displayHolders.push(holders[0]);                               // 176
        displayHolders.push(holders[1]);                               // 177
        return displayHolders;                                         // 178
      } else {                                                         //
        return displayHolders;                                         // 180
      }                                                                //
    }                                                                  //
  },                                                                   //
  hideHolders: function () {                                           // 184
    if (this.holders) {                                                // 185
      var holders = this.holders;                                      // 186
      var hideHolders = [];                                            // 187
      if (holders && holders.length <= 3) {                            // 188
        hideHolders = holders;                                         // 189
        return [];                                                     // 190
      } else if (holders && holders.length > 3) {                      //
        // hideHolders.push(holders[0]);                               //
        // hideHolders.push(holders[1]);                               //
        holders.shift();                                               // 194
        holders.shift();                                               // 195
        hideHolders = holders;                                         // 196
        return hideHolders;                                            // 197
      } else {                                                         //
        return [];                                                     // 199
      }                                                                //
    }                                                                  //
  },                                                                   //
  user: function () {                                                  // 203
    if (this.userId) {                                                 // 204
      var userId = this.userId;                                        // 205
      Meteor.subscribe('getUser', userId);                             // 206
      return User.findOne({ _id: userId });                            // 207
    }                                                                  //
  },                                                                   //
  username: function () {                                              // 210
    if (this.userId) {                                                 // 211
      var userId = this.userId;                                        // 212
      Meteor.subscribe('getUser', userId);                             // 213
      var user = User.findOne({ _id: userId });                        // 214
      if (user && user.username) {                                     // 215
        return user.username;                                          // 216
      } else {                                                         //
        return '';                                                     // 218
      }                                                                //
    }                                                                  //
  },                                                                   //
  receiverName: function () {                                          // 222
    if (this.addressInfo && this.addressInfo.receiver) {               // 223
      return this.addressInfo.receiver;                                // 224
    } else {                                                           //
      return "";                                                       // 226
    }                                                                  //
  },                                                                   //
  receiverPhone: function () {                                         // 229
    if (this.addressInfo && this.addressInfo.phone) {                  // 230
      return this.addressInfo.phone;                                   // 231
    } else {                                                           //
      return "";                                                       // 233
    }                                                                  //
  },                                                                   //
  "orderHost": function () {                                           // 236
    if (this.host) {                                                   // 237
      if (this.host === "KYLWX") {                                     // 238
        return "新版微信";                                                 // 239
      } else if (this.host === "KYLPC") {                              //
        return "官网";                                                   // 241
      } else if (this.host === "KYLWAP") {                             //
        return "移动端";                                                  // 243
      } else {                                                         //
        return this.host;                                              // 245
      }                                                                //
    } else {                                                           //
      return "未知";                                                     // 248
    }                                                                  //
  },                                                                   //
  "zone": function () {                                                // 251
    if (this.servicesNameList && this.typeNameFlag === "registration") {
      var nameList = this.servicesNameList[0];                         // 253
      if (nameList.hasOwnProperty("zone")) {                           // 254
        return nameList.zone;                                          // 255
      } else {                                                         //
        var name = nameList.name;                                      // 257
        var zone = name.slice(name.lastIndexOf("[") + 1, name.lastIndexOf("]"));
        return zone || "";                                             // 259
      }                                                                //
    } else {                                                           //
      return "";                                                       // 262
    }                                                                  //
  },                                                                   //
  "holdernum": function () {                                           // 265
    if (this.holders) {                                                // 266
      return this.holders.length || 0;                                 // 267
    } else {                                                           //
      return 0;                                                        // 269
    }                                                                  //
  },                                                                   //
  isTest: function () {                                                // 272
    if (this.username) {                                               // 273
      var userId = this.userId;                                        // 274
      // Meteor.subscribe('getUser', userId);                          //
      var user = User.findOne({ _id: userId });                        // 276
      if (user && user.username) {                                     // 277
        if (username === "15618871296" || username === "18521595051") {
          return true;                                                 // 279
        } else {                                                       //
          return false;                                                // 281
        }                                                              //
      } else {                                                         //
        return false;                                                  // 284
      }                                                                //
    } else {                                                           //
      return false;                                                    // 287
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.users.helpers({                                                 // 293
  time: function () {                                                  // 294
    return this.createdAt.Format("yyyy-MM-dd hh:mm");                  // 295
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=collection.js.map
