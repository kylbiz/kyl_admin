(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// collection/collection.js                                            //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
                                                                       //
User = Meteor.users;                                                   // 2
                                                                       //
Orders = new Meteor.Collection('Orders');                              // 4
                                                                       //
Business = new Meteor.Collection('Business');                          // 6
                                                                       //
Business1 = new Meteor.Collection('Business1');                        // 8
                                                                       //
ProgressTemple = new Meteor.Collection('ProgressTemple');              // 10
                                                                       //
BusinessTypeLists = new Meteor.Collection('BusinessTypeLists');        // 12
                                                                       //
RegistrationLists = new Meteor.Collection("RegistrationLists");        // 14
                                                                       //
HandleResults = new Meteor.Collection("HandleResults");                // 16
                                                                       //
DocNum = new Meteor.Collection("DocNum");                              // 18
                                                                       //
WeChatInfo = new Meteor.Collection('wechatinfo');                      // 20
                                                                       //
WeChatShopGoods = new Meteor.Collection('WeChatShopGoods');            // 22
                                                                       //
Date.prototype.Format = function (fmt) {                               // 24
  //author: meizz                                                      //
  var o = {                                                            // 25
    "M+": this.getMonth() + 1, //月份                                    // 26
    "d+": this.getDate(), //日                                          // 27
    "h+": this.getHours(), //小时                                        // 28
    "m+": this.getMinutes(), //分                                       // 29
    "s+": this.getSeconds(), //秒                                       // 30
    "q+": Math.floor((this.getMonth() + 3) / 3), //季度                  // 31
    "S": this.getMilliseconds() //毫秒                                   // 32
  };                                                                   //
  if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
  for (var k in babelHelpers.sanitizeForInObject(o)) if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
  return fmt;                                                          // 37
};                                                                     //
                                                                       //
Orders.helpers({                                                       // 41
  createTimeL: function () {                                           // 42
    if (this.createTime) {                                             // 43
      return moment(this.createTime).format('YYYY-MM-DD HH:mm');       // 44
      // var createTimeL = this.createTime;                            //
      // var year = createTimeL.getFullYear();                         //
      // var month = createTimeL.getMonth() + 1;                       //
      // var date= createTimeL.getDate();                              //
      // var hours = createTimeL.getHours();                           //
      // var minutes = createTimeL.getMinutes();                       //
      // var createTime =  year+ '-' +  month +'-' + date + ' ' + hours + ':' + minutes;
      // return createTime;                                            //
      // return moment(this.createTime).format("YYYY年MM月DD日 H:mm");    //
    } else {                                                           //
        return '未知';                                                   // 55
      }                                                                //
  },                                                                   //
  payedTimeL: function () {                                            // 58
    if (this.payedTime) {                                              // 59
      return moment(this.payedTime).format('YYYY-MM-DD HH:mm');        // 60
    }                                                                  //
    return '未知';                                                       // 62
  },                                                                   //
  productName: function () {                                           // 64
    var productName = '';                                              // 65
    if (this.host == 'KYLWAP' || this.host == 'KYLWX') {               // 66
      var productInfo = this.servicesNameList[0];                      // 67
      productName = productInfo.zhDes || productInfo.label || productInfo.name;
    } else {                                                           //
      productName = this.servicesNameList[0].name;                     // 70
    }                                                                  //
    return productName || '未知';                                        // 72
  },                                                                   //
                                                                       //
  businessScopeL: function () {                                        // 75
    if (this.businessScope) {                                          // 76
      return this.businessScope.toString();                            // 77
    } else {                                                           //
      return '';                                                       // 79
    }                                                                  //
  },                                                                   //
  companyNameL: function () {                                          // 82
    if (this.companyName && this.companyName.mainName) {               // 83
      var mainName = this.companyName.mainName;                        // 84
      var industrySmall = this.industrySmall;                          // 85
      return mainName;                                                 // 86
    }                                                                  //
  },                                                                   //
  alternativeName: function () {                                       // 89
    if (this.companyName) {                                            // 90
      var companyName = '';                                            // 91
      if (this.companyName.alternativeName1) {                         // 92
        companyName += this.companyName.alternativeName1;              // 93
      };                                                               //
      if (this.companyName.alternativeName2) {                         // 95
        companyName += ',' + this.companyName.alternativeName2;        // 96
      };                                                               //
      if (this.companyName.alternativeName3) {                         // 98
        companyName += ',' + this.companyName.alternativeName3;        // 99
      };                                                               //
      if (this.companyName.alternativeName4) {                         // 101
        companyName += ',' + this.companyName.alternativeName4;        // 102
      }                                                                //
      return companyName;                                              // 104
    }                                                                  //
  },                                                                   //
  displayHolders: function () {                                        // 107
    if (this.holders) {                                                // 108
      var holders = this.holders;                                      // 109
      var displayHolders = [];                                         // 110
      if (holders && holders.length <= 3) {                            // 111
        displayHolders = holders;                                      // 112
        return displayHolders;                                         // 113
      } else if (holders && holders.length > 3) {                      //
        displayHolders.push(holders[0]);                               // 115
        displayHolders.push(holders[1]);                               // 116
        return displayHolders;                                         // 117
      } else {                                                         //
        return displayHolders;                                         // 119
      }                                                                //
    }                                                                  //
  },                                                                   //
  hideHolders: function () {                                           // 123
    if (this.holders) {                                                // 124
      var holders = this.holders;                                      // 125
      var hideHolders = [];                                            // 126
      if (holders && holders.length <= 3) {                            // 127
        hideHolders = holders;                                         // 128
        return [];                                                     // 129
      } else if (holders && holders.length > 3) {                      //
        // hideHolders.push(holders[0]);                               //
        // hideHolders.push(holders[1]);                               //
        holders.shift();                                               // 133
        holders.shift();                                               // 134
        hideHolders = holders;                                         // 135
        return hideHolders;                                            // 136
      } else {                                                         //
        return [];                                                     // 138
      }                                                                //
    }                                                                  //
  },                                                                   //
  user: function () {                                                  // 142
    if (this.userId) {                                                 // 143
      var userId = this.userId;                                        // 144
      Meteor.subscribe('getUser', userId);                             // 145
      return User.findOne({ _id: userId });                            // 146
    }                                                                  //
  },                                                                   //
  username: function () {                                              // 149
    if (this.userId) {                                                 // 150
      var userId = this.userId;                                        // 151
      Meteor.subscribe('getUser', userId);                             // 152
      var user = User.findOne({ _id: userId });                        // 153
      if (user && user.username) {                                     // 154
        return user.username;                                          // 155
      } else {                                                         //
        return '';                                                     // 157
      }                                                                //
    }                                                                  //
  },                                                                   //
  receiverName: function () {                                          // 161
    if (this.addressInfo && this.addressInfo.receiver) {               // 162
      return this.addressInfo.receiver;                                // 163
    } else {                                                           //
      return "";                                                       // 165
    }                                                                  //
  },                                                                   //
  receiverPhone: function () {                                         // 168
    if (this.addressInfo && this.addressInfo.phone) {                  // 169
      return this.addressInfo.phone;                                   // 170
    } else {                                                           //
      return "";                                                       // 172
    }                                                                  //
  },                                                                   //
  "orderHost": function () {                                           // 175
    if (this.host) {                                                   // 176
      if (this.host === "KYLWX") {                                     // 177
        return "新版微信";                                                 // 178
      } else if (this.host === "KYLPC") {                              //
        return "官网";                                                   // 180
      } else if (this.host === "KYLWAP") {                             //
        return "移动端";                                                  // 182
      } else {                                                         //
        return this.host;                                              // 184
      }                                                                //
    } else {                                                           //
      return "未知";                                                     // 187
    }                                                                  //
  },                                                                   //
  "zone": function () {                                                // 190
    if (this.servicesNameList && this.typeNameFlag === "registration") {
      var nameList = this.servicesNameList[0];                         // 192
      if (nameList.hasOwnProperty("zone")) {                           // 193
        return nameList.zone;                                          // 194
      } else {                                                         //
        var name = nameList.name;                                      // 196
        var zone = name.slice(name.lastIndexOf("[") + 1, name.lastIndexOf("]"));
        return zone || "";                                             // 198
      }                                                                //
    } else {                                                           //
      return "";                                                       // 201
    }                                                                  //
  },                                                                   //
  "holdernum": function () {                                           // 204
    if (this.holders) {                                                // 205
      return this.holders.length || 0;                                 // 206
    } else {                                                           //
      return 0;                                                        // 208
    }                                                                  //
  },                                                                   //
  isTest: function () {                                                // 211
    if (this.username) {                                               // 212
      var userId = this.userId;                                        // 213
      // Meteor.subscribe('getUser', userId);                          //
      var user = User.findOne({ _id: userId });                        // 215
      if (user && user.username) {                                     // 216
        if (username === "15618871296" || username === "18521595051") {
          return true;                                                 // 218
        } else {                                                       //
          return false;                                                // 220
        }                                                              //
      } else {                                                         //
        return false;                                                  // 223
      }                                                                //
    } else {                                                           //
      return false;                                                    // 226
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.users.helpers({                                                 // 232
  time: function () {                                                  // 233
    return this.createdAt.Format("yyyy-MM-dd hh:mm");                  // 234
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=collection.js.map
