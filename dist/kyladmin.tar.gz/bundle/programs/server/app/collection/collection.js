(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// collection/collection.js                                            //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
                                                                       //
User = Meteor.users;                                                   // 2
                                                                       //
Orders = new Meteor.Collection('Orders');                              // 4
                                                                       //
Business = new Meteor.Collection('Business');                          // 6
                                                                       //
Business1 = new Meteor.Collection('Business1');                        // 8
                                                                       //
ProgressTemple = new Meteor.Collection('ProgressTemple');              // 10
                                                                       //
BusinessTypeLists = new Meteor.Collection('BusinessTypeLists');        // 12
                                                                       //
RegistrationLists = new Meteor.Collection("RegistrationLists");        // 14
                                                                       //
HandleResults = new Meteor.Collection("HandleResults");                // 16
                                                                       //
DocNum = new Meteor.Collection("DocNum");                              // 18
                                                                       //
WeChatInfo = new Meteor.Collection('wechatinfo');                      // 20
                                                                       //
WeChatShopGoods = new Meteor.Collection('WeChatShopGoods');            // 22
                                                                       //
PayLogs = new Meteor.Collection('PayLogs');                            // 24
                                                                       //
Date.prototype.Format = function (fmt) {                               // 27
  //author: meizz                                                      //
  var o = {                                                            // 28
    "M+": this.getMonth() + 1, //月份                                    // 29
    "d+": this.getDate(), //日                                          // 30
    "h+": this.getHours(), //小时                                        // 31
    "m+": this.getMinutes(), //分                                       // 32
    "s+": this.getSeconds(), //秒                                       // 33
    "q+": Math.floor((this.getMonth() + 3) / 3), //季度                  // 34
    "S": this.getMilliseconds() //毫秒                                   // 35
  };                                                                   //
  if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
  for (var k in babelHelpers.sanitizeForInObject(o)) if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
  return fmt;                                                          // 40
};                                                                     //
                                                                       //
Orders.helpers({                                                       // 44
  // payOrderId: function () {                                         //
  //   if (this.payed) {                                               //
  //     var openid = this.openid;                                     //
  //     var host = this.host;                                         //
  //     var payLog = PayLogs.findOne({openid: openid}) || {};         //
                                                                       //
  //     payOrderId = '';                                              //
  //     if (host == "KYLPC") {                                        //
  //       // payOrderId = payLog.                                     //
  //     } else if (host == "KYLWX") {                                 //
                                                                       //
  //     } else if (host == "KYLWAP") {                                //
                                                                       //
  //     }                                                             //
  //     return payOrderId;                                            //
  //   }                                                               //
  // },                                                                //
  openidL: function () {                                               // 62
    var host = this.host;                                              // 63
    var payHost = ({                                                   // 64
      'KYLPC': 'PC端支付宝支付',                                             // 65
      'KYLWX': '微信支付',                                                 // 66
      'KYLWAP': '移动端支付宝支付'                                             // 67
    })[host] || "未知渠道";                                                //
                                                                       //
    var openid = this.openid;                                          // 70
    var payLog = PayLogs.findOne({ openid: openid }) || {};            // 71
    channelPayOrder = "未知";                                            // 72
    if (payLog) {                                                      // 73
      channelPayOrder = ({                                             // 74
        'KYLPC': function () {                                         // 75
          var payInfos = payLog.payInfos || {};                        // 76
          if (!payInfos.messageDetail) {                               // 77
            // console.log('payLog', host, openid, payInfos);          //
            return "未知";                                               // 79
          }                                                            //
          return payInfos.messageDetail.trade_no || '未知';              // 81
        },                                                             //
        'KYLWX': function () {                                         // 83
          var wxpayInfos = payLog.wxpayInfos || payLog.paySuccessInfo || {};
          return wxpayInfos.transaction_id || wxpayInfos.transaction_no || '未知';
        },                                                             //
        'KYLWAP': function () {                                        // 87
          var paySuccessInfo = payLog.paySuccessInfo || {};            // 88
          return paySuccessInfo.transaction_no || '未知';                // 89
        }                                                              //
      })[host]() || "未知";                                              //
    }                                                                  //
                                                                       //
    return payHost + '-' + this.openid + "<br/>" + " 开业啦订单编号: " + this.orderId + "<br/>" + " 支付渠道方单号: " + channelPayOrder;
  },                                                                   //
  createTimeL: function () {                                           // 98
    if (this.createTime) {                                             // 99
      return moment(this.createTime).format('YYYY-MM-DD HH:mm');       // 100
      // var createTimeL = this.createTime;                            //
      // var year = createTimeL.getFullYear();                         //
      // var month = createTimeL.getMonth() + 1;                       //
      // var date= createTimeL.getDate();                              //
      // var hours = createTimeL.getHours();                           //
      // var minutes = createTimeL.getMinutes();                       //
      // var createTime =  year+ '-' +  month +'-' + date + ' ' + hours + ':' + minutes;
      // return createTime;                                            //
      // return moment(this.createTime).format("YYYY年MM月DD日 H:mm");    //
    } else {                                                           //
        return '未知';                                                   // 111
      }                                                                //
  },                                                                   //
  payedTimeL: function () {                                            // 114
    if (this.payedTime) {                                              // 115
      return moment(this.payedTime).format('YYYY-MM-DD HH:mm');        // 116
    }                                                                  //
    return null;                                                       // 118
  },                                                                   //
  productName: function () {                                           // 120
    var productName = '';                                              // 121
    if (this.host == 'KYLWAP' || this.host == 'KYLWX') {               // 122
      var productInfo = this.servicesNameList[0];                      // 123
      productName = productInfo.zhDes || productInfo.label || productInfo.name;
    } else {                                                           //
      productName = this.servicesNameList[0].name;                     // 126
    }                                                                  //
    return productName || '未知';                                        // 128
  },                                                                   //
                                                                       //
  businessScopeL: function () {                                        // 131
    if (this.businessScope) {                                          // 132
      return this.businessScope.toString();                            // 133
    } else {                                                           //
      return '';                                                       // 135
    }                                                                  //
  },                                                                   //
  companyNameL: function () {                                          // 138
    if (this.companyName && this.companyName.mainName) {               // 139
      var mainName = this.companyName.mainName || "";                  // 140
      var industrySmall = this.industrySmall || "";                    // 141
      return mainName + '（上海）' + industrySmall + '有限公司';               // 142
    }                                                                  //
    return "";                                                         // 144
  },                                                                   //
  alternativeName: function () {                                       // 146
    if (this.companyName) {                                            // 147
      var companyName = '';                                            // 148
      if (this.companyName.alternativeName1) {                         // 149
        companyName += this.companyName.alternativeName1;              // 150
      };                                                               //
      if (this.companyName.alternativeName2) {                         // 152
        companyName += ',' + this.companyName.alternativeName2;        // 153
      };                                                               //
      if (this.companyName.alternativeName3) {                         // 155
        companyName += ',' + this.companyName.alternativeName3;        // 156
      };                                                               //
      if (this.companyName.alternativeName4) {                         // 158
        companyName += ',' + this.companyName.alternativeName4;        // 159
      }                                                                //
      return companyName;                                              // 161
    }                                                                  //
  },                                                                   //
  displayHolders: function () {                                        // 164
    if (this.holders) {                                                // 165
      var holders = this.holders;                                      // 166
      var displayHolders = [];                                         // 167
      if (holders && holders.length <= 3) {                            // 168
        displayHolders = holders;                                      // 169
        return displayHolders;                                         // 170
      } else if (holders && holders.length > 3) {                      //
        displayHolders.push(holders[0]);                               // 172
        displayHolders.push(holders[1]);                               // 173
        return displayHolders;                                         // 174
      } else {                                                         //
        return displayHolders;                                         // 176
      }                                                                //
    }                                                                  //
  },                                                                   //
  hideHolders: function () {                                           // 180
    if (this.holders) {                                                // 181
      var holders = this.holders;                                      // 182
      var hideHolders = [];                                            // 183
      if (holders && holders.length <= 3) {                            // 184
        hideHolders = holders;                                         // 185
        return [];                                                     // 186
      } else if (holders && holders.length > 3) {                      //
        // hideHolders.push(holders[0]);                               //
        // hideHolders.push(holders[1]);                               //
        holders.shift();                                               // 190
        holders.shift();                                               // 191
        hideHolders = holders;                                         // 192
        return hideHolders;                                            // 193
      } else {                                                         //
        return [];                                                     // 195
      }                                                                //
    }                                                                  //
  },                                                                   //
  user: function () {                                                  // 199
    if (this.userId) {                                                 // 200
      var userId = this.userId;                                        // 201
      Meteor.subscribe('getUser', userId);                             // 202
      return User.findOne({ _id: userId });                            // 203
    }                                                                  //
  },                                                                   //
  username: function () {                                              // 206
    if (this.userId) {                                                 // 207
      var userId = this.userId;                                        // 208
      Meteor.subscribe('getUser', userId);                             // 209
      var user = User.findOne({ _id: userId });                        // 210
      if (user && user.username) {                                     // 211
        return user.username;                                          // 212
      } else {                                                         //
        return '';                                                     // 214
      }                                                                //
    }                                                                  //
  },                                                                   //
  receiverName: function () {                                          // 218
    if (this.addressInfo && this.addressInfo.receiver) {               // 219
      return this.addressInfo.receiver;                                // 220
    } else {                                                           //
      return "";                                                       // 222
    }                                                                  //
  },                                                                   //
  receiverPhone: function () {                                         // 225
    if (this.addressInfo && this.addressInfo.phone) {                  // 226
      return this.addressInfo.phone;                                   // 227
    } else {                                                           //
      return "";                                                       // 229
    }                                                                  //
  },                                                                   //
  "orderHost": function () {                                           // 232
    if (this.host) {                                                   // 233
      if (this.host === "KYLWX") {                                     // 234
        return "新版微信";                                                 // 235
      } else if (this.host === "KYLPC") {                              //
        return "官网";                                                   // 237
      } else if (this.host === "KYLWAP") {                             //
        return "移动端";                                                  // 239
      } else {                                                         //
        return this.host;                                              // 241
      }                                                                //
    } else {                                                           //
      return "未知";                                                     // 244
    }                                                                  //
  },                                                                   //
  "zone": function () {                                                // 247
    if (this.servicesNameList && this.typeNameFlag === "registration") {
      var nameList = this.servicesNameList[0];                         // 249
      if (nameList.hasOwnProperty("zone")) {                           // 250
        return nameList.zone;                                          // 251
      } else {                                                         //
        var name = nameList.name;                                      // 253
        var zone = name.slice(name.lastIndexOf("[") + 1, name.lastIndexOf("]"));
        return zone || "";                                             // 255
      }                                                                //
    } else {                                                           //
      return "";                                                       // 258
    }                                                                  //
  },                                                                   //
  "holdernum": function () {                                           // 261
    if (this.holders) {                                                // 262
      return this.holders.length || 0;                                 // 263
    } else {                                                           //
      return 0;                                                        // 265
    }                                                                  //
  },                                                                   //
  isTest: function () {                                                // 268
    if (this.username) {                                               // 269
      var userId = this.userId;                                        // 270
      // Meteor.subscribe('getUser', userId);                          //
      var user = User.findOne({ _id: userId });                        // 272
      if (user && user.username) {                                     // 273
        if (username === "15618871296" || username === "18521595051") {
          return true;                                                 // 275
        } else {                                                       //
          return false;                                                // 277
        }                                                              //
      } else {                                                         //
        return false;                                                  // 280
      }                                                                //
    } else {                                                           //
      return false;                                                    // 283
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.users.helpers({                                                 // 289
  time: function () {                                                  // 290
    return this.createdAt.Format("yyyy-MM-dd hh:mm");                  // 291
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=collection.js.map
