(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// collection/collection.js                                            //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
                                                                       //
User = Meteor.users;                                                   // 2
                                                                       //
Orders = new Meteor.Collection('Orders');                              // 4
                                                                       //
Business = new Meteor.Collection('Business');                          // 6
                                                                       //
Business1 = new Meteor.Collection('Business1');                        // 8
                                                                       //
ProgressTemple = new Meteor.Collection('ProgressTemple');              // 10
                                                                       //
BusinessTypeLists = new Meteor.Collection('BusinessTypeLists');        // 12
                                                                       //
RegistrationLists = new Meteor.Collection("RegistrationLists");        // 14
                                                                       //
HandleResults = new Meteor.Collection("HandleResults");                // 16
                                                                       //
DocNum = new Meteor.Collection("DocNum");                              // 18
                                                                       //
WeChatInfo = new Meteor.Collection('wechatinfo');                      // 20
                                                                       //
WeChatShopGoods = new Meteor.Collection('WeChatShopGoods');            // 22
                                                                       //
Date.prototype.Format = function (fmt) {                               // 24
  //author: meizz                                                      //
  var o = {                                                            // 25
    "M+": this.getMonth() + 1, //月份                                    // 26
    "d+": this.getDate(), //日                                          // 27
    "h+": this.getHours(), //小时                                        // 28
    "m+": this.getMinutes(), //分                                       // 29
    "s+": this.getSeconds(), //秒                                       // 30
    "q+": Math.floor((this.getMonth() + 3) / 3), //季度                  // 31
    "S": this.getMilliseconds() //毫秒                                   // 32
  };                                                                   //
  if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
  for (var k in babelHelpers.sanitizeForInObject(o)) if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
  return fmt;                                                          // 37
};                                                                     //
                                                                       //
Orders.helpers({                                                       // 41
  // payOrderId: function () {                                         //
  //   if (this.payed) {                                               //
  //     var openid = this.openid;                                     //
  //     var host = this.host;                                         //
  //     var payLog = PayLogs.findOne({openid: openid}) || {};         //
                                                                       //
  //     payOrderId = '';                                              //
  //     if (host == "KYLPC") {                                        //
  //       // payOrderId = payLog.                                     //
  //     } else if (host == "KYLWX") {                                 //
                                                                       //
  //     } else if (host == "KYLWAP") {                                //
                                                                       //
  //     }                                                             //
  //     return payOrderId;                                            //
  //   }                                                               //
  // },                                                                //
  openidL: function () {                                               // 59
    var host = this.host;                                              // 60
    var payHost = ({                                                   // 61
      'KYLPC': 'PC端支付宝支付',                                             // 62
      'KYLWX': '微信支付',                                                 // 63
      'KYLWAP': '移动端支付宝支付'                                             // 64
    })[host] || "未知渠道";                                                //
    return payHost + '-' + this.openid;                                // 66
  },                                                                   //
  createTimeL: function () {                                           // 68
    if (this.createTime) {                                             // 69
      return moment(this.createTime).format('YYYY-MM-DD HH:mm');       // 70
      // var createTimeL = this.createTime;                            //
      // var year = createTimeL.getFullYear();                         //
      // var month = createTimeL.getMonth() + 1;                       //
      // var date= createTimeL.getDate();                              //
      // var hours = createTimeL.getHours();                           //
      // var minutes = createTimeL.getMinutes();                       //
      // var createTime =  year+ '-' +  month +'-' + date + ' ' + hours + ':' + minutes;
      // return createTime;                                            //
      // return moment(this.createTime).format("YYYY年MM月DD日 H:mm");    //
    } else {                                                           //
        return '未知';                                                   // 81
      }                                                                //
  },                                                                   //
  payedTimeL: function () {                                            // 84
    if (this.payedTime) {                                              // 85
      return moment(this.payedTime).format('YYYY-MM-DD HH:mm');        // 86
    }                                                                  //
    return '未知';                                                       // 88
  },                                                                   //
  productName: function () {                                           // 90
    var productName = '';                                              // 91
    if (this.host == 'KYLWAP' || this.host == 'KYLWX') {               // 92
      var productInfo = this.servicesNameList[0];                      // 93
      productName = productInfo.zhDes || productInfo.label || productInfo.name;
    } else {                                                           //
      productName = this.servicesNameList[0].name;                     // 96
    }                                                                  //
    return productName || '未知';                                        // 98
  },                                                                   //
                                                                       //
  businessScopeL: function () {                                        // 101
    if (this.businessScope) {                                          // 102
      return this.businessScope.toString();                            // 103
    } else {                                                           //
      return '';                                                       // 105
    }                                                                  //
  },                                                                   //
  companyNameL: function () {                                          // 108
    if (this.companyName && this.companyName.mainName) {               // 109
      var mainName = this.companyName.mainName || "";                  // 110
      var industrySmall = this.industrySmall || "";                    // 111
      return mainName + '（上海）' + industrySmall + '有限公司';               // 112
    }                                                                  //
    return "";                                                         // 114
  },                                                                   //
  alternativeName: function () {                                       // 116
    if (this.companyName) {                                            // 117
      var companyName = '';                                            // 118
      if (this.companyName.alternativeName1) {                         // 119
        companyName += this.companyName.alternativeName1;              // 120
      };                                                               //
      if (this.companyName.alternativeName2) {                         // 122
        companyName += ',' + this.companyName.alternativeName2;        // 123
      };                                                               //
      if (this.companyName.alternativeName3) {                         // 125
        companyName += ',' + this.companyName.alternativeName3;        // 126
      };                                                               //
      if (this.companyName.alternativeName4) {                         // 128
        companyName += ',' + this.companyName.alternativeName4;        // 129
      }                                                                //
      return companyName;                                              // 131
    }                                                                  //
  },                                                                   //
  displayHolders: function () {                                        // 134
    if (this.holders) {                                                // 135
      var holders = this.holders;                                      // 136
      var displayHolders = [];                                         // 137
      if (holders && holders.length <= 3) {                            // 138
        displayHolders = holders;                                      // 139
        return displayHolders;                                         // 140
      } else if (holders && holders.length > 3) {                      //
        displayHolders.push(holders[0]);                               // 142
        displayHolders.push(holders[1]);                               // 143
        return displayHolders;                                         // 144
      } else {                                                         //
        return displayHolders;                                         // 146
      }                                                                //
    }                                                                  //
  },                                                                   //
  hideHolders: function () {                                           // 150
    if (this.holders) {                                                // 151
      var holders = this.holders;                                      // 152
      var hideHolders = [];                                            // 153
      if (holders && holders.length <= 3) {                            // 154
        hideHolders = holders;                                         // 155
        return [];                                                     // 156
      } else if (holders && holders.length > 3) {                      //
        // hideHolders.push(holders[0]);                               //
        // hideHolders.push(holders[1]);                               //
        holders.shift();                                               // 160
        holders.shift();                                               // 161
        hideHolders = holders;                                         // 162
        return hideHolders;                                            // 163
      } else {                                                         //
        return [];                                                     // 165
      }                                                                //
    }                                                                  //
  },                                                                   //
  user: function () {                                                  // 169
    if (this.userId) {                                                 // 170
      var userId = this.userId;                                        // 171
      Meteor.subscribe('getUser', userId);                             // 172
      return User.findOne({ _id: userId });                            // 173
    }                                                                  //
  },                                                                   //
  username: function () {                                              // 176
    if (this.userId) {                                                 // 177
      var userId = this.userId;                                        // 178
      Meteor.subscribe('getUser', userId);                             // 179
      var user = User.findOne({ _id: userId });                        // 180
      if (user && user.username) {                                     // 181
        return user.username;                                          // 182
      } else {                                                         //
        return '';                                                     // 184
      }                                                                //
    }                                                                  //
  },                                                                   //
  receiverName: function () {                                          // 188
    if (this.addressInfo && this.addressInfo.receiver) {               // 189
      return this.addressInfo.receiver;                                // 190
    } else {                                                           //
      return "";                                                       // 192
    }                                                                  //
  },                                                                   //
  receiverPhone: function () {                                         // 195
    if (this.addressInfo && this.addressInfo.phone) {                  // 196
      return this.addressInfo.phone;                                   // 197
    } else {                                                           //
      return "";                                                       // 199
    }                                                                  //
  },                                                                   //
  "orderHost": function () {                                           // 202
    if (this.host) {                                                   // 203
      if (this.host === "KYLWX") {                                     // 204
        return "新版微信";                                                 // 205
      } else if (this.host === "KYLPC") {                              //
        return "官网";                                                   // 207
      } else if (this.host === "KYLWAP") {                             //
        return "移动端";                                                  // 209
      } else {                                                         //
        return this.host;                                              // 211
      }                                                                //
    } else {                                                           //
      return "未知";                                                     // 214
    }                                                                  //
  },                                                                   //
  "zone": function () {                                                // 217
    if (this.servicesNameList && this.typeNameFlag === "registration") {
      var nameList = this.servicesNameList[0];                         // 219
      if (nameList.hasOwnProperty("zone")) {                           // 220
        return nameList.zone;                                          // 221
      } else {                                                         //
        var name = nameList.name;                                      // 223
        var zone = name.slice(name.lastIndexOf("[") + 1, name.lastIndexOf("]"));
        return zone || "";                                             // 225
      }                                                                //
    } else {                                                           //
      return "";                                                       // 228
    }                                                                  //
  },                                                                   //
  "holdernum": function () {                                           // 231
    if (this.holders) {                                                // 232
      return this.holders.length || 0;                                 // 233
    } else {                                                           //
      return 0;                                                        // 235
    }                                                                  //
  },                                                                   //
  isTest: function () {                                                // 238
    if (this.username) {                                               // 239
      var userId = this.userId;                                        // 240
      // Meteor.subscribe('getUser', userId);                          //
      var user = User.findOne({ _id: userId });                        // 242
      if (user && user.username) {                                     // 243
        if (username === "15618871296" || username === "18521595051") {
          return true;                                                 // 245
        } else {                                                       //
          return false;                                                // 247
        }                                                              //
      } else {                                                         //
        return false;                                                  // 250
      }                                                                //
    } else {                                                           //
      return false;                                                    // 253
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.users.helpers({                                                 // 259
  time: function () {                                                  // 260
    return this.createdAt.Format("yyyy-MM-dd hh:mm");                  // 261
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=collection.js.map
