(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// collection/collection.js                                            //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
                                                                       //
User = Meteor.users;                                                   // 2
                                                                       //
Orders = new Meteor.Collection('Orders');                              // 4
                                                                       //
Business = new Meteor.Collection('Business');                          // 6
                                                                       //
Business1 = new Meteor.Collection('Business1');                        // 8
                                                                       //
ProgressTemple = new Meteor.Collection('ProgressTemple');              // 10
                                                                       //
BusinessTypeLists = new Meteor.Collection('BusinessTypeLists');        // 12
                                                                       //
RegistrationLists = new Meteor.Collection("RegistrationLists");        // 14
                                                                       //
HandleResults = new Meteor.Collection("HandleResults");                // 16
                                                                       //
DocNum = new Meteor.Collection("DocNum");                              // 18
                                                                       //
WeChatInfo = new Meteor.Collection('wechatinfo');                      // 20
                                                                       //
WeChatShopGoods = new Meteor.Collection('WeChatShopGoods');            // 22
                                                                       //
PayLogs = new Meteor.Collection('PayLogs');                            // 24
                                                                       //
Date.prototype.Format = function (fmt) {                               // 27
  //author: meizz                                                      //
  var o = {                                                            // 28
    "M+": this.getMonth() + 1, //月份                                    // 29
    "d+": this.getDate(), //日                                          // 30
    "h+": this.getHours(), //小时                                        // 31
    "m+": this.getMinutes(), //分                                       // 32
    "s+": this.getSeconds(), //秒                                       // 33
    "q+": Math.floor((this.getMonth() + 3) / 3), //季度                  // 34
    "S": this.getMilliseconds() //毫秒                                   // 35
  };                                                                   //
  if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
  for (var k in babelHelpers.sanitizeForInObject(o)) if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
  return fmt;                                                          // 40
};                                                                     //
                                                                       //
Orders.helpers({                                                       // 44
  // payOrderId: function () {                                         //
  //   if (this.payed) {                                               //
  //     var openid = this.openid;                                     //
  //     var host = this.host;                                         //
  //     var payLog = PayLogs.findOne({openid: openid}) || {};         //
                                                                       //
  //     payOrderId = '';                                              //
  //     if (host == "KYLPC") {                                        //
  //       // payOrderId = payLog.                                     //
  //     } else if (host == "KYLWX") {                                 //
                                                                       //
  //     } else if (host == "KYLWAP") {                                //
                                                                       //
  //     }                                                             //
  //     return payOrderId;                                            //
  //   }                                                               //
  // },                                                                //
  openidL: function () {                                               // 62
    var host = this.host;                                              // 63
    var payHost = ({                                                   // 64
      'KYLPC': 'PC端支付宝支付',                                             // 65
      'KYLWX': '微信支付',                                                 // 66
      'KYLWAP': '移动端支付宝支付'                                             // 67
    })[host] || "未知渠道";                                                //
                                                                       //
    var openid = this.openid;                                          // 70
    var payLog = PayLogs.findOne({ openid: openid }) || {};            // 71
    channelPayOrder = "未知";                                            // 72
    if (payLog) {                                                      // 73
      channelPayOrder = ({                                             // 74
        'KYLPC': function () {                                         // 75
          var payInfos = payLog.payInfos || {};                        // 76
          if (!payInfos.messageDetail) {                               // 77
            // console.log('payLog', host, openid, payInfos);          //
            return "未知";                                               // 79
          }                                                            //
          return payInfos.messageDetail.trade_no || '未知';              // 81
        },                                                             //
        'KYLWX': function () {                                         // 83
          var wxpayInfos = payLog.wxpayInfos || payLog.paySuccessInfo || {};
          return wxpayInfos.transaction_id || wxpayInfos.transaction_no || '未知';
        },                                                             //
        'KYLWAP': function () {                                        // 87
          var paySuccessInfo = payLog.paySuccessInfo || {};            // 88
          return paySuccessInfo.transaction_no || '未知';                // 89
        }                                                              //
      })[host]() || "未知";                                              //
    }                                                                  //
                                                                       //
    return payHost + '-' + this.openid + "<br/>" + " 开业啦订单编号: " + this.orderId + "<br/>" + " 支付渠道方单号: " + channelPayOrder;
  },                                                                   //
  payChannel: function () {                                            // 98
    return ({ 'KYLPC': 'PC端支付宝', 'KYLWAP': '移动端支付宝', 'KYLWX': '微信' })[this.host] || "未知";
  },                                                                   //
  createTimeL: function () {                                           // 101
    if (this.createTime) {                                             // 102
      return moment(this.createTime).format('YYYY-MM-DD HH:mm');       // 103
      // var createTimeL = this.createTime;                            //
      // var year = createTimeL.getFullYear();                         //
      // var month = createTimeL.getMonth() + 1;                       //
      // var date= createTimeL.getDate();                              //
      // var hours = createTimeL.getHours();                           //
      // var minutes = createTimeL.getMinutes();                       //
      // var createTime =  year+ '-' +  month +'-' + date + ' ' + hours + ':' + minutes;
      // return createTime;                                            //
      // return moment(this.createTime).format("YYYY年MM月DD日 H:mm");    //
    } else {                                                           //
        return '未知';                                                   // 114
      }                                                                //
  },                                                                   //
  payedTimeL: function () {                                            // 117
    if (this.payedTime) {                                              // 118
      return moment(this.payedTime).format('YYYY-MM-DD HH:mm');        // 119
    }                                                                  //
    return null;                                                       // 121
  },                                                                   //
  productName: function () {                                           // 123
    var productName = '';                                              // 124
    if (this.host == 'KYLWAP' || this.host == 'KYLWX') {               // 125
      var productInfo = this.servicesNameList[0];                      // 126
      productName = productInfo.zhDes || productInfo.label || productInfo.name;
    } else {                                                           //
      productName = this.servicesNameList[0].name;                     // 129
    }                                                                  //
    return productName || '未知';                                        // 131
  },                                                                   //
                                                                       //
  businessScopeL: function () {                                        // 134
    if (this.businessScope) {                                          // 135
      return this.businessScope.toString();                            // 136
    } else {                                                           //
      return '';                                                       // 138
    }                                                                  //
  },                                                                   //
  companyNameL: function () {                                          // 141
    if (this.companyName && this.companyName.mainName) {               // 142
      var mainName = this.companyName.mainName || "";                  // 143
      var industrySmall = this.industrySmall || "";                    // 144
      return mainName + '（上海）' + industrySmall + '有限公司';               // 145
    }                                                                  //
    return "";                                                         // 147
  },                                                                   //
  alternativeName: function () {                                       // 149
    if (this.companyName) {                                            // 150
      var companyName = '';                                            // 151
      if (this.companyName.alternativeName1) {                         // 152
        companyName += this.companyName.alternativeName1;              // 153
      };                                                               //
      if (this.companyName.alternativeName2) {                         // 155
        companyName += ',' + this.companyName.alternativeName2;        // 156
      };                                                               //
      if (this.companyName.alternativeName3) {                         // 158
        companyName += ',' + this.companyName.alternativeName3;        // 159
      };                                                               //
      if (this.companyName.alternativeName4) {                         // 161
        companyName += ',' + this.companyName.alternativeName4;        // 162
      }                                                                //
      return companyName;                                              // 164
    }                                                                  //
  },                                                                   //
  displayHolders: function () {                                        // 167
    if (this.holders) {                                                // 168
      var holders = this.holders;                                      // 169
      var displayHolders = [];                                         // 170
      if (holders && holders.length <= 3) {                            // 171
        displayHolders = holders;                                      // 172
        return displayHolders;                                         // 173
      } else if (holders && holders.length > 3) {                      //
        displayHolders.push(holders[0]);                               // 175
        displayHolders.push(holders[1]);                               // 176
        return displayHolders;                                         // 177
      } else {                                                         //
        return displayHolders;                                         // 179
      }                                                                //
    }                                                                  //
  },                                                                   //
  hideHolders: function () {                                           // 183
    if (this.holders) {                                                // 184
      var holders = this.holders;                                      // 185
      var hideHolders = [];                                            // 186
      if (holders && holders.length <= 3) {                            // 187
        hideHolders = holders;                                         // 188
        return [];                                                     // 189
      } else if (holders && holders.length > 3) {                      //
        // hideHolders.push(holders[0]);                               //
        // hideHolders.push(holders[1]);                               //
        holders.shift();                                               // 193
        holders.shift();                                               // 194
        hideHolders = holders;                                         // 195
        return hideHolders;                                            // 196
      } else {                                                         //
        return [];                                                     // 198
      }                                                                //
    }                                                                  //
  },                                                                   //
  user: function () {                                                  // 202
    if (this.userId) {                                                 // 203
      var userId = this.userId;                                        // 204
      Meteor.subscribe('getUser', userId);                             // 205
      return User.findOne({ _id: userId });                            // 206
    }                                                                  //
  },                                                                   //
  username: function () {                                              // 209
    if (this.userId) {                                                 // 210
      var userId = this.userId;                                        // 211
      Meteor.subscribe('getUser', userId);                             // 212
      var user = User.findOne({ _id: userId });                        // 213
      if (user && user.username) {                                     // 214
        return user.username;                                          // 215
      } else {                                                         //
        return '';                                                     // 217
      }                                                                //
    }                                                                  //
  },                                                                   //
  receiverName: function () {                                          // 221
    if (this.addressInfo && this.addressInfo.receiver) {               // 222
      return this.addressInfo.receiver;                                // 223
    } else {                                                           //
      return "";                                                       // 225
    }                                                                  //
  },                                                                   //
  receiverPhone: function () {                                         // 228
    if (this.addressInfo && this.addressInfo.phone) {                  // 229
      return this.addressInfo.phone;                                   // 230
    } else {                                                           //
      return "";                                                       // 232
    }                                                                  //
  },                                                                   //
  "orderHost": function () {                                           // 235
    if (this.host) {                                                   // 236
      if (this.host === "KYLWX") {                                     // 237
        return "新版微信";                                                 // 238
      } else if (this.host === "KYLPC") {                              //
        return "官网";                                                   // 240
      } else if (this.host === "KYLWAP") {                             //
        return "移动端";                                                  // 242
      } else {                                                         //
        return this.host;                                              // 244
      }                                                                //
    } else {                                                           //
      return "未知";                                                     // 247
    }                                                                  //
  },                                                                   //
  "zone": function () {                                                // 250
    if (this.servicesNameList && this.typeNameFlag === "registration") {
      var nameList = this.servicesNameList[0];                         // 252
      if (nameList.hasOwnProperty("zone")) {                           // 253
        return nameList.zone;                                          // 254
      } else {                                                         //
        var name = nameList.name;                                      // 256
        var zone = name.slice(name.lastIndexOf("[") + 1, name.lastIndexOf("]"));
        return zone || "";                                             // 258
      }                                                                //
    } else {                                                           //
      return "";                                                       // 261
    }                                                                  //
  },                                                                   //
  "holdernum": function () {                                           // 264
    if (this.holders) {                                                // 265
      return this.holders.length || 0;                                 // 266
    } else {                                                           //
      return 0;                                                        // 268
    }                                                                  //
  },                                                                   //
  isTest: function () {                                                // 271
    if (this.username) {                                               // 272
      var userId = this.userId;                                        // 273
      // Meteor.subscribe('getUser', userId);                          //
      var user = User.findOne({ _id: userId });                        // 275
      if (user && user.username) {                                     // 276
        if (username === "15618871296" || username === "18521595051") {
          return true;                                                 // 278
        } else {                                                       //
          return false;                                                // 280
        }                                                              //
      } else {                                                         //
        return false;                                                  // 283
      }                                                                //
    } else {                                                           //
      return false;                                                    // 286
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.users.helpers({                                                 // 292
  time: function () {                                                  // 293
    return this.createdAt.Format("yyyy-MM-dd hh:mm");                  // 294
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=collection.js.map
