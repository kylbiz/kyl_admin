(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/clouds/template.js                                           //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
var querystring = Meteor.npmRequire('querystring');                    // 1
var requestUrl = 'http://192.168.0.100/docgen/';                       // 2
                                                                       //
function log(info) {                                                   // 5
	var len = arguments.length;                                           // 6
	console.log('------------------------------------');                  // 7
	for (var i = 0; i < len; i++) {                                       // 8
		console.log(arguments[i]);                                           // 9
	}                                                                     //
};                                                                     //
                                                                       //
Meteor.methods({                                                       // 14
	"GenerateCheTemplate": function (options) {                           // 15
		log("GenerateCheTemplate: Hi, I am called!");                        // 16
		if (!options || !options.hasOwnProperty("orderId") || !options.hasOwnProperty("uuid") || !options.hasOwnProperty("zone")) {
			log("GenerateCheTemplate: options illegal", options);               // 21
		} else {                                                             //
			var orderId = options.orderId;                                      // 23
			var uuid = options.uuid;                                            // 24
			var zone = options.zone;                                            // 25
                                                                       //
			var companyZipcode = '200082';                                      // 27
			switch (zone) {                                                     // 28
				case '虹口':                                                         // 29
					companyZipcode = '200082';                                        // 30
					break;                                                            // 31
				case '浦东':                                                         // 31
					companyZipcode = '201204';                                        // 33
					break;                                                            // 34
				default:                                                           // 34
					companyZipcode = '200082';                                        // 36
					break;                                                            // 37
			}                                                                   // 37
                                                                       //
			var order = Orders.findOne({ orderId: orderId });                   // 40
                                                                       //
			if (!order) {                                                       // 42
				log("GenerateTemplate: query order error");                        // 43
			} else {                                                            //
				var requests = HandleCheckOrder(order);                            // 45
                                                                       //
				requests.forEach(function (request) {                              // 47
					var fileName = request.fileName;                                  // 48
					var cnLabel = request.cnLabel;                                    // 49
					var randomStr = uuid;                                             // 50
					delete request.fileName;                                          // 51
					delete request.cnLabel;                                           // 52
					fileData = JSON.stringify(request);                               // 53
                                                                       //
					var params = {                                                    // 55
						fileName: fileName,                                              // 56
						cnLabel: cnLabel,                                                // 57
						randomStr: randomStr,                                            // 58
						fileData: fileData                                               // 59
					};                                                                //
					log(params);                                                      // 61
                                                                       //
					HTTP.call('POST', requestUrl, {                                   // 63
						params: params                                                   // 64
					}, function (err, result) {                                       //
						if (!err && querystring.parse(result.content).result === 'success') {
							var handleFlag = 'true';                                        // 67
							var resultString = querystring.parse(result.content).resultString;
                                                                       //
							log('resultString: ', resultString);                            // 70
                                                                       //
							HandleResults.insert({                                          // 72
								uuid: uuid,                                                    // 73
								handleFlag: handleFlag,                                        // 74
								wordURI: requestUrl + 'output/' + resultString + '.doc',       // 75
								pdfURI: requestUrl + 'output/' + resultString + '.pdf',        // 76
								fileName: fileName,                                            // 77
								cnLabel: cnLabel,                                              // 78
								createDate: new Date()                                         // 79
							}, function (err) {                                             //
								if (err) {                                                     // 81
									log(cnLabel + ' [ ' + fileName + ' ] ' + 'save handle results to db error', err);
								} else {                                                       //
									log(cnLabel + ' [ ' + fileName + ' ] ' + 'save handle results to db succeed!');
								}                                                              //
							});                                                             //
						} else {                                                         //
							log(cnLabel + ' [ ' + fileName + ' ] ' + 'handle error,try again.', err);
						}                                                                //
					});                                                               //
				});                                                                //
			}                                                                   //
		}                                                                    //
	}                                                                     //
});                                                                    //
                                                                       //
function HandleCheckOrder(order) {                                     // 98
	log("HandleCheckOrder: I am called.");                                // 99
	// handle companyName                                                 //
	var companyName = "";                                                 // 101
	var alternativeName = [];                                             // 102
                                                                       //
	if (!order.hasOwnProperty("companyName") || !order.companyName.hasOwnProperty("mainName") || !order.hasOwnProperty("industrySmall")) {
		companyName = "";                                                    // 107
	} else {                                                              //
		companyName = order.companyName.mainName + '（上海）' + order.industrySmall + '有限责任公司';
	}                                                                     //
                                                                       //
	if (!order.hasOwnProperty("companyName")) {                           // 112
		alternativeName = [];                                                // 113
	} else {                                                              //
		var companyNameObj = order.companyName;                              // 115
		if (companyNameObj.hasOwnProperty("alternativeName1")) {             // 116
			alternativeName.push(companyNameObj.alternativeName1);              // 117
		}                                                                    //
		if (companyNameObj.hasOwnProperty("alternativeName2")) {             // 119
			alternativeName.push(companyNameObj.alternativeName2);              // 120
		}                                                                    //
		if (companyNameObj.hasOwnProperty("alternativeName3")) {             // 122
			alternativeName.push(companyNameObj.alternativeName3);              // 123
		}                                                                    //
		if (companyNameObj.hasOwnProperty("alternativeName4")) {             // 125
			alternativeName.push(companyNameObj.alternativeName4);              // 126
		}                                                                    //
	}                                                                     //
                                                                       //
	var companyZone = "";                                                 // 131
                                                                       //
	if (!order.hasOwnProperty("servicesNameList") || !order.hasOwnProperty("typeNameFlag") || order.typeNameFlag === "registration") {
		var nameList = order.servicesNameList[0];                            // 136
		if (nameList.hasOwnProperty("zone")) {                               // 137
			companyZone = nameList.zone;                                        // 138
		} else {                                                             //
			var name = nameList.name;                                           // 140
			companyZone = name.slice(name.lastIndexOf("[") + 1, name.lastIndexOf("]")) || "";
		}                                                                    //
	} else {                                                              //
		companyZone = "";                                                    // 144
	}                                                                     //
                                                                       //
	var businessScope = "";                                               // 147
                                                                       //
	if (!order.hasOwnProperty("businessScope")) {                         // 149
		businessScope = "";                                                  // 150
	} else {                                                              //
		businessScope = order.businessScope.toString();                      // 152
	}                                                                     //
                                                                       //
	var holderName = [];                                                  // 156
	var holderID = [];                                                    // 157
                                                                       //
	if (order.hasOwnProperty("holders")) {                                // 159
		var holders = order.holders;                                         // 160
		holders.forEach(function (holder) {                                  // 161
			if (holder.hasOwnProperty("holderName")) {                          // 162
				holderName.push(holder.holderName);                                // 163
			} else {                                                            //
				holderName.push("");                                               // 165
			}                                                                   //
                                                                       //
			if (holder.hasOwnProperty("code")) {                                // 168
				holderID.push(holder.code);                                        // 169
			} else {                                                            //
				holderID.push("");                                                 // 171
			}                                                                   //
		});                                                                  //
	}                                                                     //
                                                                       //
	var moneyAmount = 0;                                                  // 176
	if (order.hasOwnProperty("companyMoney")) {                           // 177
		moneyAmount = order.companyMoney;                                    // 178
	}                                                                     //
                                                                       //
	var companyAddress = ""; // 公司地址                                      // 181
	var requests = [];                                                    // 182
	if (companyZone === "虹口") {                                           // 183
		var checkBook = {                                                    // 184
			fileName: 'K0211090101',                                            // 185
			cnLabel: '企业名称预先核准申请书',                                             // 186
			companyName: companyName,                                           // 187
			alternativeName: alternativeName,                                   // 188
			companyAddress: companyAddress,                                     // 189
			businessScope: businessScope,                                       // 190
			holderName: holderName,                                             // 191
			holderID: holderID,                                                 // 192
			moneyAmount: moneyAmount                                            // 193
		};                                                                   //
		requests.push(checkBook);                                            // 195
	} else if (companyZone === "浦东") {                                    //
                                                                       //
		var checkBook = {                                                    // 198
			fileName: 'K0211020101',                                            // 199
			cnLabel: '企业名称预先核准申请书',                                             // 200
			companyName: companyName,                                           // 201
			alternativeName: alternativeName,                                   // 202
			companyAddress: companyAddress,                                     // 203
			businessScope: businessScope,                                       // 204
			holderName: holderName,                                             // 205
			holderID: holderID,                                                 // 206
			moneyAmount: moneyAmount                                            // 207
		};                                                                   //
		requests.push(checkBook);                                            // 209
		var certification = {                                                // 210
			fileName: 'K0211020102',                                            // 211
			cnLabel: '委托人代理证明',                                                 // 212
			holderName: holderName.join('、')                                    // 213
		};                                                                   //
		requests.push(certification);                                        // 215
                                                                       //
		var authorizationPaper = {                                           // 217
			fileName: 'K0211020103',                                            // 218
			cnLabel: '委托书',                                                     // 219
			holderName: holderName.join('、')                                    // 220
		};                                                                   //
		requests.push(authorizationPaper);                                   // 222
	}                                                                     //
	return requests;                                                      // 225
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=template.js.map
