(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/clouds/clouds.js                                             //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
var querystring = Meteor.npmRequire('querystring');                    // 1
var requestUrl = 'http://192.168.0.100/docgen/';                       // 2
                                                                       //
function log(info) {                                                   // 4
  var len = arguments.length;                                          // 5
  console.log('------------------------------------');                 // 6
  for (var i = 0; i < len; i++) {                                      // 7
    console.log(arguments[i]);                                         // 8
  }                                                                    //
};                                                                     //
                                                                       //
Meteor.methods({                                                       // 12
  "GenerateRegTemplate": function (options) {                          // 13
    log("GenerateRegTemplate: Hi, I am called!");                      // 14
    if (!options || !options.hasOwnProperty("orderId") || !options.hasOwnProperty("uuid") || !options.hasOwnProperty("zone")) {
      log("GenerateRegTemplate: options illegal", options);            // 19
    } else {                                                           //
      var orderId = options.orderId;                                   // 21
      var uuid = options.uuid;                                         // 22
      var zone = options.zone;                                         // 23
                                                                       //
      var order = Orders.findOne({ orderId: orderId });                // 25
                                                                       //
      if (!order) {                                                    // 27
        log("GenerateTemplate: query order error");                    // 28
      } else {                                                         //
        var requests = [];                                             // 30
        switch (zone) {                                                // 31
          case '虹口':                                                   // 32
            requests = HandleRegHKOrder(order);                        // 33
            break;                                                     // 34
          case '浦东':                                                   // 35
            requests = HandleRegPDOrder(order);                        // 36
            break;                                                     // 37
          default:                                                     // 38
            break;                                                     // 39
        }                                                              // 39
        requests.forEach(function (request) {                          // 41
          var fileName = request.fileName;                             // 42
          var cnLabel = request.cnLabel;                               // 43
          var randomStr = uuid;                                        // 44
          delete request.fileName;                                     // 45
          delete request.cnLabel;                                      // 46
          fileData = JSON.stringify(request);                          // 47
                                                                       //
          var params = {                                               // 49
            fileName: fileName,                                        // 50
            cnLabel: cnLabel,                                          // 51
            randomStr: randomStr,                                      // 52
            fileData: fileData                                         // 53
          };                                                           //
          log(params, "开始提交生成文档");                                     // 55
                                                                       //
          HTTP.call('POST', requestUrl, {                              // 57
            params: params                                             // 58
          }, function (err, result) {                                  //
            if (!err && querystring.parse(result.content).result === 'success') {
              var handleFlag = 'true';                                 // 61
              var resultString = querystring.parse(result.content).resultString;
                                                                       //
              log('resultString: ', resultString);                     // 64
                                                                       //
              HandleResults.insert({                                   // 66
                uuid: uuid,                                            // 67
                handleFlag: handleFlag,                                // 68
                wordURI: requestUrl + 'output/' + resultString + '.doc',
                pdfURI: requestUrl + 'output/' + resultString + '.pdf',
                fileName: fileName,                                    // 71
                cnLabel: cnLabel,                                      // 72
                createDate: new Date()                                 // 73
              }, function (err) {                                      //
                if (err) {                                             // 75
                  log(cnLabel + ' [ ' + fileName + ' ] ' + 'save handle results to db error', err);
                } else {                                               //
                  log(cnLabel + ' [ ' + fileName + ' ] ' + 'save handle results to db succeed!');
                }                                                      //
              });                                                      //
            } else {                                                   //
              log(cnLabel + ' [ ' + fileName + ' ] ' + 'handle error,try again.', err);
            }                                                          //
          });                                                          //
        });                                                            //
      }                                                                //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
function HandlePCOrder(order) {                                        // 92
  // handle companyName                                                //
  var _order = {};                                                     // 94
  var companyName = "";                                                // 95
  var alternativeName = [];                                            // 96
                                                                       //
  if (!order.hasOwnProperty("companyName") || !order.companyName.hasOwnProperty("mainName") || !order.hasOwnProperty("industrySmall")) {
    companyName = "";                                                  // 101
  } else {                                                             //
    companyName = order.companyName.mainName + '（上海）' + order.industrySmall + '有限责任公司';
  }                                                                    //
                                                                       //
  if (!order.hasOwnProperty("companyName")) {                          // 106
    alternativeName = [];                                              // 107
  } else {                                                             //
    var companyNameObj = order.companyName;                            // 109
    if (companyNameObj.hasOwnProperty("alternativeName1")) {           // 110
      alternativeName.push(companyNameObj.alternativeName1);           // 111
    }                                                                  //
    if (companyNameObj.hasOwnProperty("alternativeName2")) {           // 113
      alternativeName.push(companyNameObj.alternativeName2);           // 114
    }                                                                  //
    if (companyNameObj.hasOwnProperty("alternativeName3")) {           // 116
      alternativeName.push(companyNameObj.alternativeName3);           // 117
    }                                                                  //
    if (companyNameObj.hasOwnProperty("alternativeName4")) {           // 119
      alternativeName.push(companyNameObj.alternativeName4);           // 120
    }                                                                  //
  }                                                                    //
                                                                       //
  // log(companyName, alternativeName)                                 //
                                                                       //
  var companyZone = "";                                                // 126
  var companyType = "有限责任公司";                                          // 127
  var companyId = "";                                                  // 128
  var companyTel = "";                                                 // 129
  var companyZipcode = ""; // TODO                                     // 130
  var businessPeriod = "";                                             // 131
  var addressFlag = "是";                                               // 132
  var companyAddress = ""; // 公司地址                                     // 133
  var productionAddress = ""; // 生产地址                                  // 134
                                                                       //
  if (!order.hasOwnProperty("servicesNameList") || !order.hasOwnProperty("typeNameFlag") || order.typeNameFlag === "registration") {
    var nameList = order.servicesNameList[0];                          // 140
    if (nameList.hasOwnProperty("zone")) {                             // 141
      companyZone = nameList.zone;                                     // 142
    } else {                                                           //
      var name = nameList.name;                                        // 144
      companyZone = name.slice(name.lastIndexOf("[") + 1, name.lastIndexOf("]")) || "";
    }                                                                  //
  } else {                                                             //
    companyZone = "";                                                  // 148
  }                                                                    //
                                                                       //
  if (companyZone === "浦东") {                                          // 151
    businessPeriod = "20年";                                            // 152
  } else if (companyZone === "虹口") {                                   //
    businessPeriod = "长期";                                             // 154
  }                                                                    //
                                                                       //
  if (!order.hasOwnProperty("companyAddress") || !order.companyAddress.length >= 4) {
    if (companyZone === "浦东") {                                        // 158
      companyAddress = "浦东新区";                                         // 159
      productionAddress = companyAddress;                              // 160
    } else if (companyZone === "虹口") {                                 //
      companyAddress = "虹口区长阳路235号";                                   // 162
      productionAddress = companyAddress;                              // 163
    } else {                                                           //
      companyAddress = "";                                             // 165
      productionAddress = "";                                          // 166
    }                                                                  //
  } else {                                                             //
    companyAddress = order.companyAddress;                             // 169
    productionAddress = companyAddress;                                // 170
  }                                                                    //
                                                                       //
  var businessScope = "";                                              // 174
                                                                       //
  if (!order.hasOwnProperty("businessScope")) {                        // 176
    businessScope = "";                                                // 177
  } else {                                                             //
    businessScope = order.businessScope.toString();                    // 179
  }                                                                    //
                                                                       //
  var moneyAmount = 0;                                                 // 182
  if (order.hasOwnProperty("companyMoney")) {                          // 183
    moneyAmount = order.companyMoney;                                  // 184
  }                                                                    //
                                                                       //
  var legalPersonName = ""; //法人姓名                                     // 187
  var legalPersonPhone = "";                                           // 188
  var legalPersonTel = "";                                             // 189
  var legalPersonEmail = "";                                           // 190
  var legalPersonID = "";                                              // 191
  var legalPersonIDType = "身份证";                                       // 192
                                                                       //
  if (order.hasOwnProperty("legalPerson")) {                           // 194
    legalPersonName = order.legalPerson.legalPersonName || "";         // 195
    legalPersonID = order.legalPerson.legalPersonId || "";             // 196
  }                                                                    //
                                                                       //
  var chairmanName = legalPersonName || "";                            // 199
  var chairmanType = "执行董事";                                           // 200
  var chairmanIDType = "身份证";                                          // 201
  var chairmanID = legalPersonID || "";                                // 202
  var chairmanPhone = legalPersonPhone || "";                          // 203
                                                                       //
  var supervisorName = "";                                             // 205
  var supervisorType = "监事";                                           // 206
  var supervisorIDType = "身份证";                                        // 207
  var supervisorID = "";                                               // 208
  if (order.hasOwnProperty("supervisor")) {                            // 209
    supervisorName = order.supervisor.supervisorName || "";            // 210
    supervisorID = order.supervisor.supervisorId || "";                // 211
  }                                                                    //
                                                                       //
  var managerName = legalPersonName || "";                             // 214
  var managerType = "经理";                                              // 215
  var managerIDType = "身份证";                                           // 216
  var managerID = legalPersonID || "";                                 // 217
                                                                       //
  var contractorName = "";                                             // 219
  var contractorTel = "";                                              // 220
  var contractorPhone = "";                                            // 221
  var contractorEmail = "";                                            // 222
  var contractorIDType = "身份证";                                        // 223
  var contractorID = "";                                               // 224
                                                                       //
  if (order.hasOwnProperty("contractor") && order.contractor.hasOwnProperty("liaisons")) {
    var liaisons = order.contractor.liaisons;                          // 228
    contractorName = liaisons.liaisonsName;                            // 229
    contractorID = liaisons.liaisonsId;                                // 230
    contractorPhone = liaisons.liaisonsPhone;                          // 231
    contractorEmail = liaisons.liaisonsEmail;                          // 232
  }                                                                    //
                                                                       //
  var financialStaffName = "";                                         // 235
  var financialStallTel = "";                                          // 236
  var financialStaffPhone = "";                                        // 237
  var financialStaffEmail = "";                                        // 238
  var financialStaffIDType = "身份证";                                    // 239
  var financialStaffID = "";                                           // 240
                                                                       //
  if (order.hasOwnProperty("contractor") && order.contractor.hasOwnProperty("financialStaff")) {
    var financialStaff = order.contractor.financialStaff;              // 244
    financialStaffName = financialStaff.financialStaffName;            // 245
    financialStaffID = financialStaff.financialStaffId;                // 246
    financialStaffPhone = financialStaff.financialStaffPhone;          // 247
    financialStaffEmail = financialStaff.financialStaffEmail;          // 248
  }                                                                    //
                                                                       //
  var authorizationFlag = "是";                                         // 251
  var createTime = new Date();                                         // 252
  var year = createTime.getFullYear();                                 // 253
  var month = createTime.getMonth() + 1;                               // 254
  var day = '28';                                                      // 255
  // var investDate = (year + 10) + '年' + month + '月' + day + '日';     //
  var investDate = "";                                                 // 257
  if (companyZone === "虹口") {                                          // 258
    investDate = moment(createTime).add(20, 'years').format("YYYY.M.D");
  } else if (companyZone === "浦东") {                                   //
    investDate = "公司设立之日起20年内";                                        // 261
  } else {                                                             //
    investDate = "";                                                   // 263
  }                                                                    //
                                                                       //
  var mettingDate = year + '年' + month + '月' + day + '日';              // 266
                                                                       //
  var authorizationDate = "";                                          // 268
                                                                       //
  var authorizationStart = moment(createTime).format("YYYY年 M 月 D 日");
  var authorizationEnd = moment(createTime).add(3, 'months').format("YYYY年 M 月 D 日");
  log(authorizationStart, authorizationEnd);                           // 272
                                                                       //
  authorizationDate = authorizationStart + ' 至 ' + authorizationEnd;   // 274
                                                                       //
  var agent = "";                                                      // 276
  if (order.hasOwnProperty("agent")) {                                 // 277
    agent = order.agent;                                               // 278
  } else {                                                             //
    agent = "";                                                        // 280
  }                                                                    //
                                                                       //
  var regulationFileName = '';                                         // 285
  var holderFileName = '';                                             // 286
  var registrationFileName = '';                                       // 287
                                                                       //
  var holderName = [];                                                 // 289
  var holderIDType = [];                                               // 290
  var holderID = [];                                                   // 291
  var investType = [];                                                 // 292
  var investShare = [];                                                // 293
  var investMoneyAmount = [];                                          // 294
  var investDateOutput = [];                                           // 295
                                                                       //
  var holderLength = 0;                                                // 297
  if (order.hasOwnProperty("holders")) {                               // 298
    holderLength = order.holders.length;                               // 299
  }                                                                    //
                                                                       //
  if (order.hasOwnProperty("holders")) {                               // 303
    var holders = order.holders;                                       // 304
                                                                       //
    holders.forEach(function (holder) {                                // 306
      if (holder.hasOwnProperty("holderName")) {                       // 307
        holderName.push(holder.holderName);                            // 308
      } else {                                                         //
        holderName.push("");                                           // 310
      }                                                                //
      log(holder);                                                     // 312
      holderIDType.push("身份证");                                        // 313
      if (holder.hasOwnProperty("code")) {                             // 314
        holderID.push(holder.code);                                    // 315
      } else {                                                         //
        holderID.push("");                                             // 317
      }                                                                //
                                                                       //
      investType.push("货币");                                           // 320
                                                                       //
      if (holder.hasOwnProperty("moneyPercent")) {                     // 322
        investShare.push(holder.moneyPercent + "%");                   // 323
      } else {                                                         //
        investShare.push("");                                          // 325
      }                                                                //
                                                                       //
      if (holder.hasOwnProperty("money")) {                            // 328
        investMoneyAmount.push(holder.money);                          // 329
      } else {                                                         //
        investMoneyAmount.push("");                                    // 331
      }                                                                //
                                                                       //
      investDateOutput.push(investDate);                               // 334
    });                                                                //
  };                                                                   //
                                                                       //
  _order.companyName = companyName || "";                              // 338
  _order.alternativeName = alternativeName || [];                      // 339
  _order.companyZone = companyZone || "";                              // 340
  _order.companyType = companyType || "";                              // 341
  _order.companyId = companyId || "";                                  // 342
  _order.companyTel = companyTel || "";                                // 343
                                                                       //
  _order.companyZipcode = companyZipcode || "";                        // 345
                                                                       //
  _order.businessPeriod = businessPeriod || "";                        // 347
  _order.addressFlag = addressFlag || "";                              // 348
  _order.companyAddress = companyAddress || "";                        // 349
  _order.productionAddress = productionAddress || "";                  // 350
  _order.moneyAmount = moneyAmount || 0;                               // 351
                                                                       //
  _order.businessScope = businessScope || "";                          // 353
                                                                       //
  _order.legalPersonName = legalPersonName || "";                      // 355
  _order.legalPersonPhone = legalPersonPhone || "";                    // 356
  _order.legalPersonTel = legalPersonTel || "";                        // 357
  _order.legalPersonEmail = legalPersonEmail || "";                    // 358
  _order.legalPersonID = legalPersonID || "";                          // 359
  _order.legalPersonIDType = legalPersonIDType || "身份证";               // 360
  _order.chairmanName = chairmanName || "";                            // 361
  _order.chairmanType = chairmanType || "";                            // 362
  _order.chairmanIDType = chairmanIDType || "";                        // 363
  _order.chairmanID = chairmanID || "";                                // 364
  _order.chairmanPhone = chairmanPhone || "";                          // 365
                                                                       //
  _order.supervisorName = supervisorName || "";                        // 367
  _order.supervisorType = supervisorType || "";                        // 368
  _order.supervisorIDType = supervisorIDType || "身份证";                 // 369
  _order.supervisorID = supervisorID || "";                            // 370
                                                                       //
  _order.managerName = managerName || "";                              // 372
  _order.managerType = managerType || "";                              // 373
  _order.managerIDType = managerIDType || "身份证";                       // 374
  _order.managerID = managerID || "";                                  // 375
                                                                       //
  _order.contractorName = contractorName || "";                        // 377
  _order.contractorTel = contractorTel || "";                          // 378
  _order.contractorPhone = contractorPhone || "";                      // 379
  _order.contractorEmail = contractorEmail || "";                      // 380
  _order.contractorIDType = contractorIDType || "身份证";                 // 381
  _order.contractorID = contractorID || "";                            // 382
                                                                       //
  _order.financialStaffName = financialStaffName || "";                // 384
  _order.financialStallTel = financialStallTel || "";                  // 385
  _order.financialStaffPhone = financialStaffPhone || "";              // 386
  _order.financialStaffEmail = financialStaffEmail || "";              // 387
  _order.financialStaffIDType = financialStaffIDType || "身份证";         // 388
  _order.financialStaffID = financialStaffID || "";                    // 389
                                                                       //
  _order.authorizationFlag = authorizationFlag || "是";                 // 391
                                                                       //
  _order.investDate = investDate || "";                                // 393
  _order.mettingDate = mettingDate || "";                              // 394
                                                                       //
  _order.holderName = holderName || [];                                // 396
  _order.holderIDType = holderIDType || [];                            // 397
  _order.holderID = holderID || [];                                    // 398
  _order.investType = investType || [];                                // 399
  _order.investShare = investShare || [];                              // 400
  _order.investMoneyAmount = investMoneyAmount || [];                  // 401
  _order.investDateOutput = investDateOutput || [];                    // 402
                                                                       //
  _order.holderLength = holderLength || 0;                             // 404
  _order.agent = agent || "";                                          // 405
                                                                       //
  _order.authorizationDate = authorizationDate || "";                  // 407
                                                                       //
  log(_order);                                                         // 410
                                                                       //
  return _order;                                                       // 412
}                                                                      //
                                                                       //
function HandleRegHKOrder(order) {                                     // 417
  log("HandleRegHKOrder: I am called.");                               // 418
                                                                       //
  var _order = HandlePCOrder(order);                                   // 420
                                                                       //
  var regulationFileName = '';                                         // 422
  var holderFileName = '';                                             // 423
  var registrationFileName = '';                                       // 424
                                                                       //
  log("holderLength: " + _order.holderLength);                         // 426
  if (_order.holderLength <= 1) {                                      // 427
    log("单人");                                                         // 428
    regulationFileName = 'K0211090301';                                // 429
    holderFileName = 'K0211090201';                                    // 430
    registrationFileName = 'K0211090601';                              // 431
                                                                       //
    var regulations = {                                                // 433
      fileName: regulationFileName,                                    // 434
      cnLabel: '公司章程',                                                 // 435
      companyName: _order.companyName,                                 // 436
      companyAddress: _order.companyAddress,                           // 437
      productionAddress: _order.productionAddress,                     // 438
      businessScope: _order.businessScope,                             // 439
      moneyAmount: _order.moneyAmount,                                 // 440
      registeredCapital: _order.moneyAmount,                           // 441
      holderName: _order.holderName[0],                                // 442
      investDate: _order.investDateOutput[0],                          // 443
      investType: _order.investType[0],                                // 444
      investMoney: _order.investMoneyAmount[0]                         // 445
    };                                                                 //
  } else {                                                             //
    log('多人');                                                         // 449
    regulationFileName = 'K0211090302';                                // 450
    holderFileName = 'K0211090202';                                    // 451
    registrationFileName = 'K0211090602';                              // 452
    var regulations = {                                                // 453
      fileName: regulationFileName,                                    // 454
      cnLabel: '公司章程',                                                 // 455
      companyName: _order.companyName,                                 // 456
      companyAddress: _order.companyAddress,                           // 457
      productionAddress: _order.productionAddress,                     // 458
      businessScope: _order.businessScope,                             // 459
      moneyAmount: _order.moneyAmount,                                 // 460
      registeredCapital: _order.moneyAmount,                           // 461
      holderName: _order.holderName,                                   // 462
      investDate: _order.investDateOutput,                             // 463
      investType: _order.investType,                                   // 464
      investMoney: _order.investMoneyAmount                            // 465
    };                                                                 //
  }                                                                    //
                                                                       //
  var requests = [];                                                   // 469
  requests.push(regulations);                                          // 470
                                                                       //
  var shareholder = {                                                  // 472
    fileName: holderFileName,                                          // 473
    cnLabel: '股东会决议',                                                  // 474
    mettingDate: _order.mettingDate,                                   // 475
    companyName: _order.companyName,                                   // 476
    chairmanName: _order.chairmanName,                                 // 477
    managerName: _order.managerName,                                   // 478
    supervisorName: _order.supervisorName,                             // 479
    supervisorID: _order.supervisorID                                  // 480
  };                                                                   //
  requests.push(shareholder);                                          // 482
                                                                       //
  var leasing = {                                                      // 484
    fileName: 'K0211090401',                                           // 485
    cnLabel: '房屋租赁合同',                                                 // 486
    companyName: _order.companyName,                                   // 487
    companyAddress: _order.companyAddress                              // 488
  };                                                                   //
  requests.push(leasing);                                              // 490
                                                                       //
  // 公司备案申请书                                                           //
  var registrationBook = {                                             // 493
    fileName: registrationFileName,                                    // 494
    cnLabel: '公司登记（备案）申请书',                                            // 495
    companyName: _order.companyName,                                   // 496
    companyZone: _order.companyZone,                                   // 497
    companyType: _order.companyType,                                   // 498
                                                                       //
    companyId: _order.companyId,                                       // 500
    companyTel: _order.companyTel,                                     // 501
    companyZipcode: _order.companyZipcode,                             // 502
    businessScope: _order.businessScope,                               // 503
    businessPeriod: _order.businessPeriod,                             // 504
                                                                       //
    companyAddress: _order.companyAddress,                             // 506
    productionAddress: _order.productionAddress,                       // 507
                                                                       //
    legalPersonName: _order.legalPersonName,                           // 509
    legalPersonTel: _order.legalPersonTel,                             // 510
    legalPersonPhone: _order.legalPersonPhone,                         // 511
    legalPersonEmail: _order.legalPersonEmail,                         // 512
    legalPersonIDType: _order.legalPersonIDType,                       // 513
    legalPersonID: _order.legalPersonID,                               // 514
                                                                       //
    chairmanName: _order.chairmanName,                                 // 516
    chairmanType: _order.chairmanType,                                 // 517
    chairmanIDType: _order.chairmanIDType,                             // 518
    chairmanID: _order.chairmanID,                                     // 519
    chairmanPhone: _order.chairmanPhone,                               // 520
                                                                       //
    supervisorName: _order.supervisorName,                             // 522
    supervisorType: _order.supervisorType,                             // 523
    supervisorIDType: _order.supervisorIDType,                         // 524
    supervisorID: _order.supervisorID,                                 // 525
                                                                       //
    managerName: _order.managerName,                                   // 527
    managerType: _order.managerType,                                   // 528
    managerIDType: _order.managerIDType,                               // 529
    managerID: _order.managerID,                                       // 530
                                                                       //
    holderName: _order.holderName,                                     // 532
    holderIDType: _order.holderIDType,                                 // 533
    holderID: _order.holderID,                                         // 534
    investType: _order.investType,                                     // 535
    investDate: _order.investDateOutput,                               // 536
    money: _order.investMoneyAmount,                                   // 537
    share: _order.investShare,                                         // 538
    moneyAmount: _order.moneyAmount,                                   // 539
                                                                       //
    contractorName: _order.contractorName,                             // 541
    contractorTel: _order.contractorTel,                               // 542
    contractorPhone: _order.contractorPhone,                           // 543
    contractorEmail: _order.contractorEmail,                           // 544
    contractorIDType: _order.contractorIDType,                         // 545
    contractorID: _order.contractorID,                                 // 546
                                                                       //
    financialStaffName: _order.financialStaffName,                     // 548
    financialStallTel: _order.financialStallTel,                       // 549
    financialStaffPhone: _order.financialStaffPhone,                   // 550
    financialStaffEmail: _order.financialStaffEmail,                   // 551
    financialStaffIDType: _order.financialStaffIDType,                 // 552
    financialStaffID: _order.financialStaffID                          // 553
  };                                                                   //
                                                                       //
  requests.push(registrationBook);                                     // 556
                                                                       //
  var commitment = {                                                   // 558
    fileName: 'K0211090701',                                           // 559
    cnLabel: '广告企业告知承诺书'                                               // 560
  };                                                                   //
                                                                       //
  requests.push(commitment);                                           // 563
                                                                       //
  var appraise = {                                                     // 565
    fileName: 'K0211090801',                                           // 566
    cnLabel: '小型微型企业认定申请表'                                             // 567
  };                                                                   //
  requests.push(appraise);                                             // 569
                                                                       //
  var companyIdApplication = {                                         // 571
    fileName: 'K0211090901',                                           // 572
    cnLabel: '上海市组织机构代码申请表'                                            // 573
  };                                                                   //
                                                                       //
  requests.push(companyIdApplication);                                 // 576
                                                                       //
  var note = {                                                         // 578
    fileName: 'K0211091001',                                           // 579
    cnLabel: '情况说明'                                                    // 580
  };                                                                   //
                                                                       //
  requests.push(note);                                                 // 583
  return requests;                                                     // 584
}                                                                      //
                                                                       //
function HandleRegPDOrder(order) {                                     // 589
  log("HandleRegPDOrder: I am called.");                               // 590
                                                                       //
  var _order = HandlePCOrder(order);                                   // 592
  var regulationFileName = '';                                         // 593
  var holderFileName = '';                                             // 594
  var registrationFileName = '';                                       // 595
                                                                       //
  log("holderLength: " + _order.holderLength);                         // 597
  if (_order.holderLength <= 1) {                                      // 598
    log("单人");                                                         // 599
    regulationFileName = 'K0211020301';                                // 600
    holderFileName = 'K0211020201';                                    // 601
    registrationFileName = 'K0211020601';                              // 602
                                                                       //
    var regulations = {                                                // 604
      fileName: regulationFileName,                                    // 605
      cnLabel: '公司章程',                                                 // 606
      companyName: _order.companyName,                                 // 607
      companyAddress: _order.companyAddress,                           // 608
      productionAddress: _order.productionAddress,                     // 609
      businessScope: _order.businessScope,                             // 610
      moneyAmount: _order.moneyAmount,                                 // 611
      registeredCapital: _order.moneyAmount,                           // 612
      holderName: _order.holderName[0],                                // 613
      investDate: _order.investDateOutput[0],                          // 614
      investType: _order.investType[0],                                // 615
      investMoney: _order.investMoneyAmount[0]                         // 616
    };                                                                 //
  } else {                                                             //
    log('多人');                                                         // 620
    regulationFileName = 'K0211020302';                                // 621
    holderFileName = 'K0211020202';                                    // 622
    registrationFileName = 'K0211020602';                              // 623
    var regulations = {                                                // 624
      fileName: regulationFileName,                                    // 625
      cnLabel: '公司章程',                                                 // 626
      companyName: _order.companyName,                                 // 627
      companyAddress: _order.companyAddress,                           // 628
      productionAddress: _order.productionAddress,                     // 629
      businessScope: _order.businessScope,                             // 630
      moneyAmount: _order.moneyAmount,                                 // 631
      registeredCapital: _order.moneyAmount,                           // 632
      holderName: _order.holderName,                                   // 633
      holderNames: _order.holderName.join('、'),                        // 634
      share: _order.investShare,                                       // 635
      investDate: _order.investDateOutput,                             // 636
      investType: _order.investType,                                   // 637
      investMoney: _order.investMoneyAmount                            // 638
    };                                                                 //
  }                                                                    //
                                                                       //
  var requests = [];                                                   // 642
  requests.push(regulations);                                          // 643
                                                                       //
  var shareholder = {                                                  // 645
    fileName: holderFileName,                                          // 646
    cnLabel: '股东会决议',                                                  // 647
    mettingDate: _order.mettingDate,                                   // 648
    companyName: _order.companyName,                                   // 649
    chairmanName: _order.chairmanName,                                 // 650
    supervisorName: _order.supervisorName,                             // 651
    managerName: _order.managerName,                                   // 652
    holderNumber: _order.holderLength,                                 // 653
    supervisorID: _order.supervisorID                                  // 654
  };                                                                   //
  requests.push(shareholder);                                          // 656
                                                                       //
  var leasing = {                                                      // 658
    fileName: 'K0211090401',                                           // 659
    cnLabel: '房屋租赁合同',                                                 // 660
    companyName: _order.companyName,                                   // 661
    companyAddress: _order.companyAddress                              // 662
  };                                                                   //
  requests.push(leasing);                                              // 664
                                                                       //
  // 公司备案申请书                                                           //
  var registrationBook = {                                             // 667
    fileName: registrationFileName,                                    // 668
    cnLabel: '公司登记（备案）申请书',                                            // 669
    companyName: _order.companyName,                                   // 670
    companyZone: _order.companyZone,                                   // 671
    companyType: _order.companyType,                                   // 672
                                                                       //
    companyId: _order.companyId,                                       // 674
    companyTel: _order.companyTel,                                     // 675
    companyZipcode: _order.companyZipcode,                             // 676
    businessScope: _order.businessScope,                               // 677
    businessPeriod: _order.businessPeriod,                             // 678
                                                                       //
    companyAddress: _order.companyAddress,                             // 680
    productionAddress: _order.productionAddress,                       // 681
                                                                       //
    legalPersonName: _order.legalPersonName,                           // 683
    legalPersonTel: _order.legalPersonTel,                             // 684
    legalPersonPhone: _order.legalPersonPhone,                         // 685
    legalPersonEmail: _order.legalPersonEmail,                         // 686
    legalPersonIDType: _order.legalPersonIDType,                       // 687
    legalPersonID: _order.legalPersonID,                               // 688
                                                                       //
    chairmanName: _order.chairmanName,                                 // 690
    chairmanType: _order.chairmanType,                                 // 691
    chairmanIDType: _order.chairmanIDType,                             // 692
    chairmanID: _order.chairmanID,                                     // 693
    chairmanPhone: _order.chairmanPhone,                               // 694
                                                                       //
    supervisorName: _order.supervisorName,                             // 696
    supervisorType: _order.supervisorType,                             // 697
    supervisorIDType: _order.supervisorIDType,                         // 698
    supervisorID: _order.supervisorID,                                 // 699
                                                                       //
    managerName: _order.managerName,                                   // 701
    managerType: _order.managerType,                                   // 702
    managerIDType: _order.managerIDType,                               // 703
    managerID: _order.managerID,                                       // 704
                                                                       //
    holderName: _order.holderName,                                     // 706
    holderIDType: _order.holderIDType,                                 // 707
    holderID: _order.holderID,                                         // 708
    investType: _order.investType,                                     // 709
    investDate: _order.investDateOutput,                               // 710
    money: _order.investMoneyAmount,                                   // 711
    share: _order.investShare,                                         // 712
    moneyAmount: _order.moneyAmount,                                   // 713
                                                                       //
    contractorName: _order.contractorName,                             // 715
    contractorTel: _order.contractorTel,                               // 716
    contractorPhone: _order.contractorPhone,                           // 717
    contractorEmail: _order.contractorEmail,                           // 718
    contractorIDType: _order.contractorIDType,                         // 719
    contractorID: _order.contractorID,                                 // 720
                                                                       //
    financialStaffName: _order.financialStaffName,                     // 722
    financialStallTel: _order.financialStallTel,                       // 723
    financialStaffPhone: _order.financialStaffPhone,                   // 724
    financialStaffEmail: _order.financialStaffEmail,                   // 725
    financialStaffIDType: _order.financialStaffIDType,                 // 726
    financialStaffID: _order.financialStaffID                          // 727
  };                                                                   //
                                                                       //
  requests.push(registrationBook);                                     // 730
                                                                       //
  var commitment = {                                                   // 732
    fileName: 'K0211020701',                                           // 733
    cnLabel: '广告企业告知承诺书'                                               // 734
  };                                                                   //
                                                                       //
  requests.push(commitment);                                           // 737
                                                                       //
  var certification = {                                                // 739
    fileName: 'K0211021101',                                           // 740
    cnLabel: '委托人代理证明',                                                // 741
    holderName: _order.holderName.join('、'),                           // 742
    companyName: _order.companyName,                                   // 743
    authorizationDate: _order.authorizationDate,                       // 744
    agent: _order.agent                                                // 745
  };                                                                   //
  requests.push(certification);                                        // 747
                                                                       //
  var authorizationPaper = {                                           // 749
    fileName: 'K0211020501',                                           // 750
    cnLabel: '指定代表或者共同委托代理人授权委托书',                                     // 751
    holderName: _order.holderName.join('、'),                           // 752
    companyName: _order.companyName,                                   // 753
    authorizationDate: _order.authorizationDate,                       // 754
    agent: _order.agent                                                // 755
  };                                                                   //
                                                                       //
  requests.push(authorizationPaper);                                   // 758
                                                                       //
  var cogeneration = {                                                 // 760
    fileName: 'K0211021001',                                           // 761
    cnLabel: '联动登记申请单',                                                // 762
    companyName: _order.companyName,                                   // 763
    companyAddress: _order.companyAddress,                             // 764
    legalPersonName: _order.legalPersonName,                           // 765
    legalPersonPhone: _order.legalPersonPhone,                         // 766
    companyType: _order.companyType,                                   // 767
    zipcode: _order.companyZipcode                                     // 768
  };                                                                   //
  requests.push(cogeneration);                                         // 770
  return requests;                                                     // 771
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=clouds.js.map
