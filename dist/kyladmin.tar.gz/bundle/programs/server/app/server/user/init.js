(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/user/init.js                                                 //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
var users = [{                                                         // 1
  name: "kyladmin",                                                    // 3
  email: "air.cui@kyl.biz",                                            // 4
  password: 'kyl123',                                                  // 5
  phone: 122222334,                                                    // 6
  roles: ['admin', 'manageusers', 'vieworders', 'editorders', 'editgoods']
}];                                                                    //
                                                                       //
if (Meteor.users.find().count() == 0 || Roles.getUsersInRole('admin').count() == 0) {
  console.log("create");                                               // 12
  _.each(users, function (user) {                                      // 13
    var userId;                                                        // 14
    userId = Accounts.createUser({                                     // 15
      username: user.name,                                             // 16
      password: user.password,                                         // 17
      profile: {                                                       // 18
        nickname: user.name,                                           // 19
        phone: user.phone,                                             // 20
        email: user.email                                              // 21
      }                                                                //
    });                                                                //
                                                                       //
    console.log('create user', user.name, userId);                     // 25
                                                                       //
    if (user.roles.length >= 0) {                                      // 27
      console.log(user.name, 'add roles', user.roles);                 // 28
      Roles.addUsersToRoles(userId, user.roles);                       // 29
    }                                                                  //
  });                                                                  //
                                                                       //
  // Roles.createRole('customer');                                     //
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=init.js.map
