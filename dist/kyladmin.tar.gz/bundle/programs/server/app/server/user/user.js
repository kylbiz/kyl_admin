(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/user/user.js                                                 //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
                                                                       //
                                                                       //
// 创建新用户的权限                                                            //
Accounts.validateNewUser(function (user) {                             // 4
  if (Meteor.users.find().count() == 0 || Roles.getUsersInRole('admin').count() == 0) {
    return true;                                                       // 6
  }                                                                    //
                                                                       //
  var loggedInUser = Meteor.user();                                    // 9
  if (Roles.userIsInRole(loggedInUser, ['admin', 'manageusers'])) {    // 10
    // NOTE: This example assumes the user is not using groups.        //
    console.log("create user true");                                   // 12
    return true;                                                       // 13
  }                                                                    //
                                                                       //
  console.log("create user false");                                    // 16
  throw new Meteor.Error(403, "Not authorized to create new users");   // 17
});                                                                    //
                                                                       //
// 操作用户的方法                                                             //
Meteor.methods({                                                       // 21
  checkPermission: function (permission) {                             // 22
    var loggedInUser = Meteor.user();                                  // 23
    if (permission && loggedInUser && Roles.userIsInRole(loggedInUser, permission)) {
      return true;                                                     // 25
    }                                                                  //
                                                                       //
    return false;                                                      // 28
  },                                                                   //
  checkUserHandlePermission: function () {                             // 30
    var loggedInUser = Meteor.user();                                  // 31
    if (!loggedInUser || !Roles.userIsInRole(loggedInUser, ['manageusers'])) {
      return false;                                                    // 34
    } else {                                                           //
      return true;                                                     // 36
    }                                                                  //
  },                                                                   //
  /**                                                                  //
   * check user permission for login this platform                     //
   * @return {Boolean} true if permit                                  //
   */                                                                  //
  checkLoginPermission: function (username) {                          // 43
    var user = Meteor.users.findOne({ "username": username });         // 44
    if (!user || !Roles.userIsInRole(user._id, ['admin'])) {           // 45
      return false;                                                    // 46
    } else {                                                           //
      return true;                                                     // 48
    }                                                                  //
  },                                                                   //
                                                                       //
  /**                                                                  //
   * delete a user from a specific group                               //
   *                                                                   //
   * @method deleteUser                                                //
   * @param {String} targetUserId _id of user to delete                //
   * @param {String} group Company to update permissions for           //
   */                                                                  //
  deleteUser: function (targetUserId) {                                // 59
    var loggedInUser = Meteor.user();                                  // 60
                                                                       //
    if (!loggedInUser || !Roles.userIsInRole(loggedInUser, ['manageusers'])) {
      throw new Meteor.Error(403, "Access denied");                    // 65
    }                                                                  //
                                                                       //
    // remove permissions for target group                             //
    Roles.setUserRoles(targetUserId, []);                              // 69
                                                                       //
    // do other actions required when a user is removed...             //
    Meteor.users.remove(targetUserId);                                 // 72
                                                                       //
    return "delete user ok";                                           // 74
  },                                                                   //
                                                                       //
  /**                                                                  //
   *  create user                                                      //
   */                                                                  //
  addUser: function (user) {                                           // 80
    console.log("addUser", user);                                      // 81
                                                                       //
    var loggedInUser = Meteor.user();                                  // 83
    if (!user || !loggedInUser || !Roles.userIsInRole(loggedInUser, ['manageusers'])) {
      throw new Meteor.Error(403, "Access denied");                    // 85
    }                                                                  //
                                                                       //
    var info = user.info;                                              // 88
    var userId = Accounts.createUser({                                 // 89
      username: info.username,                                         // 90
      password: info.password,                                         // 91
      profile: {                                                       // 92
        nickname: info.username,                                       // 93
        phone: info.phone,                                             // 94
        email: info.email                                              // 95
      }                                                                //
    });                                                                //
                                                                       //
    console.log('create user', info.username, userId);                 // 99
                                                                       //
    if (user.roles && user.roles.length >= 0) {                        // 101
      console.log(info.username, 'add roles', user.roles);             // 102
      Roles.addUsersToRoles(userId, user.roles);                       // 103
    }                                                                  //
                                                                       //
    return "add " + info.username + " ok";                             // 106
  },                                                                   //
                                                                       //
  updateUser: function (targetUserId, user) {                          // 109
    // var info = userInfo.info;                                       //
    console.log("update user", targetUserId, user);                    // 111
                                                                       //
    var loggedInUser = Meteor.user();                                  // 113
                                                                       //
    if (!user || !loggedInUser || !Roles.userIsInRole(loggedInUser, ['manageusers'])) {
      throw new Meteor.Error(403, "Access denied");                    // 118
    }                                                                  //
                                                                       //
    var roles = user.roles;                                            // 121
    Roles.setUserRoles(targetUserId, roles);                           // 122
                                                                       //
    var info = user.info;                                              // 124
    var targetUser = Meteor.users.update({ _id: targetUserId }, { $set: {
        'username': info.username,                                     // 126
        'profile.email': info.email,                                   // 127
        'profile.phone': info.phone                                    // 128
      } }, function (err, result) {                                    //
      if (err) {                                                       // 130
        console.log("update user err", err);                           // 131
        throw new Meteor.Error(403, "update user err");                // 132
      } else {                                                         //
        console.log("update user succeed", result);                    // 134
      }                                                                //
    });                                                                //
                                                                       //
    if (info.password) {                                               // 138
      console.log("change password");                                  // 139
      Accounts.setPassword(targetUserId, info.password);               // 140
    }                                                                  //
  },                                                                   //
  updateSelf: function (user) {                                        // 143
    if (Meteor.userId()) {                                             // 144
      var targetUser = Meteor.users.update({ _id: Meteor.userId() }, { $set: {
          'username': user.username,                                   // 146
          'profile.email': user.email,                                 // 147
          'profile.phone': user.phone                                  // 148
        } }, function (err, result) {                                  //
        if (err) {                                                     // 150
          console.log("update user err", err);                         // 151
          throw new Meteor.Error(403, "update you self err");          // 152
        } else {                                                       //
          console.log("update user succeed", result);                  // 154
        }                                                              //
      });                                                              //
    } else {                                                           //
      throw new Meteor.Error(403, "Not authorized to update you self");
    }                                                                  //
  },                                                                   //
                                                                       //
  /**                                                                  //
   * update a user's permissions                                       //
   *                                                                   //
   * @param {Object} targetUserId Id of user to update                 //
   * @param {Array} roles User's new permissions                       //
   * @param {String} group Company to update permissions for           //
   */                                                                  //
  updateRoles: function (targetUserId, roles, group) {                 // 169
    var loggedInUser = Meteor.user();                                  // 170
                                                                       //
    if (!loggedInUser || !Roles.userIsInRole(loggedInUser, ['manage-users'], group)) {
      throw new Meteor.Error(403, "Access denied!");                   // 175
    }                                                                  //
    if (roles || group) {                                              // 177
      Roles.setUserRoles(targetUserId, roles, group);                  // 178
    }                                                                  //
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=user.js.map
