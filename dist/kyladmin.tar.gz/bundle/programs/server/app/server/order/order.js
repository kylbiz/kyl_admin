(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/order/order.js                                               //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
function log(info) {                                                   // 1
  console.log('-------------------------');                            // 2
  var length = arguments.length;                                       // 3
  for (var i = 0; i < length; i++) {                                   // 4
    console.log(arguments[i]);                                         // 5
  }                                                                    //
}                                                                      //
                                                                       //
Meteor.methods({                                                       // 10
  "updateOrderAddress": function (options) {                           // 11
    log("updateOrderAddress: Hi, I am called.");                       // 12
    if (!options || !options.relationId || !options.receiver || !options.address || !options.phone || !options.zipcode) {
      console.log('user address options not legal');                   // 14
      console.log(options);                                            // 15
    } else {                                                           //
      var relationId = options.relationId;                             // 17
                                                                       //
      Orders.update({ relationId: relationId }, {                      // 20
        $set: {                                                        // 21
          "addressInfo.receiver": options.receiver,                    // 22
          "addressInfo.address": options.address,                      // 23
          "addressInfo.phone": options.phone,                          // 24
          "addressInfo.zipcode": options.zipcode                       // 25
        }                                                              //
      }, {                                                             //
        multi: true                                                    // 28
      }, function (err) {                                              //
        if (err) {                                                     // 30
          console.log('update user address information error');        // 31
          console.log(err);                                            // 32
        } else {                                                       //
          console.log('update user address information succeed');      // 34
        }                                                              //
      });                                                              //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 42
  "UpdateOrderProgress": function (options) {                          // 43
    if (!options || !options.relationId || ! typeof options.status === 'number') {
      console.log('order progress update stop for options illegal');   // 45
      console.log(options);                                            // 46
    } else {                                                           //
      var relationId = options.relationId;                             // 48
      var status = options.status;                                     // 49
      Orders.update({ relationId: relationId }, {                      // 50
        $set: {                                                        // 51
          "productProgress.status": status                             // 52
        }                                                              //
      }, {                                                             //
        upsert: true,                                                  // 55
        multi: true                                                    // 56
      }, function (err) {                                              //
        if (err) {                                                     // 58
          console.log('update order progress error');                  // 59
          console.log(err);                                            // 60
        } else {                                                       //
          console.log('update order progress succeed');                // 62
        }                                                              //
      });                                                              //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 71
  "UpdateHolder": function (options) {                                 // 72
    if (!options || !options.orderId || !options.holderId || !options.holderSex || !options.holderName || !options.holderCode || !options.holderAddress || !options.holderMoney || !options.moneyPercent) {
      console.log('order update holder options illegal');              // 74
      console.log(options);                                            // 75
    } else {                                                           //
      console.log(options);                                            // 77
      Orders.update({                                                  // 78
        orderId: options.orderId,                                      // 80
        "holders.holderId": options.holderId                           // 81
      }, {                                                             //
        $set: {                                                        // 83
          "holders.$.holderName": options.holderName,                  // 84
          "holders.$.sex": options.holderSex,                          // 85
          "holders.$.holderType": options.holderType,                  // 86
          "holders.$.code": options.holderCode,                        // 87
          "holders.$.money": options.holderMoney,                      // 88
          "holders.$.moneyPercent": options.moneyPercent,              // 89
          "holders.$.address": options.holderAddress                   // 90
        }                                                              //
      }, {                                                             //
        multi: true                                                    // 93
      }, function (err) {                                              //
        if (err) {                                                     // 95
          console.log('update holder error');                          // 96
          console.log(err);                                            // 97
        } else {                                                       //
          console.log('update holder succeed');                        // 99
        }                                                              //
      });                                                              //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 107
  "deleteHolder": function (options) {                                 // 108
    if (!options || !options.orderId || !options.holderId) {           // 109
      console.log("delete holder failed for options illegal");         // 110
    } else {                                                           //
      console.log(options);                                            // 112
      Orders.update({                                                  // 113
        orderId: options.orderId                                       // 114
      }, {                                                             //
        $pull: {                                                       // 116
          holders: {                                                   // 117
            holderId: options.holderId                                 // 118
          }                                                            //
        }                                                              //
      }, function (err) {                                              //
        if (err) {                                                     // 122
          console.log("delete holder error");                          // 123
          console.log(err);                                            // 124
        } else {                                                       //
          console.log("delete holder succeed");                        // 126
        }                                                              //
      });                                                              //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
//----------------------------------------------------------------------------
                                                                       //
Meteor.methods({                                                       // 136
  "OrderHolderAdd": function (options) {                               // 137
    if (!options || !options.orderId || !options.holderId || !options.holderSex || !options.holderName || !options.holderCode || !options.holderAddress || !options.holderMoney || !options.holderType || !options.moneyPercent) {
      console.log('order add holder options illegal');                 // 139
      console.log(options);                                            // 140
    } else {                                                           //
      Orders.update({                                                  // 142
        orderId: options.orderId                                       // 143
      }, {                                                             //
        $push: {                                                       // 145
          "holders": {                                                 // 146
            holderId: options.holderId,                                // 147
            holderName: options.holderName,                            // 148
            holderType: options.holderType,                            // 149
            sex: options.holderSex,                                    // 150
            code: options.holderCode,                                  // 151
            money: options.holderMoney,                                // 152
            moneyPercent: options.moneyPercent,                        // 153
            address: options.holderAddress                             // 154
          }                                                            //
        }                                                              //
      }, {                                                             //
        upsert: true                                                   // 158
      }, function (err) {                                              //
        if (err) {                                                     // 160
          console.log('add holder error');                             // 161
          console.log(err);                                            // 162
        } else {                                                       //
          console.log('add holder succeed');                           // 164
        }                                                              //
      });                                                              //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 172
  'OrderEditPerson': function (options) {                              // 173
    var orderId = options.orderId || "";                               // 174
    var legalPersonName = options.legalPersonName || "";               // 175
    var legalPersonId = options.legalPersonId || "";                   // 176
    var legalPersonPhone = options.legalPersonPhone || "";             // 177
    var legalPersonTel = options.legalPersonTel || "";                 // 178
    var legalPersonEmail = options.legalPersonEmail || "";             // 179
    var supervisorName = options.supervisorName || "";                 // 180
    var supervisorId = options.supervisorId || "";                     // 181
    if (orderId && legalPersonName && legalPersonId && supervisorName && supervisorId) {
      Orders.update({ orderId: orderId }, {                            // 185
        $set: {                                                        // 186
          legalPerson: {                                               // 187
            legalPersonName: legalPersonName,                          // 188
            legalPersonId: legalPersonId,                              // 189
            legalPersonPhone: legalPersonPhone,                        // 190
            legalPersonTel: legalPersonTel,                            // 191
            legalPersonEmail: legalPersonEmail                         // 192
          },                                                           //
          supervisor: {                                                // 194
            supervisorName: supervisorName,                            // 195
            supervisorId: supervisorId                                 // 196
          }                                                            //
        }                                                              //
      }, {                                                             //
        upsert: true                                                   // 200
      }, function (err) {                                              //
        if (err) {                                                     // 202
          log('update order person information error', err);           // 203
        } else {                                                       //
          log('update order person information succeed');              // 205
        }                                                              //
      });                                                              //
    } else {                                                           //
      log('person information not complately', options);               // 209
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 216
  'updateCompanyName': function (options) {                            // 217
    log("updateCompanyName: Hi, I am called.", options);               // 218
    if (options && options.orderId && options.mainName && (options.alternativeName1 || options.alternativeName2 || options.alternativeName3 || options.alternativeName4)) {
      var orderId = options.orderId;                                   // 222
      delete options.orderId;                                          // 223
      var companyName = options;                                       // 224
      log(companyName);                                                // 225
      Orders.update({ orderId: orderId }, {                            // 226
        $set: {                                                        // 227
          companyName: companyName                                     // 228
        }                                                              //
      }, function (err) {                                              //
        if (err) {                                                     // 231
          log('update company name error', err);                       // 232
        } else {                                                       //
          log('update company name succeed');                          // 234
        }                                                              //
      });                                                              //
    } else {                                                           //
      log('update company name error, for the information you provided not valid', options);
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 246
  'updateIndustry': function (industryOptions) {                       // 247
    if (!industryOptions || !industryOptions.orderId || !industryOptions.industryBig || !industryOptions.industrySmall) {
      log("industryOptions illegal", industryOptions);                 // 249
    } else {                                                           //
      var orderId = industryOptions.orderId || "";                     // 251
      var industryBig = industryOptions.industryBig || "";             // 252
      var industrySmall = industryOptions.industrySmall || "";         // 253
      var businessScope = [];                                          // 254
      var business = Business.findOne({ industryBig: industryBig, industrySmall: industrySmall });
      if (business) {                                                  // 256
        businessScope = business.content;                              // 257
      }                                                                //
                                                                       //
      if (businessScope.length > 0 && industryOptions && orderId && industryBig !== null && industrySmall !== null && industryBig !== "" && industrySmall !== "") {
                                                                       //
        Orders.update({ orderId: orderId }, {                          // 262
          $set: {                                                      // 263
            industryBig: industryBig,                                  // 264
            industrySmall: industrySmall,                              // 265
            businessScope: businessScope                               // 266
          }                                                            //
        }, function (err) {                                            //
          if (err) {                                                   // 269
            log('update industry type error', err);                    // 270
          } else {                                                     //
            log('update industry type succeed');                       // 272
          }                                                            //
        });                                                            //
      } else {                                                         //
        log('update industry type error, check you parameters', industryOptions);
      }                                                                //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 286
  'EditScope': function (options) {                                    // 287
    if (options && options.orderId && options.contents instanceof Array) {
      Orders.update({ orderId: options.orderId }, {                    // 290
        $set: {                                                        // 291
          businessScope: options.contents                              // 292
        }                                                              //
      }, function (err) {                                              //
        if (err) {                                                     // 295
          log('Edit business scope error', err);                       // 296
        } else {                                                       //
          log('Edit business scope succeed');                          // 298
        }                                                              //
      });                                                              //
    } else {                                                           //
      log("Edit business scope failed for options illegal", options);  // 302
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 310
  'UpdateIndustryDetail': function (options) {                         // 311
    var orderId = options.orderId;                                     // 312
    var contents = options.contents;                                   // 313
                                                                       //
    if (options && orderId && contents instanceof Array) {             // 315
      Orders.update({ orderId: orderId }, {                            // 317
        $pushAll: {                                                    // 318
          businessScope: contents                                      // 319
        }                                                              //
      }, function (err) {                                              //
        if (err) {                                                     // 322
          log('Add business scope error');                             // 323
        } else {                                                       //
          log('Add business scope succeed');                           // 325
        }                                                              //
      });                                                              //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 334
  "UpdateOrderConsigner": function (options) {                         // 335
    var EmailReg = /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/;
    var PhoneReg = /^(0|86|17951)?(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$/;
    if (!options || !options.orderId || !options.consignerName || !EmailReg.test(options.consignerEmail) || !PhoneReg.test(options.consignerPhone)) {
      var err = "consigner information not complately";                // 339
      log(err, options);                                               // 340
    } else {                                                           //
      var orderId = options.orderId;                                   // 342
      var consigner = {                                                // 343
        consignerName: options.consignerName,                          // 344
        consignerPhone: options.consignerPhone,                        // 345
        consignerEmail: options.consignerEmail                         // 346
      };                                                               //
                                                                       //
      Orders.update({ orderId: orderId }, {                            // 349
        $set: {                                                        // 350
          consigner: consigner                                         // 351
        }                                                              //
      }, function (err) {                                              //
        if (err) {                                                     // 354
          log("update order consigner error", err);                    // 355
        } else {                                                       //
          log("update order consigner succeed");                       // 357
        }                                                              //
      });                                                              //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 366
  'CompayContractorHandle': function (options) {                       // 367
    var IdReg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;            // 368
    var EmailReg = /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/;
    var PhoneReg = /^(0|86|17951)?(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$/;
                                                                       //
    if (!options || !options.orderId || !options.liaisons || !IdReg.test(options.liaisons.liaisonsId) || !PhoneReg.test(options.liaisons.liaisonsPhone) || !EmailReg.test(options.liaisons.liaisonsEmail) || !options.financialStaff || !IdReg.test(options.financialStaff.financialStaffId) || !PhoneReg.test(options.financialStaff.financialStaffPhone) || !EmailReg.test(options.financialStaff.financialStaffEmail)) {
      var err = 'contractor information not complately';               // 381
      log(err, options);                                               // 382
    } else {                                                           //
      var orderId = options.orderId;                                   // 384
      var liaisons = options.liaisons;                                 // 385
      var financialStaff = options.financialStaff;                     // 386
                                                                       //
      Orders.update({ orderId: orderId }, {                            // 388
        $set: {                                                        // 389
          contractor: {                                                // 390
            liaisons: liaisons,                                        // 391
            financialStaff: financialStaff                             // 392
          }                                                            //
        }                                                              //
      }, function (err) {                                              //
        if (err) {                                                     // 396
          log('update contractor information error', err);             // 397
        } else {                                                       //
          log('update contractor information succeed');                // 399
        }                                                              //
      });                                                              //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 407
  "updateCompanyAddress": function (options) {                         // 408
    log("updateCompanyAddress: Hi, I am called");                      // 409
    if (!options || !options.hasOwnProperty("orderId") || !options.hasOwnProperty("companyAddress") || !options.hasOwnProperty("companyMoney")) {
      log("updateCompanyAddress: options illegal", options);           // 414
    } else {                                                           //
      var orderId = options.orderId;                                   // 416
      var companyAddress = options.companyAddress;                     // 417
      var companyMoney = options.companyMoney;                         // 418
      Orders.update({                                                  // 419
        orderId: orderId                                               // 420
      }, {                                                             //
        $set: {                                                        // 422
          companyAddress: companyAddress,                              // 423
          companyMoney: companyMoney                                   // 424
        }                                                              //
      }, {                                                             //
        upsert: true                                                   // 427
      }, function (err) {                                              //
        if (err) {                                                     // 429
          log("updateCompanyAddress: update address error", err);      // 430
        } else {                                                       //
          log("updateCompanyAddress: update address succeed.");        // 432
        }                                                              //
      });                                                              //
    }                                                                  //
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=order.js.map
