(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/order/order.js                                               //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
function log(info) {                                                   // 1
  console.log('-------------------------');                            // 2
  var length = arguments.length;                                       // 3
  for (var i = 0; i < length; i++) {                                   // 4
    console.log(arguments[i]);                                         // 5
  }                                                                    //
}                                                                      //
                                                                       //
Meteor.methods({                                                       // 10
  "updateOrderAddress": function (options) {                           // 11
    log("updateOrderAddress: Hi, I am called.");                       // 12
    if (!options || !options.relationId || !options.receiver || !options.address || !options.phone || !options.zipcode) {
      console.log('user address options not legal');                   // 14
      console.log(options);                                            // 15
    } else {                                                           //
      var relationId = options.relationId;                             // 17
                                                                       //
      Orders.update({ relationId: relationId }, {                      // 20
        $set: {                                                        // 21
          "addressInfo.receiver": options.receiver,                    // 22
          "addressInfo.address": options.address,                      // 23
          "addressInfo.phone": options.phone,                          // 24
          "addressInfo.zipcode": options.zipcode                       // 25
        }                                                              //
      }, {                                                             //
        multi: true                                                    // 28
      }, function (err) {                                              //
        if (err) {                                                     // 30
          console.log('update user address information error');        // 31
          console.log(err);                                            // 32
        } else {                                                       //
          console.log('update user address information succeed');      // 34
        }                                                              //
      });                                                              //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 42
  "UpdateOrderProgress": function (options) {                          // 43
    if (!options || !options.relationId || ! typeof options.status === 'number') {
      console.log('order progress update stop for options illegal');   // 45
      console.log(options);                                            // 46
    } else {                                                           //
      var relationId = options.relationId;                             // 48
      var status = options.status;                                     // 49
      Orders.update({ relationId: relationId }, {                      // 50
        $set: {                                                        // 51
          "productProgress.status": status                             // 52
        }                                                              //
      }, {                                                             //
        upsert: true,                                                  // 55
        multi: true                                                    // 56
      }, function (err) {                                              //
        if (err) {                                                     // 58
          console.log('update order progress error');                  // 59
          console.log(err);                                            // 60
        } else {                                                       //
          console.log('update order progress succeed');                // 62
        }                                                              //
      });                                                              //
    }                                                                  //
  }                                                                    //
                                                                       //
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 71
  "UpdateOrderRemark": function (orderId, remarkInfo) {                // 72
    if (!orderId || !remarkInfo) {                                     // 73
      throw new Meteor.Error("参数不可为空");                                // 74
    }                                                                  //
                                                                       //
    var orderInfo = Orders.findOne({ orderId: orderId }) || false;     // 77
    if (!orderInfo) {                                                  // 78
      throw new Meteor.Error("参数非法");                                  // 79
    }                                                                  //
                                                                       //
    Orders.upsert({ orderId: orderId }, { $set: { remark: remarkInfo || "" } });
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 88
  "UpdateHolder": function (options) {                                 // 89
    if (!options || !options.orderId || !options.holderId || !options.holderSex || !options.holderName || !options.holderCode || !options.holderAddress || !options.holderMoney || !options.moneyPercent) {
      console.log('order update holder options illegal');              // 91
      console.log(options);                                            // 92
    } else {                                                           //
      console.log(options);                                            // 94
      Orders.update({                                                  // 95
        orderId: options.orderId,                                      // 97
        "holders.holderId": options.holderId                           // 98
      }, {                                                             //
        $set: {                                                        // 100
          "holders.$.holderName": options.holderName,                  // 101
          "holders.$.sex": options.holderSex,                          // 102
          "holders.$.holderType": options.holderType,                  // 103
          "holders.$.code": options.holderCode,                        // 104
          "holders.$.money": options.holderMoney,                      // 105
          "holders.$.moneyPercent": options.moneyPercent,              // 106
          "holders.$.address": options.holderAddress                   // 107
        }                                                              //
      }, {                                                             //
        multi: true                                                    // 110
      }, function (err) {                                              //
        if (err) {                                                     // 112
          console.log('update holder error');                          // 113
          console.log(err);                                            // 114
        } else {                                                       //
          console.log('update holder succeed');                        // 116
        }                                                              //
      });                                                              //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 124
  "deleteHolder": function (options) {                                 // 125
    if (!options || !options.orderId || !options.holderId) {           // 126
      console.log("delete holder failed for options illegal");         // 127
    } else {                                                           //
      console.log(options);                                            // 129
      Orders.update({                                                  // 130
        orderId: options.orderId                                       // 131
      }, {                                                             //
        $pull: {                                                       // 133
          holders: {                                                   // 134
            holderId: options.holderId                                 // 135
          }                                                            //
        }                                                              //
      }, function (err) {                                              //
        if (err) {                                                     // 139
          console.log("delete holder error");                          // 140
          console.log(err);                                            // 141
        } else {                                                       //
          console.log("delete holder succeed");                        // 143
        }                                                              //
      });                                                              //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
//----------------------------------------------------------------------------
                                                                       //
Meteor.methods({                                                       // 153
  "OrderHolderAdd": function (options) {                               // 154
    if (!options || !options.orderId || !options.holderId || !options.holderSex || !options.holderName || !options.holderCode || !options.holderAddress || !options.holderMoney || !options.holderType || !options.moneyPercent) {
      console.log('order add holder options illegal');                 // 156
      console.log(options);                                            // 157
    } else {                                                           //
      Orders.update({                                                  // 159
        orderId: options.orderId                                       // 160
      }, {                                                             //
        $push: {                                                       // 162
          "holders": {                                                 // 163
            holderId: options.holderId,                                // 164
            holderName: options.holderName,                            // 165
            holderType: options.holderType,                            // 166
            sex: options.holderSex,                                    // 167
            code: options.holderCode,                                  // 168
            money: options.holderMoney,                                // 169
            moneyPercent: options.moneyPercent,                        // 170
            address: options.holderAddress                             // 171
          }                                                            //
        }                                                              //
      }, {                                                             //
        upsert: true                                                   // 175
      }, function (err) {                                              //
        if (err) {                                                     // 177
          console.log('add holder error');                             // 178
          console.log(err);                                            // 179
        } else {                                                       //
          console.log('add holder succeed');                           // 181
        }                                                              //
      });                                                              //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 189
  'OrderEditPerson': function (options) {                              // 190
    var orderId = options.orderId || "";                               // 191
    var legalPersonName = options.legalPersonName || "";               // 192
    var legalPersonId = options.legalPersonId || "";                   // 193
    var legalPersonPhone = options.legalPersonPhone || "";             // 194
    var legalPersonTel = options.legalPersonTel || "";                 // 195
    var legalPersonEmail = options.legalPersonEmail || "";             // 196
    var supervisorName = options.supervisorName || "";                 // 197
    var supervisorId = options.supervisorId || "";                     // 198
    if (orderId && legalPersonName && legalPersonId && supervisorName && supervisorId) {
      Orders.update({ orderId: orderId }, {                            // 202
        $set: {                                                        // 203
          legalPerson: {                                               // 204
            legalPersonName: legalPersonName,                          // 205
            legalPersonId: legalPersonId,                              // 206
            legalPersonPhone: legalPersonPhone,                        // 207
            legalPersonTel: legalPersonTel,                            // 208
            legalPersonEmail: legalPersonEmail                         // 209
          },                                                           //
          supervisor: {                                                // 211
            supervisorName: supervisorName,                            // 212
            supervisorId: supervisorId                                 // 213
          }                                                            //
        }                                                              //
      }, {                                                             //
        upsert: true                                                   // 217
      }, function (err) {                                              //
        if (err) {                                                     // 219
          log('update order person information error', err);           // 220
        } else {                                                       //
          log('update order person information succeed');              // 222
        }                                                              //
      });                                                              //
    } else {                                                           //
      log('person information not complately', options);               // 226
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 233
  'updateCompanyName': function (options) {                            // 234
    log("updateCompanyName: Hi, I am called.", options);               // 235
    if (options && options.orderId && options.mainName && (options.alternativeName1 || options.alternativeName2 || options.alternativeName3 || options.alternativeName4)) {
      var orderId = options.orderId;                                   // 239
      delete options.orderId;                                          // 240
      var companyName = options;                                       // 241
      log(companyName);                                                // 242
      Orders.update({ orderId: orderId }, {                            // 243
        $set: {                                                        // 244
          companyName: companyName                                     // 245
        }                                                              //
      }, function (err) {                                              //
        if (err) {                                                     // 248
          log('update company name error', err);                       // 249
        } else {                                                       //
          log('update company name succeed');                          // 251
        }                                                              //
      });                                                              //
    } else {                                                           //
      log('update company name error, for the information you provided not valid', options);
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 263
  'updateIndustry': function (industryOptions) {                       // 264
    if (!industryOptions || !industryOptions.orderId || !industryOptions.industryBig || !industryOptions.industrySmall) {
      log("industryOptions illegal", industryOptions);                 // 266
    } else {                                                           //
      var orderId = industryOptions.orderId || "";                     // 268
      var industryBig = industryOptions.industryBig || "";             // 269
      var industrySmall = industryOptions.industrySmall || "";         // 270
      var businessScope = [];                                          // 271
      var business = Business.findOne({ industryBig: industryBig, industrySmall: industrySmall });
      if (business) {                                                  // 273
        businessScope = business.content;                              // 274
      }                                                                //
                                                                       //
      if (businessScope.length > 0 && industryOptions && orderId && industryBig !== null && industrySmall !== null && industryBig !== "" && industrySmall !== "") {
                                                                       //
        Orders.update({ orderId: orderId }, {                          // 279
          $set: {                                                      // 280
            industryBig: industryBig,                                  // 281
            industrySmall: industrySmall,                              // 282
            businessScope: businessScope                               // 283
          }                                                            //
        }, function (err) {                                            //
          if (err) {                                                   // 286
            log('update industry type error', err);                    // 287
          } else {                                                     //
            log('update industry type succeed');                       // 289
          }                                                            //
        });                                                            //
      } else {                                                         //
        log('update industry type error, check you parameters', industryOptions);
      }                                                                //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 303
  'EditScope': function (options) {                                    // 304
    if (options && options.orderId && options.contents instanceof Array) {
      Orders.update({ orderId: options.orderId }, {                    // 307
        $set: {                                                        // 308
          businessScope: options.contents                              // 309
        }                                                              //
      }, function (err) {                                              //
        if (err) {                                                     // 312
          log('Edit business scope error', err);                       // 313
        } else {                                                       //
          log('Edit business scope succeed');                          // 315
        }                                                              //
      });                                                              //
    } else {                                                           //
      log("Edit business scope failed for options illegal", options);  // 319
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 327
  'UpdateIndustryDetail': function (options) {                         // 328
    var orderId = options.orderId;                                     // 329
    var contents = options.contents;                                   // 330
                                                                       //
    if (options && orderId && contents instanceof Array) {             // 332
      Orders.update({ orderId: orderId }, {                            // 334
        $pushAll: {                                                    // 335
          businessScope: contents                                      // 336
        }                                                              //
      }, function (err) {                                              //
        if (err) {                                                     // 339
          log('Add business scope error');                             // 340
        } else {                                                       //
          log('Add business scope succeed');                           // 342
        }                                                              //
      });                                                              //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 351
  "UpdateOrderConsigner": function (options) {                         // 352
    var EmailReg = /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/;
    var PhoneReg = /^(0|86|17951)?(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$/;
    if (!options || !options.orderId || !options.consignerName || !EmailReg.test(options.consignerEmail) || !PhoneReg.test(options.consignerPhone)) {
      var err = "consigner information not complately";                // 356
      log(err, options);                                               // 357
    } else {                                                           //
      var orderId = options.orderId;                                   // 359
      var consigner = {                                                // 360
        consignerName: options.consignerName,                          // 361
        consignerPhone: options.consignerPhone,                        // 362
        consignerEmail: options.consignerEmail                         // 363
      };                                                               //
                                                                       //
      Orders.update({ orderId: orderId }, {                            // 366
        $set: {                                                        // 367
          consigner: consigner                                         // 368
        }                                                              //
      }, function (err) {                                              //
        if (err) {                                                     // 371
          log("update order consigner error", err);                    // 372
        } else {                                                       //
          log("update order consigner succeed");                       // 374
        }                                                              //
      });                                                              //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 383
  'CompayContractorHandle': function (options) {                       // 384
    var IdReg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;            // 385
    var EmailReg = /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/;
    var PhoneReg = /^(0|86|17951)?(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$/;
                                                                       //
    if (!options || !options.orderId || !options.liaisons || !IdReg.test(options.liaisons.liaisonsId) || !PhoneReg.test(options.liaisons.liaisonsPhone) || !EmailReg.test(options.liaisons.liaisonsEmail) || !options.financialStaff || !IdReg.test(options.financialStaff.financialStaffId) || !PhoneReg.test(options.financialStaff.financialStaffPhone) || !EmailReg.test(options.financialStaff.financialStaffEmail)) {
      var err = 'contractor information not complately';               // 398
      log(err, options);                                               // 399
    } else {                                                           //
      var orderId = options.orderId;                                   // 401
      var liaisons = options.liaisons;                                 // 402
      var financialStaff = options.financialStaff;                     // 403
                                                                       //
      Orders.update({ orderId: orderId }, {                            // 405
        $set: {                                                        // 406
          contractor: {                                                // 407
            liaisons: liaisons,                                        // 408
            financialStaff: financialStaff                             // 409
          }                                                            //
        }                                                              //
      }, function (err) {                                              //
        if (err) {                                                     // 413
          log('update contractor information error', err);             // 414
        } else {                                                       //
          log('update contractor information succeed');                // 416
        }                                                              //
      });                                                              //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Meteor.methods({                                                       // 424
  "updateCompanyAddress": function (options) {                         // 425
    log("updateCompanyAddress: Hi, I am called");                      // 426
    if (!options || !options.hasOwnProperty("orderId") || !options.hasOwnProperty("companyAddress") || !options.hasOwnProperty("companyMoney")) {
      log("updateCompanyAddress: options illegal", options);           // 431
    } else {                                                           //
      var orderId = options.orderId;                                   // 433
      var companyAddress = options.companyAddress;                     // 434
      var companyMoney = options.companyMoney;                         // 435
      Orders.update({                                                  // 436
        orderId: orderId                                               // 437
      }, {                                                             //
        $set: {                                                        // 439
          companyAddress: companyAddress,                              // 440
          companyMoney: companyMoney                                   // 441
        }                                                              //
      }, {                                                             //
        upsert: true                                                   // 444
      }, function (err) {                                              //
        if (err) {                                                     // 446
          log("updateCompanyAddress: update address error", err);      // 447
        } else {                                                       //
          log("updateCompanyAddress: update address succeed.");        // 449
        }                                                              //
      });                                                              //
    }                                                                  //
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=order.js.map
