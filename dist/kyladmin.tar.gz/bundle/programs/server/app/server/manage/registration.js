(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/manage/registration.js                                       //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
function log(info) {                                                   // 1
  console.log('-------------------------');                            // 2
  var length = arguments.length;                                       // 3
  for (var i = 0; i < length; i++) {                                   // 4
    console.log(arguments[i]);                                         // 5
  }                                                                    //
}                                                                      //
                                                                       //
/**                                                                    //
 * updateRegistrationMainInfo                                          //
 * 修改 registration list 的基本信息：名称，名称代码                                  //
 */                                                                    //
                                                                       //
Meteor.methods({                                                       // 15
  "UpdateRegistrationMainInfo": function (options) {                   // 16
    function HandleRegistrationMain(callback) {                        // 17
      if (!options || !options.userId || !options.listId || !options.registrationName || !options.registrationType) {
        log("UpdateRegistrationMainInfo failed, options illegal", options);
        callback(null, {                                               // 20
          status: 0,                                                   // 21
          message: "更新信息失败，信息必须完整！"                                    // 22
        });                                                            //
      } else {                                                         //
        var user = Meteor.users.find({                                 // 25
          _id: options.userId,                                         // 26
          "roles": {                                                   // 27
            $all: ["manageusers"]                                      // 28
          }                                                            //
        });                                                            //
        if (user) {                                                    // 31
          RegistrationLists.update({                                   // 32
            _id: options.listId                                        // 33
          }, {                                                         //
            $set: {                                                    // 35
              name: options.registrationName,                          // 36
              type: options.registrationType                           // 37
            }                                                          //
          }, function (err) {                                          //
            if (err) {                                                 // 40
              log("product registration main information update error", err);
              callback(null, {                                         // 42
                status: 0,                                             // 43
                message: "更新信息失败，请重新提交信息！"                             // 44
              });                                                      //
            } else {                                                   //
              log("product registration main information update succeed");
              callback(null, {                                         // 48
                status: 1,                                             // 49
                message: "更新公司注册产品信息成功！"                               // 50
              });                                                      //
            }                                                          //
          });                                                          //
        } else {                                                       //
          log("user do not have authority to handle RegistrationLists db");
          callback(null, {                                             // 56
            status: 0,                                                 // 57
            message: "更新失败，没有权限操作该信息"                                  // 58
          });                                                          //
        }                                                              //
      }                                                                //
    }                                                                  //
    var handleRegistration = Async.wrap(HandleRegistrationMain);       // 63
    var response = new handleRegistration();                           // 64
    return response;                                                   // 65
  }                                                                    //
});                                                                    //
                                                                       //
/**                                                                    //
 * 修改 registration list 中的区域信息                                         //
 */                                                                    //
                                                                       //
Meteor.methods({                                                       // 74
  "upsertRegistrationZone": function (options) {                       // 75
    console.log("addRegistrationZone");                                // 76
                                                                       //
    function RegistrationZone(callback) {                              // 78
      if (!options || !options.userId || !options.listId || !options.zone || !options.payment || !options.message) {
        log("registration zone information upsert failed for options illegal", options);
        callback(null, {                                               // 81
          status: 0,                                                   // 82
          message: "修改区域信息失败，信息不完整！"                                   // 83
        });                                                            //
      } else {                                                         //
        var user = Meteor.users.find({                                 // 86
          _id: options.userId,                                         // 87
          "roles": {                                                   // 88
            $all: ["manageusers"]                                      // 89
          }                                                            //
        });                                                            //
        if (user) {                                                    // 92
          console.log(options);                                        // 93
          RegistrationLists.update({                                   // 94
            _id: options.listId,                                       // 95
            "services.zone": options.zone                              // 96
          }, {                                                         //
            "$set": {                                                  // 98
              "services.$.zone": options.zone,                         // 99
              "services.$.payment": options.payment,                   // 100
              "services.$.message": options.message                    // 101
            }                                                          //
          }, function (err, result) {                                  //
            console.log(arguments);                                    // 104
            if (err) {                                                 // 105
              log("add zone information error", err);                  // 106
              callback(err, {                                          // 107
                status: 0,                                             // 108
                message: "修改区域信息失败！"                                   // 109
              });                                                      //
            } else {                                                   //
              if (result === 0) {                                      // 112
                RegistrationLists.update({                             // 113
                  _id: options.listId,                                 // 114
                  "services.zone": {                                   // 115
                    $ne: options.zone                                  // 116
                  }                                                    //
                }, {                                                   //
                  $push: {                                             // 119
                    services: {                                        // 120
                      zone: options.zone,                              // 121
                      payment: options.payment,                        // 122
                      message: options.message                         // 123
                    }                                                  //
                  }                                                    //
                }, function (err) {                                    //
                  if (err) {                                           // 127
                    log("updsert zone information error", err);        // 128
                    callback(err, {                                    // 129
                      status: 0,                                       // 130
                      message: "修改区域信息失败！"                             // 131
                    });                                                //
                  } else {                                             //
                    log("upsert zone information succeed");            // 134
                    callback(null, {                                   // 135
                      status: 1,                                       // 136
                      message: "修改区域信息成功！"                             // 137
                    });                                                //
                  }                                                    //
                });                                                    //
              } else {                                                 //
                callback(null, {                                       // 142
                  status: 1,                                           // 143
                  message: "修改区域信息成功！"                                 // 144
                });                                                    //
              }                                                        //
            }                                                          //
          });                                                          //
        } else {                                                       //
          log("user do not have authority to handle RegistrationLists db");
          callback(null, {                                             // 151
            status: 0,                                                 // 152
            message: "更新失败，没有权限操作该信息"                                  // 153
          });                                                          //
        }                                                              //
      }                                                                //
    }                                                                  //
                                                                       //
    var registrationZonen = Async.wrap(RegistrationZone);              // 159
    var response = new registrationZonen();                            // 160
    return response;                                                   // 161
  }                                                                    //
});                                                                    //
                                                                       //
/**                                                                    //
 * 删除registration 中的区域信息                                               //
 */                                                                    //
                                                                       //
Meteor.methods({                                                       // 169
  "deleteRegistrationZone": function (options) {                       // 170
    if (!options || !options.listId || !options.userId || !options.zone) {
      log("delete registration zone failed", options);                 // 172
    } else {                                                           //
      var user = Meteor.users.find({                                   // 174
        _id: options.userId,                                           // 175
        "roles": {                                                     // 176
          $all: ["manageusers"]                                        // 177
        }                                                              //
      });                                                              //
      if (user) {                                                      // 180
        RegistrationLists.update({                                     // 181
          _id: options.listId                                          // 182
        }, {                                                           //
          $pull: {                                                     // 184
            "services": {                                              // 185
              zone: options.zone                                       // 186
            }                                                          //
          }                                                            //
        }, function (err) {                                            //
          if (err) {                                                   // 190
            log("delete registration lists zone error", err);          // 191
          } else {                                                     //
            log("delete registration lists zone succeed");             // 193
          }                                                            //
        });                                                            //
      } else {                                                         //
        log("current user : " + options.userId + " do not have permission to delete registration zone");
      }                                                                //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
/**                                                                    //
 * 删除registration list                                                 //
 */                                                                    //
                                                                       //
Meteor.methods({                                                       // 207
  "deleteRegistrationHandle": function (options) {                     // 208
    if (!options || !options.listId || !options.userId) {              // 209
      log("delete registration list failed", options);                 // 210
    } else {                                                           //
      var user = Meteor.users.find({                                   // 212
        _id: options.userId,                                           // 213
        "roles": {                                                     // 214
          $all: ["manageusers"]                                        // 215
        }                                                              //
      });                                                              //
      if (user) {                                                      // 218
        RegistrationLists.remove({                                     // 219
          _id: options.listId                                          // 220
        }, function (err) {                                            //
          if (err) {                                                   // 222
            log("delete registration list error", err);                // 223
          } else {                                                     //
            log("delete registration succeed");                        // 225
          }                                                            //
        });                                                            //
      } else {                                                         //
        log("user " + options.userId + " do not have permission to hancle registration lists");
      }                                                                //
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
/**                                                                    //
 * 新增 registration list                                                //
 */                                                                    //
                                                                       //
Meteor.methods({                                                       // 239
  "addRegistrationList": function (options) {                          // 240
    function RegistrationList(callback) {                              // 241
      if (!options || !options.userId || !options.name || !options.type) {
        log("add registration list failed", options);                  // 243
        callback(null, { status: 0, message: "参数不全，增加失败！" });          // 244
      } else {                                                         //
        var user = Meteor.users.find({                                 // 246
          _id: options.userId,                                         // 247
          "roles": {                                                   // 248
            $all: ["manageusers"]                                      // 249
          }                                                            //
        });                                                            //
        if (!user) {                                                   // 252
          log("use do not have permission to hancle registration list");
          callback(null, { status: 0, message: "增加失败，没有权限！" });        // 254
        } else {                                                       //
                                                                       //
          RegistrationLists.update({                                   // 257
            name: options.name                                         // 258
          }, {                                                         //
            $set: {                                                    // 260
              name: options.name,                                      // 261
              type: options.type                                       // 262
            }                                                          //
          }, {                                                         //
            upsert: true                                               // 265
          }, function (err) {                                          //
            if (err) {                                                 // 267
              log("registration list add error", err);                 // 268
              callback(null, { status: 0, message: "新增公司注册信息失败，请重试！" });
            } else {                                                   //
              log("registration list add succeed");                    // 271
              callback(null, { status: 1, message: "新增公司注册信息成功！" });   // 272
            }                                                          //
          });                                                          //
        }                                                              //
      }                                                                //
    }                                                                  //
    var RegistrationHandleAdd = Async.wrap(RegistrationList);          // 278
    var response = new RegistrationHandleAdd();                        // 279
    return response;                                                   // 280
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=registration.js.map
