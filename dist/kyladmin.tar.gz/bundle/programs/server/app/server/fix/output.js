(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/fix/output.js                                                //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/*                                                                     //
 * 一些辅助运营人员的方法                                                         //
 **/                                                                   //
                                                                       //
function outPutOrder(fromTime, toTime) {                               // 6
  if (!fromTime || !toTime) {                                          // 7
    return;                                                            // 8
  }                                                                    //
  var jsonInfo = [];                                                   // 10
                                                                       //
  var orders = Orders.find({                                           // 12
    payedTime: { $lte: toTime, $gte: fromTime }, payed: true           // 13
  }, {                                                                 //
    sort: { payedTime: 1 },                                            // 15
    fields: { host: 1, openid: 1, orderId: 1 }                         // 16
  }).forEach(function (info) {                                         //
    var payChannel = ({ 'KYLPC': 'PC端支付宝', 'KYLWAP': '移动端支付宝', 'KYLWX': '微信' })[info.host];
    var orderId = info.orderId;                                        // 19
    jsonInfo.push({ "支付渠道": payChannel, "订单编号": orderId });            // 20
  });                                                                  //
                                                                       //
  var pathBasic = process.env.PWD + '/server/fix/';                    // 23
                                                                       //
  outPutJsonFile(jsonInfo, pathBasic + "out.json");                    // 25
};                                                                     //
                                                                       //
function outPutJsonFile(jsonData, filePath) {                          // 28
  var fs = Npm.require('fs');                                          // 29
  fs.writeFileSync(filePath, JSON.stringify(jsonData));                // 30
}                                                                      //
                                                                       //
Meteor.startup(function () {                                           // 34
  // outPutOrder(new Date(1459488133856), new Date(1461924605798));    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=output.js.map
