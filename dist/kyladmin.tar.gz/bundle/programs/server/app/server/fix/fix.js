(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/fix/fix.js                                                   //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/*                                                                     //
 * 本文件中函数用于修复一些之前系统中的问题                                                //
**/                                                                    //
                                                                       //
/*                                                                     //
 * 在订单中添加支付渠道自身的订单号（从之前的payLogs中取）                                     //
**/                                                                    //
function orderAddPayInfo() {}                                          // 10
                                                                       //
/*                                                                     //
 * host的信息有误                                                           //
 *                                                                     //
 **/                                                                   //
function fixHostError() {                                              // 18
  console.log("fixHostError");                                         // 19
  var count = 0;                                                       // 20
  Orders.find({                                                        // 21
    payed: true, host: { $in: ["KYLWX", "KYLWAP"] }                    // 22
  }, { fields: { host: 1, openid: 1 } }).forEach(function (order) {    //
                                                                       //
    var paylog = PayLogs.findOne({ openid: order.openid });            // 25
    var host = order.host;                                             // 26
                                                                       //
    var updateOrder = false;                                           // 28
    if (paylog.paySuccessInfo && host == "KYLWX") {                    // 29
      updateOrder = Orders.update({ openid: order.openid }, { $set: { host: "KYLWAP" } });
    } else if (paylog.wxpayInfos && host == "KYLWAP") {                //
      updateOrder = Orders.update({ openid: order.openid }, { $set: { host: "KYLWX" } });
    }                                                                  //
                                                                       //
    if (updateOrder) {                                                 // 35
      count += 1;                                                      // 36
      console.log("updateOrder: ", updateOrder, " count:", count);     // 37
    }                                                                  //
  });                                                                  //
}                                                                      //
                                                                       //
Meteor.startup(function () {                                           // 44
  // fixHostError();                                                   //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=fix.js.map
