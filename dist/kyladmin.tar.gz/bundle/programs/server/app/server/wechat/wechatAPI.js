(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/wechat/wechatAPI.js                                          //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
var wechatAPI = Meteor.npmRequire('wechat-api');                       // 1
                                                                       //
var WXAPI = new wechatAPI(WXConfig.appID, WXConfig.appsecret, getToken, saveToken);
function getToken(callback) {                                          // 4
  // 传入一个获取全局token的方法                                                  //
  console.log('getToken');                                             // 6
  var Fiber = Npm.require("fibers");                                   // 7
  Fiber(function () {                                                  // 8
    var info = WeChatInfo.findOne({ name: 'access_token' }) || {};     // 9
    callback(null, info.token);                                        // 10
  }).run();                                                            //
}                                                                      //
                                                                       //
function saveToken(token, callback) {                                  // 14
  // 请将token存储到全局，跨进程、跨机器级别的全局，比如写到数据库、redis等                          //
  // 这样才能在cluster模式及多机情况下使用，以下为写入到文件的示例                                //
  console.log("saveToken", token);                                     // 17
  var Fiber = Npm.require("fibers");                                   // 18
  Fiber(function () {                                                  // 19
    WeChatInfo.upsert({ name: 'access_token' }, { $set: { name: 'access_token', token: token } }, callback);
  }).run();                                                            //
}                                                                      //
                                                                       //
Meteor.methods({                                                       // 25
  'flashWXShopGoods': function () {                                    // 26
    // 拉取微信端的数据                                                        //
    var retInfo = getGoodsByStatus(0);                                 // 28
    if (retInfo.errcode) {                                             // 29
      throw new Meteor.Error(retInfo.errcode + ": " + retInfo.errmsg);
    }                                                                  //
    // 更新数据库的数据                                                        //
    var goods = retInfo.products_info || [];                           // 33
    WeChatShopGoods.remove({});                                        // 34
    goods.forEach(function (good) {                                    // 35
      WeChatShopGoods.insert(good);                                    // 36
    });                                                                //
  },                                                                   //
  'newWXShopGood': function (good) {                                   // 39
    var good = {                                                       // 40
      product_base: {                                                  // 41
        name: '测试商品',                                                  // 42
        main_img: "http://mmbiz.qpic.cn/mmbiz/sgT7HNZ9VPX42WvTv9hT8XhYyMIF4KmYfdd3PDTH8plPPovf3No5oI3Vu35Libcm59j27qCow7xRHwibC1CEYpAw/0",
        buy_limit: 0,                                                  // 44
        img: ["http://mmbiz.qpic.cn/mmbiz/sgT7HNZ9VPX42WvTv9hT8XhYyMIF4KmYfdd3PDTH8plPPovf3No5oI3Vu35Libcm59j27qCow7xRHwibC1CEYpAw/0"],
        detail: [{                                                     // 48
          text: '测试商品内容'                                               // 49
        }]                                                             //
      },                                                               //
      sku_list: [{                                                     // 52
        sku_id: '',                                                    // 53
        price: 1,                                                      // 54
        quantity: 10                                                   // 55
      }],                                                              //
      attrext: {                                                       // 57
        isPostFree: 1,                                                 // 58
        isHasReceipt: 1,                                               // 59
        location: {                                                    // 60
          country: '中国',                                               // 61
          province: '上海市',                                             // 62
          city: '上海市',                                                 // 63
          address: '长宁区'                                               // 64
        }                                                              //
      }                                                                //
    };                                                                 //
                                                                       //
    var retInfo = createGoods(good);                                   // 69
    console.log("newWXShopGood", retInfo);                             // 70
    if (retInfo.errcode) {                                             // 71
      throw new Meteor.Error(retInfo.errcode + ": " + retInfo.errmsg);
    }                                                                  //
    var product_id = retInfo.product_id;                               // 74
                                                                       //
    // 拉取全部数据 or 拉取单个数据                                                //
                                                                       //
    // 更新数据库 全部 or 单个                                                  //
  },                                                                   //
  'updateWXShopGood': function (id, good) {                            // 80
    // 更新微信端的数据                                                        //
                                                                       //
    // 更新数据可的数据                                                        //
  },                                                                   //
  'delWXShopGood': function (id) {                                     // 85
    console.log("delWXShopGood", id);                                  // 86
    return true;                                                       // 87
  },                                                                   //
  'uploadImg': function () {                                           // 89
    // 获取图片数据                                                          //
    var path = process.env.PWD + '/public/img/avatars/avatar.jpg';     // 91
    console.log("uploadImg", path);                                    // 92
    WXAPI.uploadPicture(path, function (err, res) {                    // 93
      console.log("uploadImg", err, res);                              // 94
    });                                                                //
  }                                                                    //
});                                                                    //
                                                                       //
////////////////////////////////////////////////////////////////////////////////////////
// 微信调用的同步化操作                                                          //
////////////////////////////////////////////////////////////////////////////////////////
function getGoodsByStatus(status) {                                    // 104
  status = status || 0;                                                // 105
  var ret = Async.runSync(function (callback) {                        // 106
    WXAPI.getGoodsByStatus(status, callback);                          // 107
  });                                                                  //
                                                                       //
  if (ret.error) {                                                     // 110
    console.log("getGoodsByStatus error-", ret.error);                 // 111
    throw new Meteor.Error(ret.error.name);                            // 112
  } else {                                                             //
    console.log("getGoodsByStatus ", ret.result);                      // 114
    return ret.result;                                                 // 115
  }                                                                    //
}                                                                      //
                                                                       //
function createGoods(goods) {                                          // 119
  var ret = Async.runSync(function (callback) {                        // 120
    WXAPI.createGoods(goods, callback);                                // 121
  });                                                                  //
                                                                       //
  if (ret.error) {                                                     // 124
    console.log("updateGoods error-", ret.error);                      // 125
    throw new Meteor.Error(ret.error);                                 // 126
  } else {                                                             //
    console.log("updateGoods ", ret.result);                           // 128
    return ret.result;                                                 // 129
  }                                                                    //
}                                                                      //
                                                                       //
function updateGoods(goods) {                                          // 133
  var ret = Async.runSync(function (callback) {                        // 134
    WXAPI.updateGoods(status, callback);                               // 135
  });                                                                  //
                                                                       //
  if (ret.error) {                                                     // 138
    console.log("updateGoods error-", ret.error);                      // 139
    throw new Meteor.Error(ret.error);                                 // 140
  } else {                                                             //
    console.log("updateGoods ", ret.result);                           // 142
    return ret.result;                                                 // 143
  }                                                                    //
}                                                                      //
                                                                       //
function updateGoodsStatus(product_id, status) {                       // 147
  var ret = Async.runSync(function (callback) {                        // 148
    WXAPI.updateGoodsStatus(product_id, status, callback);             // 149
  });                                                                  //
                                                                       //
  if (ret.error) {                                                     // 152
    console.log("updateGoods error-", ret.error);                      // 153
    throw new Meteor.Error(ret.error);                                 // 154
  } else {                                                             //
    console.log("updateGoods ", ret.result);                           // 156
    return ret.result;                                                 // 157
  }                                                                    //
}                                                                      //
                                                                       //
function deleteGoods(product_id) {                                     // 161
  var ret = Async.runSync(function (callback) {                        // 162
    WXAPI.deleteGoods(product_id, callback);                           // 163
  });                                                                  //
                                                                       //
  if (ret.error) {                                                     // 166
    console.log("updateGoods error-", ret.error);                      // 167
    throw new Meteor.Error(ret.error);                                 // 168
  } else {                                                             //
    console.log("updateGoods ", ret.result);                           // 170
    return ret.result;                                                 // 171
  }                                                                    //
}                                                                      //
                                                                       //
function uploadPicture() {}                                            // 175
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=wechatAPI.js.map
