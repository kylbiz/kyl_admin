(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/universal/publications.js                                    //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.publish('getAllOrders', function (dataLimit, dataFilter) {      // 1
  dataLimit = dataLimit || {};                                         // 2
  page = dataLimit.page || 1;                                          // 3
  num = dataLimit.num || 10;                                           // 4
                                                                       //
  dataFilter = dataFilter || {};                                       // 6
  dataFilter.payed = true;                                             // 7
                                                                       //
  var user = Meteor.users.findOne({ _id: this.userId });               // 9
  if (!Roles.userIsInRole(user, ['manageusers'])) {                    // 10
    var userNameLists = /15618871296|18521595051|15026444506|13701673465|13524861250|13916175286|15921239366|13585955409|150000852940/;
    var users = Meteor.users.find({                                    // 12
      username: userNameLists                                          // 13
    }, {                                                               //
      fields: {                                                        // 15
        username: 1,                                                   // 16
        _id: 1                                                         // 17
      }                                                                //
    }).fetch();                                                        //
                                                                       //
    var userIdLists = [];                                              // 21
    for (var i = 0; i < users.length; i++) {                           // 22
      userIdLists.push(users[i]._id);                                  // 23
    }                                                                  //
    dataFilter.userId = { $nin: userIdLists };                         // 25
  }                                                                    //
                                                                       //
  var orderInfo = Orders.find(dataFilter, {                            // 28
    sort: { payedTime: -1 },                                           // 29
    limit: num || 20,                                                  // 30
    skip: (page - 1) * num,                                            // 31
    fields: { openid: 1 }                                              // 32
  });                                                                  //
                                                                       //
  var openidList = [];                                                 // 35
  orderInfo.forEach(function (order) {                                 // 36
    if (order.openid) {                                                // 37
      openidList.push(order.openid);                                   // 38
    }                                                                  //
  });                                                                  //
                                                                       //
  return [Orders.find(dataFilter, {                                    // 42
    sort: { payedTime: -1 },                                           // 44
    limit: num || 20,                                                  // 45
    skip: (page - 1) * num                                             // 46
  }), PayLogs.find({ openid: { $in: openidList || [] } }, {            //
    fields: { openid: 1, payInfos: 1, wxpayInfos: 1, paySuccessInfo: 1 }
  })];                                                                 //
});                                                                    //
                                                                       //
Meteor.publish('getOrderTypeLists', function (typeNameFlag) {          // 58
  var user = Meteor.users.findOne({ _id: this.userId });               // 59
                                                                       //
  if (!Roles.userIsInRole(user, ['manageusers'])) {                    // 61
    var userNameLists = /15618871296|18521595051|15026444506|13701673465|13524861250|13916175286|15921239366|13585955409|150000852940/;
    var users = Meteor.users.find({                                    // 63
      username: userNameLists                                          // 64
    }, {                                                               //
      fields: {                                                        // 66
        username: 1,                                                   // 67
        _id: 1                                                         // 68
      }                                                                //
    }).fetch();                                                        //
                                                                       //
    var userIdLists = [];                                              // 72
    // var length = user.count();                                      //
    for (var i = 0; i < users.length; i++) {                           // 74
      userIdLists.push(users[i]._id);                                  // 75
    }                                                                  //
    var orders = Orders.find({                                         // 77
      typeNameFlag: typeNameFlag,                                      // 78
      host: /KYLPC|KYLWX|KYLWAP/,                                      // 79
      'userId': {                                                      // 80
        $nin: userIdLists                                              // 81
      }                                                                //
    }, {                                                               //
      sort: { orderId: -1 }                                            // 84
    });                                                                //
    return orders;                                                     // 86
  } else {                                                             //
    return Orders.find({                                               // 88
      typeNameFlag: typeNameFlag,                                      // 89
      host: /KYLPC|KYLWX|KYLWAP/                                       // 90
    }, {                                                               //
      sort: { orderId: -1 }                                            // 92
    });                                                                //
  }                                                                    //
                                                                       //
  // return Orders.find({typeNameFlag: typeNameFlag, host: /KYLPC|KYLWX|KYLWAP/});
});                                                                    //
                                                                       //
Meteor.publish('getUser', function (userId) {                          // 99
  return User.find({ _id: userId });                                   // 100
});                                                                    //
                                                                       //
Meteor.publish('registrationLists', function () {                      // 103
  return RegistrationLists.find();                                     // 104
});                                                                    //
                                                                       //
Meteor.publish('orderInformation', function (orderId) {                // 107
  return Orders.find({ orderId: orderId });                            // 108
});                                                                    //
                                                                       //
Meteor.publish('getUserOrderInfo', function (userId) {                 // 111
  return Orders.find({ userId: userId });                              // 112
});                                                                    //
                                                                       //
Meteor.publish('getBusinessTypeLists', function () {                   // 115
  return BusinessTypeLists.find({});                                   // 116
});                                                                    //
                                                                       //
Meteor.publish('getIndustrySmall', function (industryBig) {            // 119
  industryBig = industryBig || "";                                     // 120
  return Business.find({ industryBig: industryBig });                  // 121
});                                                                    //
                                                                       //
Meteor.publish('IndustryLists', function () {                          // 124
  return Business1.find({});                                           // 125
});                                                                    //
                                                                       //
Meteor.publish("getwxorders", function () {                            // 128
  return Orders.find({                                                 // 129
    host: 'KYLWECHAT'                                                  // 130
  }, {                                                                 //
    fields: {                                                          // 132
      order_id: 1,                                                     // 133
      order_status: 1,                                                 // 134
      product_name: 1,                                                 // 135
      product_price: 1,                                                // 136
      order_create_time: 1,                                            // 137
      updateTime: 1,                                                   // 138
      host: 1                                                          // 139
    }                                                                  //
  });                                                                  //
});                                                                    //
                                                                       //
Meteor.publish("getwxorder", function (order_id) {                     // 144
  return Orders.find({ host: 'KYLWECHAT', order_id: order_id });       // 145
});                                                                    //
                                                                       //
// Meteor.publish("getyzorders", function() {                          //
//   return Orders.find({                                              //
//     host: 'KYLYZ'                                                   //
//   }, {                                                              //
//     fields: {                                                       //
//       tid: 1,                                                       //
//       title: 1,                                                     //
//       status: 1,                                                    //
//       num: 1,                                                       //
//       type: 1,                                                      //
//       price: 1,                                                     //
//       buyer_nick: 1,                                                //
//       pay_time: 1,                                                  //
//       host: 1                                                       //
//     }                                                               //
//   });                                                               //
// })                                                                  //
                                                                       //
// Meteor.publish("yzorder", function(tid) {                           //
//   return Orders.find({host: 'KYLYZ', orderId: tid});                //
// })                                                                  //
                                                                       //
//---------------------------------------------------------            //
                                                                       //
Meteor.publish("customers", function () {                              // 173
  var user = Meteor.users.findOne({ _id: this.userId });               // 174
                                                                       //
  if (Roles.userIsInRole(user, ['admin'])) {                           // 176
    var users = Roles.getUsersInRole('customer', '', { fields: { emails: 1, profile: 1, roles: 1, createdAt: 1, username: 1 } });
    // var users = Meteor.users.find({"roles": {$all: ["customer"]}})  //
    return users;                                                      // 179
  }                                                                    //
                                                                       //
  this.stop();                                                         // 182
  return;                                                              // 183
});                                                                    //
                                                                       //
Meteor.publish("getCustomer", function (userId) {                      // 187
  var user = Meteor.users.findOne({ _id: this.userId });               // 188
                                                                       //
  if (Roles.userIsInRole(user, ['admin'])) {                           // 190
    var users = Meteor.users.find({ _id: userId });                    // 191
    return users;                                                      // 192
  }                                                                    //
                                                                       //
  this.stop();                                                         // 195
  return;                                                              // 196
});                                                                    //
                                                                       //
Meteor.publish("admins", function () {                                 // 201
  var user = Meteor.users.findOne({ _id: this.userId });               // 202
                                                                       //
  if (Roles.userIsInRole(user, ['manageusers'])) {                     // 204
    var users = Roles.getUsersInRole('admin', '', { fields: { emails: 1, profile: 1, roles: 1, createdAt: 1, username: 1 } });
    return users;                                                      // 206
  }                                                                    //
                                                                       //
  this.stop();                                                         // 209
  return;                                                              // 210
});                                                                    //
                                                                       //
Meteor.publish('GetHandleResults', function (uuid) {                   // 214
  return HandleResults.find({ uuid: uuid });                           // 215
});                                                                    //
                                                                       //
Meteor.publish('getDocNum', function (userId) {                        // 218
  return DocNum.find({ userId: userId });                              // 219
});                                                                    //
                                                                       //
// 获取微信小店的数据                                                           //
Meteor.publish('getWxShopInfo', function (cond) {                      // 223
  var userId = this.userId;                                            // 224
  if (userId && Roles.userIsInRole(userId, ['editgoods'])) {           // 225
    cond = cond || {};                                                 // 226
    return WeChatShopGoods.find(cond);                                 // 227
  } else {                                                             //
    this.stop();                                                       // 229
    return;                                                            // 230
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=publications.js.map
