(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/universal/publications.js                                    //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.publish('getAllOrders', function () {                           // 1
  var user = Meteor.users.findOne({ _id: this.userId });               // 2
  if (!Roles.userIsInRole(user, ['manageusers'])) {                    // 3
    var userNameLists = /15618871296|18521595051|15026444506|13701673465|13524861250|13916175286|15921239366|13585955409|150000852940/;
    var users = Meteor.users.find({                                    // 5
      username: userNameLists                                          // 6
    }, {                                                               //
      fields: {                                                        // 8
        username: 1,                                                   // 9
        _id: 1                                                         // 10
      }                                                                //
    }).fetch();                                                        //
                                                                       //
    var userIdLists = [];                                              // 14
    for (var i = 0; i < users.length; i++) {                           // 15
      userIdLists.push(users[i]._id);                                  // 16
    }                                                                  //
                                                                       //
    return Orders.find({                                               // 19
      host: /KYLPC|KYLWX|KYLWAP/,                                      // 20
      'userId': {                                                      // 21
        $nin: userIdLists                                              // 22
      }                                                                //
    }, {                                                               //
      sort: { orderId: -1 }                                            // 25
    });                                                                //
  } else {                                                             //
    return Orders.find({ host: /KYLPC|KYLWX|KYLWAP/ }, {               // 28
      sort: { orderId: -1 }                                            // 29
    });                                                                //
  }                                                                    //
});                                                                    //
                                                                       //
// Meteor.publish("getOrdersCount", function() {                       //
//   return Orders.find({}, {fields: {typeNameFlag: 1, host: 1}})      //
// })                                                                  //
                                                                       //
Meteor.publish('getOrderTypeLists', function (typeNameFlag) {          // 39
  var user = Meteor.users.findOne({ _id: this.userId });               // 40
                                                                       //
  if (!Roles.userIsInRole(user, ['manageusers'])) {                    // 42
    var userNameLists = /15618871296|18521595051|15026444506|13701673465|13524861250|13916175286|15921239366|13585955409|150000852940/;
    var users = Meteor.users.find({                                    // 44
      username: userNameLists                                          // 45
    }, {                                                               //
      fields: {                                                        // 47
        username: 1,                                                   // 48
        _id: 1                                                         // 49
      }                                                                //
    }).fetch();                                                        //
                                                                       //
    var userIdLists = [];                                              // 53
    // var length = user.count();                                      //
    for (var i = 0; i < users.length; i++) {                           // 55
      userIdLists.push(users[i]._id);                                  // 56
    }                                                                  //
    var orders = Orders.find({                                         // 58
      typeNameFlag: typeNameFlag,                                      // 59
      host: /KYLPC|KYLWX|KYLWAP/,                                      // 60
      'userId': {                                                      // 61
        $nin: userIdLists                                              // 62
      }                                                                //
    }, {                                                               //
      sort: { orderId: -1 }                                            // 65
    });                                                                //
    return orders;                                                     // 67
  } else {                                                             //
    return Orders.find({                                               // 69
      typeNameFlag: typeNameFlag,                                      // 70
      host: /KYLPC|KYLWX|KYLWAP/                                       // 71
    }, {                                                               //
      sort: { orderId: -1 }                                            // 73
    });                                                                //
  }                                                                    //
                                                                       //
  // return Orders.find({typeNameFlag: typeNameFlag, host: /KYLPC|KYLWX|KYLWAP/});
});                                                                    //
                                                                       //
Meteor.publish('getUser', function (userId) {                          // 80
  return User.find({ _id: userId });                                   // 81
});                                                                    //
                                                                       //
Meteor.publish('registrationLists', function () {                      // 84
  return RegistrationLists.find();                                     // 85
});                                                                    //
                                                                       //
Meteor.publish('orderInformation', function (orderId) {                // 88
  return Orders.find({ orderId: orderId });                            // 89
});                                                                    //
                                                                       //
Meteor.publish('getUserOrderInfo', function (userId) {                 // 92
  return Orders.find({ userId: userId });                              // 93
});                                                                    //
                                                                       //
Meteor.publish('getBusinessTypeLists', function () {                   // 96
  return BusinessTypeLists.find({});                                   // 97
});                                                                    //
                                                                       //
Meteor.publish('getIndustrySmall', function (industryBig) {            // 100
  industryBig = industryBig || "";                                     // 101
  return Business.find({ industryBig: industryBig });                  // 102
});                                                                    //
                                                                       //
Meteor.publish('IndustryLists', function () {                          // 105
  return Business1.find({});                                           // 106
});                                                                    //
                                                                       //
Meteor.publish("getwxorders", function () {                            // 109
  return Orders.find({                                                 // 110
    host: 'KYLWECHAT'                                                  // 111
  }, {                                                                 //
    fields: {                                                          // 113
      order_id: 1,                                                     // 114
      order_status: 1,                                                 // 115
      product_name: 1,                                                 // 116
      product_price: 1,                                                // 117
      order_create_time: 1,                                            // 118
      updateTime: 1,                                                   // 119
      host: 1                                                          // 120
    }                                                                  //
  });                                                                  //
});                                                                    //
                                                                       //
Meteor.publish("getwxorder", function (order_id) {                     // 125
  return Orders.find({ host: 'KYLWECHAT', order_id: order_id });       // 126
});                                                                    //
                                                                       //
// Meteor.publish("getyzorders", function() {                          //
//   return Orders.find({                                              //
//     host: 'KYLYZ'                                                   //
//   }, {                                                              //
//     fields: {                                                       //
//       tid: 1,                                                       //
//       title: 1,                                                     //
//       status: 1,                                                    //
//       num: 1,                                                       //
//       type: 1,                                                      //
//       price: 1,                                                     //
//       buyer_nick: 1,                                                //
//       pay_time: 1,                                                  //
//       host: 1                                                       //
//     }                                                               //
//   });                                                               //
// })                                                                  //
                                                                       //
// Meteor.publish("yzorder", function(tid) {                           //
//   return Orders.find({host: 'KYLYZ', orderId: tid});                //
// })                                                                  //
                                                                       //
//---------------------------------------------------------            //
                                                                       //
Meteor.publish("customers", function () {                              // 154
  var user = Meteor.users.findOne({ _id: this.userId });               // 155
                                                                       //
  if (Roles.userIsInRole(user, ['admin'])) {                           // 157
    var users = Roles.getUsersInRole('customer', '', { fields: { emails: 1, profile: 1, roles: 1, createdAt: 1, username: 1 } });
    // var users = Meteor.users.find({"roles": {$all: ["customer"]}})  //
    return users;                                                      // 160
  }                                                                    //
                                                                       //
  this.stop();                                                         // 163
  return;                                                              // 164
});                                                                    //
                                                                       //
Meteor.publish("getCustomer", function (userId) {                      // 168
  var user = Meteor.users.findOne({ _id: this.userId });               // 169
                                                                       //
  if (Roles.userIsInRole(user, ['admin'])) {                           // 171
    var users = Meteor.users.find({ _id: userId });                    // 172
    return users;                                                      // 173
  }                                                                    //
                                                                       //
  this.stop();                                                         // 176
  return;                                                              // 177
});                                                                    //
                                                                       //
Meteor.publish("admins", function () {                                 // 182
  var user = Meteor.users.findOne({ _id: this.userId });               // 183
                                                                       //
  if (Roles.userIsInRole(user, ['manageusers'])) {                     // 185
    var users = Roles.getUsersInRole('admin', '', { fields: { emails: 1, profile: 1, roles: 1, createdAt: 1, username: 1 } });
    return users;                                                      // 187
  }                                                                    //
                                                                       //
  this.stop();                                                         // 190
  return;                                                              // 191
});                                                                    //
                                                                       //
Meteor.publish('GetHandleResults', function (uuid) {                   // 195
  return HandleResults.find({ uuid: uuid });                           // 196
});                                                                    //
                                                                       //
Meteor.publish('getDocNum', function (userId) {                        // 199
  return DocNum.find({ userId: userId });                              // 200
});                                                                    //
                                                                       //
// 获取微信小店的数据                                                           //
Meteor.publish('getWxShopInfo', function (cond) {                      // 204
  var userId = this.userId;                                            // 205
  if (userId && Roles.userIsInRole(userId, ['editgoods'])) {           // 206
    cond = cond || {};                                                 // 207
    return WeChatShopGoods.find(cond);                                 // 208
  } else {                                                             //
    this.stop();                                                       // 210
    return;                                                            // 211
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=publications.js.map
