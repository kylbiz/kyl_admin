(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/universal/publications.js                                    //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.publish('getAllOrders', function () {                           // 1
  var user = Meteor.users.findOne({ _id: this.userId });               // 2
  if (!Roles.userIsInRole(user, ['manageusers'])) {                    // 3
    var userNameLists = /15618871296|18521595051|15026444506|13701673465|13524861250|13916175286|15921239366|13585955409|150000852940/;
    var users = Meteor.users.find({                                    // 5
      username: userNameLists                                          // 6
    }, {                                                               //
      fields: {                                                        // 8
        username: 1,                                                   // 9
        _id: 1                                                         // 10
      }                                                                //
    }).fetch();                                                        //
                                                                       //
    var userIdLists = [];                                              // 14
    for (var i = 0; i < users.length; i++) {                           // 15
      userIdLists.push(users[i]._id);                                  // 16
    }                                                                  //
                                                                       //
    return Orders.find({                                               // 19
      host: /KYLPC|KYLWX|KYLWAP/,                                      // 20
      'userId': {                                                      // 21
        $nin: userIdLists                                              // 22
      }                                                                //
    }, {                                                               //
      sort: { orderId: -1 }                                            // 25
    });                                                                //
  } else {                                                             //
    return Orders.find({ host: /KYLPC|KYLWX|KYLWAP/ }, {               // 28
      sort: { orderId: -1 }                                            // 29
    });                                                                //
  }                                                                    //
});                                                                    //
                                                                       //
// Meteor.publish("getOrdersCount", function() {                       //
//   return Orders.find({}, {fields: {typeNameFlag: 1, host: 1}})      //
// })                                                                  //
                                                                       //
// limit: 10,                                                          //
Meteor.publish('getOrderTypeLists', function (typeNameFlag) {          // 40
  var user = Meteor.users.findOne({ _id: this.userId });               // 41
                                                                       //
  if (!Roles.userIsInRole(user, ['manageusers'])) {                    // 43
    var userNameLists = /15618871296|18521595051|15026444506|13701673465|13524861250|13916175286|15921239366|13585955409|150000852940/;
    var users = Meteor.users.find({                                    // 45
      username: userNameLists                                          // 46
    }, {                                                               //
      fields: {                                                        // 48
        username: 1,                                                   // 49
        _id: 1                                                         // 50
      }                                                                //
    }).fetch();                                                        //
                                                                       //
    var userIdLists = [];                                              // 54
    // var length = user.count();                                      //
    for (var i = 0; i < users.length; i++) {                           // 56
      userIdLists.push(users[i]._id);                                  // 57
    }                                                                  //
    var orders = Orders.find({                                         // 59
      typeNameFlag: typeNameFlag,                                      // 60
      host: /KYLPC|KYLWX|KYLWAP/,                                      // 61
      'userId': {                                                      // 62
        $nin: userIdLists                                              // 63
      }                                                                //
    }, {                                                               //
      sort: { orderId: -1 }                                            // 66
    });                                                                //
    return orders;                                                     // 68
  } else {                                                             //
    return Orders.find({                                               // 70
      typeNameFlag: typeNameFlag,                                      // 71
      host: /KYLPC|KYLWX|KYLWAP/                                       // 72
    }, {                                                               //
      sort: { orderId: -1 }                                            // 74
    });                                                                //
  }                                                                    //
                                                                       //
  // return Orders.find({typeNameFlag: typeNameFlag, host: /KYLPC|KYLWX|KYLWAP/});
});                                                                    //
                                                                       //
Meteor.publish('getUser', function (userId) {                          // 81
  return User.find({ _id: userId });                                   // 82
});                                                                    //
                                                                       //
Meteor.publish('registrationLists', function () {                      // 85
  return RegistrationLists.find();                                     // 86
});                                                                    //
                                                                       //
Meteor.publish('orderInformation', function (orderId) {                // 89
  return Orders.find({ orderId: orderId });                            // 90
});                                                                    //
                                                                       //
Meteor.publish('getUserOrderInfo', function (userId) {                 // 93
  return Orders.find({ userId: userId });                              // 94
});                                                                    //
                                                                       //
Meteor.publish('getBusinessTypeLists', function () {                   // 97
  return BusinessTypeLists.find({});                                   // 98
});                                                                    //
                                                                       //
Meteor.publish('getIndustrySmall', function (industryBig) {            // 101
  industryBig = industryBig || "";                                     // 102
  return Business.find({ industryBig: industryBig });                  // 103
});                                                                    //
                                                                       //
Meteor.publish('IndustryLists', function () {                          // 106
  return Business1.find({});                                           // 107
});                                                                    //
                                                                       //
Meteor.publish("getwxorders", function () {                            // 110
  return Orders.find({                                                 // 111
    host: 'KYLWECHAT'                                                  // 112
  }, {                                                                 //
    fields: {                                                          // 114
      order_id: 1,                                                     // 115
      order_status: 1,                                                 // 116
      product_name: 1,                                                 // 117
      product_price: 1,                                                // 118
      order_create_time: 1,                                            // 119
      updateTime: 1,                                                   // 120
      host: 1                                                          // 121
    }                                                                  //
  });                                                                  //
});                                                                    //
                                                                       //
Meteor.publish("getwxorder", function (order_id) {                     // 126
  return Orders.find({ host: 'KYLWECHAT', order_id: order_id });       // 127
});                                                                    //
                                                                       //
// Meteor.publish("getyzorders", function() {                          //
//   return Orders.find({                                              //
//     host: 'KYLYZ'                                                   //
//   }, {                                                              //
//     fields: {                                                       //
//       tid: 1,                                                       //
//       title: 1,                                                     //
//       status: 1,                                                    //
//       num: 1,                                                       //
//       type: 1,                                                      //
//       price: 1,                                                     //
//       buyer_nick: 1,                                                //
//       pay_time: 1,                                                  //
//       host: 1                                                       //
//     }                                                               //
//   });                                                               //
// })                                                                  //
                                                                       //
// Meteor.publish("yzorder", function(tid) {                           //
//   return Orders.find({host: 'KYLYZ', orderId: tid});                //
// })                                                                  //
                                                                       //
//---------------------------------------------------------            //
                                                                       //
Meteor.publish("customers", function () {                              // 155
  var user = Meteor.users.findOne({ _id: this.userId });               // 156
                                                                       //
  if (Roles.userIsInRole(user, ['admin'])) {                           // 158
    var users = Roles.getUsersInRole('customer', '', { fields: { emails: 1, profile: 1, roles: 1, createdAt: 1, username: 1 } });
    // var users = Meteor.users.find({"roles": {$all: ["customer"]}})  //
    return users;                                                      // 161
  }                                                                    //
                                                                       //
  this.stop();                                                         // 164
  return;                                                              // 165
});                                                                    //
                                                                       //
Meteor.publish("getCustomer", function (userId) {                      // 169
  var user = Meteor.users.findOne({ _id: this.userId });               // 170
                                                                       //
  if (Roles.userIsInRole(user, ['admin'])) {                           // 172
    var users = Meteor.users.find({ _id: userId });                    // 173
    return users;                                                      // 174
  }                                                                    //
                                                                       //
  this.stop();                                                         // 177
  return;                                                              // 178
});                                                                    //
                                                                       //
Meteor.publish("admins", function () {                                 // 183
  var user = Meteor.users.findOne({ _id: this.userId });               // 184
                                                                       //
  if (Roles.userIsInRole(user, ['manageusers'])) {                     // 186
    var users = Roles.getUsersInRole('admin', '', { fields: { emails: 1, profile: 1, roles: 1, createdAt: 1, username: 1 } });
    return users;                                                      // 188
  }                                                                    //
                                                                       //
  this.stop();                                                         // 191
  return;                                                              // 192
});                                                                    //
                                                                       //
Meteor.publish('GetHandleResults', function (uuid) {                   // 196
  return HandleResults.find({ uuid: uuid });                           // 197
});                                                                    //
                                                                       //
Meteor.publish('getDocNum', function (userId) {                        // 200
  return DocNum.find({ userId: userId });                              // 201
});                                                                    //
                                                                       //
// 获取微信小店的数据                                                           //
Meteor.publish('getWxShopInfo', function (cond) {                      // 205
  var userId = this.userId;                                            // 206
  if (userId && Roles.userIsInRole(userId, ['editgoods'])) {           // 207
    cond = cond || {};                                                 // 208
    return WeChatShopGoods.find(cond);                                 // 209
  } else {                                                             //
    this.stop();                                                       // 211
    return;                                                            // 212
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=publications.js.map
