(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/universal/publications.js                                    //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
Meteor.publish('getAllOrders', function () {                           // 1
  var user = Meteor.users.findOne({ _id: this.userId });               // 2
  if (!Roles.userIsInRole(user, ['manageusers'])) {                    // 3
    var userNameLists = /15618871296|18521595051|15026444506|13701673465|13524861250|13916175286|15921239366|13585955409|150000852940/;
    var users = Meteor.users.find({                                    // 5
      username: userNameLists                                          // 6
    }, {                                                               //
      fields: {                                                        // 8
        username: 1,                                                   // 9
        _id: 1                                                         // 10
      }                                                                //
    }).fetch();                                                        //
                                                                       //
    var userIdLists = [];                                              // 14
    for (var i = 0; i < users.length; i++) {                           // 15
      userIdLists.push(users[i]._id);                                  // 16
    }                                                                  //
                                                                       //
    return Orders.find({                                               // 19
      host: /KYLPC|KYLWX|KYLWAP/,                                      // 20
      payed: true,                                                     // 21
      'userId': {                                                      // 22
        $nin: userIdLists                                              // 23
      }                                                                //
    }, {                                                               //
      sort: { payedTime: -1 },                                         // 26
      limit: 150                                                       // 27
    });                                                                //
  } else {                                                             //
    return Orders.find({ host: /KYLPC|KYLWX|KYLWAP/, payed: true }, {  // 30
      sort: { payedTime: -1 },                                         // 31
      limit: 150                                                       // 32
    });                                                                //
  }                                                                    //
});                                                                    //
                                                                       //
// Meteor.publish("getOrdersCount", function() {                       //
//   return Orders.find({}, {fields: {typeNameFlag: 1, host: 1}})      //
// })                                                                  //
                                                                       //
Meteor.publish('getOrderTypeLists', function (typeNameFlag) {          // 42
  var user = Meteor.users.findOne({ _id: this.userId });               // 43
                                                                       //
  if (!Roles.userIsInRole(user, ['manageusers'])) {                    // 45
    var userNameLists = /15618871296|18521595051|15026444506|13701673465|13524861250|13916175286|15921239366|13585955409|150000852940/;
    var users = Meteor.users.find({                                    // 47
      username: userNameLists                                          // 48
    }, {                                                               //
      fields: {                                                        // 50
        username: 1,                                                   // 51
        _id: 1                                                         // 52
      }                                                                //
    }).fetch();                                                        //
                                                                       //
    var userIdLists = [];                                              // 56
    // var length = user.count();                                      //
    for (var i = 0; i < users.length; i++) {                           // 58
      userIdLists.push(users[i]._id);                                  // 59
    }                                                                  //
    var orders = Orders.find({                                         // 61
      typeNameFlag: typeNameFlag,                                      // 62
      host: /KYLPC|KYLWX|KYLWAP/,                                      // 63
      'userId': {                                                      // 64
        $nin: userIdLists                                              // 65
      }                                                                //
    }, {                                                               //
      sort: { orderId: -1 }                                            // 68
    });                                                                //
    return orders;                                                     // 70
  } else {                                                             //
    return Orders.find({                                               // 72
      typeNameFlag: typeNameFlag,                                      // 73
      host: /KYLPC|KYLWX|KYLWAP/                                       // 74
    }, {                                                               //
      sort: { orderId: -1 }                                            // 76
    });                                                                //
  }                                                                    //
                                                                       //
  // return Orders.find({typeNameFlag: typeNameFlag, host: /KYLPC|KYLWX|KYLWAP/});
});                                                                    //
                                                                       //
Meteor.publish('getUser', function (userId) {                          // 83
  return User.find({ _id: userId });                                   // 84
});                                                                    //
                                                                       //
Meteor.publish('registrationLists', function () {                      // 87
  return RegistrationLists.find();                                     // 88
});                                                                    //
                                                                       //
Meteor.publish('orderInformation', function (orderId) {                // 91
  return Orders.find({ orderId: orderId });                            // 92
});                                                                    //
                                                                       //
Meteor.publish('getUserOrderInfo', function (userId) {                 // 95
  return Orders.find({ userId: userId });                              // 96
});                                                                    //
                                                                       //
Meteor.publish('getBusinessTypeLists', function () {                   // 99
  return BusinessTypeLists.find({});                                   // 100
});                                                                    //
                                                                       //
Meteor.publish('getIndustrySmall', function (industryBig) {            // 103
  industryBig = industryBig || "";                                     // 104
  return Business.find({ industryBig: industryBig });                  // 105
});                                                                    //
                                                                       //
Meteor.publish('IndustryLists', function () {                          // 108
  return Business1.find({});                                           // 109
});                                                                    //
                                                                       //
Meteor.publish("getwxorders", function () {                            // 112
  return Orders.find({                                                 // 113
    host: 'KYLWECHAT'                                                  // 114
  }, {                                                                 //
    fields: {                                                          // 116
      order_id: 1,                                                     // 117
      order_status: 1,                                                 // 118
      product_name: 1,                                                 // 119
      product_price: 1,                                                // 120
      order_create_time: 1,                                            // 121
      updateTime: 1,                                                   // 122
      host: 1                                                          // 123
    }                                                                  //
  });                                                                  //
});                                                                    //
                                                                       //
Meteor.publish("getwxorder", function (order_id) {                     // 128
  return Orders.find({ host: 'KYLWECHAT', order_id: order_id });       // 129
});                                                                    //
                                                                       //
// Meteor.publish("getyzorders", function() {                          //
//   return Orders.find({                                              //
//     host: 'KYLYZ'                                                   //
//   }, {                                                              //
//     fields: {                                                       //
//       tid: 1,                                                       //
//       title: 1,                                                     //
//       status: 1,                                                    //
//       num: 1,                                                       //
//       type: 1,                                                      //
//       price: 1,                                                     //
//       buyer_nick: 1,                                                //
//       pay_time: 1,                                                  //
//       host: 1                                                       //
//     }                                                               //
//   });                                                               //
// })                                                                  //
                                                                       //
// Meteor.publish("yzorder", function(tid) {                           //
//   return Orders.find({host: 'KYLYZ', orderId: tid});                //
// })                                                                  //
                                                                       //
//---------------------------------------------------------            //
                                                                       //
Meteor.publish("customers", function () {                              // 157
  var user = Meteor.users.findOne({ _id: this.userId });               // 158
                                                                       //
  if (Roles.userIsInRole(user, ['admin'])) {                           // 160
    var users = Roles.getUsersInRole('customer', '', { fields: { emails: 1, profile: 1, roles: 1, createdAt: 1, username: 1 } });
    // var users = Meteor.users.find({"roles": {$all: ["customer"]}})  //
    return users;                                                      // 163
  }                                                                    //
                                                                       //
  this.stop();                                                         // 166
  return;                                                              // 167
});                                                                    //
                                                                       //
Meteor.publish("getCustomer", function (userId) {                      // 171
  var user = Meteor.users.findOne({ _id: this.userId });               // 172
                                                                       //
  if (Roles.userIsInRole(user, ['admin'])) {                           // 174
    var users = Meteor.users.find({ _id: userId });                    // 175
    return users;                                                      // 176
  }                                                                    //
                                                                       //
  this.stop();                                                         // 179
  return;                                                              // 180
});                                                                    //
                                                                       //
Meteor.publish("admins", function () {                                 // 185
  var user = Meteor.users.findOne({ _id: this.userId });               // 186
                                                                       //
  if (Roles.userIsInRole(user, ['manageusers'])) {                     // 188
    var users = Roles.getUsersInRole('admin', '', { fields: { emails: 1, profile: 1, roles: 1, createdAt: 1, username: 1 } });
    return users;                                                      // 190
  }                                                                    //
                                                                       //
  this.stop();                                                         // 193
  return;                                                              // 194
});                                                                    //
                                                                       //
Meteor.publish('GetHandleResults', function (uuid) {                   // 198
  return HandleResults.find({ uuid: uuid });                           // 199
});                                                                    //
                                                                       //
Meteor.publish('getDocNum', function (userId) {                        // 202
  return DocNum.find({ userId: userId });                              // 203
});                                                                    //
                                                                       //
// 获取微信小店的数据                                                           //
Meteor.publish('getWxShopInfo', function (cond) {                      // 207
  var userId = this.userId;                                            // 208
  if (userId && Roles.userIsInRole(userId, ['editgoods'])) {           // 209
    cond = cond || {};                                                 // 210
    return WeChatShopGoods.find(cond);                                 // 211
  } else {                                                             //
    this.stop();                                                       // 213
    return;                                                            // 214
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=publications.js.map
