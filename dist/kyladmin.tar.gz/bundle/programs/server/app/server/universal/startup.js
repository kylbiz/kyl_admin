(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/universal/startup.js                                         //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
                                                                       //
var DocNumLists = [{ type: 'check', zone: 'hk', holdernum: '0', num: 1 }, { type: 'check', zone: 'hk', holdernum: '1', num: 1 }, { type: 'check', zone: 'pd', holdernum: '0', num: 3 }, { type: 'check', zone: 'pd', holdernum: '1', num: 3 }, { type: 'registration', zone: 'hk', holdernum: '0', num: 8 }, { type: 'registration', zone: 'hk', holdernum: '1', num: 8 }, { type: 'registration', zone: 'pd', holdernum: '0', num: 8 }, { type: 'registration', zone: 'pd', holdernum: '1', num: 8 }];
                                                                       //
Meteor.startup(function () {                                           // 13
  if (DocNum.find().count() === 0) {                                   // 14
    DocNumLists.forEach(function (docNum) {                            // 15
      DocNum.insert(docNum);                                           // 16
    });                                                                //
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=startup.js.map
